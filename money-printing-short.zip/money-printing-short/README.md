# Money Printing Short — Remotion

Proyecto vertical 1080x1920, 30 fps. Incluye la narración suministrada en `public/audio/narration.mp3`.

## Ejecutar

```bash
npm install
npm run typecheck
npm run render
```

El MP4 se genera en `out/money-printing-short.mp4`.

La duración configurada es de 1437 fotogramas (47,9 s), ajustada a la duración del audio incluido. Los tiempos de subtítulos son aproximados y se pueden retocar en `src/MoneyPrintingShort.tsx`.
