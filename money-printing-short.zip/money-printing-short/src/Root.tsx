import React from 'react';
import { Composition } from 'remotion';
import { MoneyPrintingShort } from './MoneyPrintingShort';
export const Root: React.FC = () => <Composition id="MoneyPrintingShort" component={MoneyPrintingShort} durationInFrames={1437} fps={30} width={1080} height={1920} />;
