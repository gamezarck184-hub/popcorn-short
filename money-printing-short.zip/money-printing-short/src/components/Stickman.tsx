import React from 'react';
import { useCurrentFrame, interpolate } from 'remotion';
export const Stickman: React.FC<{x?:number;y?:number;point?:boolean}> = ({x=760,y=1120,point=false}) => {
 const f=useCurrentFrame(); const bob=Math.sin(f/8)*7;
 return <g transform={`translate(${x} ${y+bob})`} stroke="#111827" strokeWidth="18" strokeLinecap="round" strokeLinejoin="round">
  <circle cx="0" cy="-150" r="76" fill="#fff" strokeWidth="12"/><circle cx="-25" cy="-160" r="7" fill="#111" stroke="none"/><circle cx="25" cy="-160" r="7" fill="#111" stroke="none"/><path d="M-24 -122 Q0 -102 24 -122" fill="none" strokeWidth="8"/>
  <path d="M-55 -65 Q0 -90 55 -65 L72 100 L-72 100 Z" fill="#20a45a" strokeWidth="12"/>
  <path d={point?'M-60 -35 L-145 -120 M60 -35 L145 -115':'M-60 -35 L-130 45 M60 -35 L130 45'} fill="none"/>
  <path d="M-35 100 L-50 230 M35 100 L50 230" fill="none"/>
  <path d="M-50 230 L-95 240 M50 230 L95 240" fill="none"/>
 </g>;
};
