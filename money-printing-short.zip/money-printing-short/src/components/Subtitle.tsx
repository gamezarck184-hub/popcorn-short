import React from 'react';
import { useCurrentFrame, interpolate } from 'remotion';
export const Subtitle: React.FC<{text:string}> = ({text}) => {const f=useCurrentFrame(); const op=interpolate(f,[0,5],[0,1],{extrapolateRight:'clamp'}); return <div style={{position:'absolute',bottom:190,left:65,right:65,textAlign:'center',fontFamily:'Arial,sans-serif',fontWeight:900,fontSize:48,lineHeight:1.15,color:'white',textShadow:'0 4px 12px #000',opacity:op,background:'rgba(0,0,0,.38)',padding:'18px 24px',borderRadius:18}}>{text}</div>};
