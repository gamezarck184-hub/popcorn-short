export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const DURATION_SEC = 59;
export const TOTAL_FRAMES = DURATION_SEC * FPS; // 1770 frames
export const FLOOR_Y = 1430;

// Integración de audio: si existe el archivo de narración en public/audio/, se monta en la composición.
// Para reemplazarlo fácilmente, coloca tu archivo de voz en public/audio/ y actualiza NARRATION_AUDIO_FILE si cambia el nombre.
export const NARRATION_AUDIO_FILE: string | null = 'narration.mp3';

export const FONT_FAMILY = 'system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';

export const PALETTE = {
  bgNavy: '#07111F',
  wallSlate: '#0E1C30',
  aisleMid: '#152842',
  floorMain: '#1E2F47',
  floorLine: '#3B5578',
  shelfBody: '#1B2A41',
  shelfEdge: '#64748B',
  sweaterGreen: '#1E7A44',
  sweaterGreenDark: '#14532D',
  accentGreen: '#22C55E',
  mintGlow: '#4ADE80',
  white: '#F8FAFC',
  greyLight: '#CBD5E1',
  ink: '#080C14',
  amber: '#F59E0B',
  red: '#EF4444',
  sky: '#38BDF8',
};

export const secToFrame = (s: number): number => Math.round(s * FPS);
