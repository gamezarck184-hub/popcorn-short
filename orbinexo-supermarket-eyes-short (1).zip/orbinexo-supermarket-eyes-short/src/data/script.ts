export interface SceneSegment {
  id: string;
  sceneNumber: number;
  title: string;
  startSec: number;
  endSec: number;
  narration: string;
  onScreenText: string | string[];
}

export const SCENE_SEGMENTS: SceneSegment[] = [
  {
    id: 'scene-01',
    sceneNumber: 1,
    title: 'ENTRADA AL SUPERMERCADO',
    startSec: 0,
    endSec: 6,
    narration:
      'Cuando entrás a un supermercado, probablemente no te das cuenta, pero algunos productos están colocados estratégicamente para que los elijas casi sin pensarlo.',
    onScreenText: 'NADA ESTÁ PUESTO AL AZAR',
  },
  {
    id: 'scene-02',
    sceneNumber: 2,
    title: 'LA ALTURA DE LOS OJOS',
    startSec: 6,
    endSec: 13,
    narration:
      'Y hay un detalle que puede hacerte gastar más dinero de lo que imaginás: la altura de tus ojos.',
    onScreenText: 'A LA ALTURA DE TUS OJOS',
  },
  {
    id: 'scene-03',
    sceneNumber: 3,
    title: 'LOS LUGARES MÁS VISIBLES',
    startSec: 13,
    endSec: 22,
    narration:
      'Los supermercados saben que normalmente miramos primero los estantes que tenemos justo delante. Por eso, muchas marcas pagan para conseguir los lugares más visibles de las góndolas.',
    onScreenText: 'LOS LUGARES MÁS VISIBLES TIENEN VALOR',
  },
  {
    id: 'scene-04',
    sceneNumber: 4,
    title: 'LOS PRODUCTOS ECONÓMICOS',
    startSec: 22,
    endSec: 32,
    narration:
      'Ahí suelen aparecer productos conocidos o más caros, mientras que las alternativas económicas pueden estar escondidas en los estantes inferiores o superiores.',
    onScreenText: ['ESTANTE CENTRAL', 'ESTANTE INFERIOR', 'COMPARÁ LOS PRECIOS'],
  },
  {
    id: 'scene-05',
    sceneNumber: 5,
    title: 'LA EXPLICACIÓN PSICOLÓGICA',
    startSec: 32,
    endSec: 43,
    narration:
      'Esto tiene una explicación psicológica: cuando vemos un producto fácilmente, es más probable que le prestemos atención y lo consideremos al momento de comprar.',
    onScreenText: 'MÁS VISIBILIDAD = MÁS ATENCIÓN',
  },
  {
    id: 'scene-06',
    sceneNumber: 6,
    title: 'EL DESCUBRIMIENTO',
    startSec: 43,
    endSec: 55,
    narration:
      'Y aunque parezca una decisión completamente nuestra, la ubicación de los productos puede influir bastante.',
    onScreenText: 'TU ELECCIÓN PUEDE ESTAR INFLUENCIADA',
  },
  {
    id: 'scene-07',
    sceneNumber: 7,
    title: 'CIERRE',
    startSec: 55,
    endSec: 58,
    narration:
      'La próxima vez que vayas al supermercado, mirá también arriba y abajo. Quizás encuentres exactamente el mismo producto por menos dinero.',
    onScreenText: 'MIRÁ ARRIBA. MIRÁ ABAJO. COMPARÁ',
  },
];
