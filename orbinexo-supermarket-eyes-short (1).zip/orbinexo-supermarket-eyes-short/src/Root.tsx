import React from 'react';
import {Composition} from 'remotion';
import {OrbinexoEyeLevelShort} from './OrbinexoEyeLevelShort';
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from './config';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="OrbinexoEyeLevelShort"
      component={OrbinexoEyeLevelShort}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};
