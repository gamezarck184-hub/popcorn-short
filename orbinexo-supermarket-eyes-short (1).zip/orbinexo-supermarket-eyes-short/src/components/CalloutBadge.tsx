import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FONT_FAMILY, PALETTE} from '../config';

export interface CalloutBadgeProps {
  text: string;
  x?: number;
  y?: number;
  tone?: 'green' | 'amber' | 'sky';
  enterFrame?: number;
}

export const CalloutBadge: React.FC<CalloutBadgeProps> = ({
  text,
  x = 540,
  y = 250,
  tone = 'green',
  enterFrame = 0,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const localFrame = Math.max(0, frame - enterFrame);

  const sp = spring({
    frame: localFrame,
    fps,
    config: {damping: 14, stiffness: 150},
  });

  const opacity = interpolate(localFrame, [0, 8], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const borderColor =
    tone === 'amber' ? PALETTE.amber : tone === 'sky' ? PALETTE.sky : PALETTE.accentGreen;

  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%, -50%) scale(${(0.85 + 0.15 * sp).toFixed(3)})`,
        opacity,
        backgroundColor: 'rgba(8, 12, 20, 0.92)',
        border: `3px solid ${borderColor}`,
        borderRadius: 18,
        padding: '14px 30px',
        fontFamily: FONT_FAMILY,
        fontWeight: 900,
        fontSize: 34,
        letterSpacing: '0.03em',
        color: PALETTE.white,
        textAlign: 'center',
        boxShadow: '0 14px 36px rgba(0, 0, 0, 0.55)',
        maxWidth: 940,
      }}
    >
      {text}
    </div>
  );
};
