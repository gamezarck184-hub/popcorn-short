import React from 'react';
import {useCurrentFrame} from 'remotion';
import {FONT_FAMILY, PALETTE} from '../config';

export interface ProductItem {
  id: string;
  label: string;
  priceText: string;
  color: string;
  accentColor?: string;
  tier: 'top' | 'eye' | 'bottom';
  col: number; // 0..3
  isPremium?: boolean;
}

export const GONDOLA_PRODUCTS: ProductItem[] = [
  // Estante superior
  {id: 'top-1', label: 'CEREAL', priceText: '$6.50', color: '#0284C7', tier: 'top', col: 0},
  {id: 'top-2', label: 'GRANOLA', priceText: '$5.20', color: '#0EA5E9', tier: 'top', col: 1},
  {id: 'top-3', label: 'AVENA', priceText: '$2.40', color: '#38BDF8', tier: 'top', col: 2},
  {id: 'top-4', label: 'MIEL', priceText: '$7.10', color: '#0369A1', tier: 'top', col: 3},

  // Estante central (altura de los ojos)
  {id: 'eye-1', label: 'CAFÉ PRO', priceText: '$8.90', color: '#16A34A', tier: 'eye', col: 0, isPremium: true},
  {id: 'eye-2', label: 'ACEITE+', priceText: '$9.50', color: '#F59E0B', tier: 'eye', col: 1, isPremium: true},
  {id: 'eye-3', label: 'SALSA', priceText: '$6.80', color: '#EF4444', tier: 'eye', col: 2, isPremium: true},
  {id: 'eye-4', label: 'JUGO+', priceText: '$5.90', color: '#8B5CF6', tier: 'eye', col: 3, isPremium: true},

  // Estante inferior (alternativas económicas)
  {id: 'bot-1', label: 'CAFÉ', priceText: '$4.20', color: '#0D9488', tier: 'bottom', col: 0},
  {id: 'bot-2', label: 'ACEITE', priceText: '$4.90', color: '#D97706', tier: 'bottom', col: 1},
  {id: 'bot-3', label: 'SALSA', priceText: '$3.10', color: '#DC2626', tier: 'bottom', col: 2},
  {id: 'bot-4', label: 'JUGO', priceText: '$2.60', color: '#6366F1', tier: 'bottom', col: 3},
];

export interface PriceBadgeProps {
  x: number;
  y: number;
  priceText: string;
  tagText?: string;
  highlight?: boolean;
}

export const PriceBadge: React.FC<PriceBadgeProps> = ({
  x,
  y,
  priceText,
  tagText,
  highlight = false,
}) => {
  return (
    <g transform={`translate(${x}, ${y})`}>
      <rect
        x={-68}
        y={-32}
        width={136}
        height={tagText ? 60 : 44}
        rx={10}
        fill={PALETTE.white}
        stroke={highlight ? PALETTE.amber : PALETTE.ink}
        strokeWidth={highlight ? 4.5 : 3}
      />
      <text
        x={0}
        y={tagText ? -6 : 6}
        textAnchor="middle"
        fill={PALETTE.ink}
        fontFamily={FONT_FAMILY}
        fontWeight="900"
        fontSize="24"
      >
        {priceText}
      </text>
      {tagText && (
        <text
          x={0}
          y={18}
          textAnchor="middle"
          fill={PALETTE.sweaterGreenDark}
          fontFamily={FONT_FAMILY}
          fontWeight="800"
          fontSize="13"
        >
          {tagText}
        </text>
      )}
    </g>
  );
};

export interface GondolaProps {
  x: number;
  y: number;
  width?: number;
  height?: number;
  focusedTier?: 'top' | 'eye' | 'bottom' | null;
  blurOtherTiers?: boolean;
  spotlightCol?: number | null;
  showPrices?: boolean;
  reservedSlotCol?: number | null;
  hiddenProductIds?: string[];
}

export const Gondola: React.FC<GondolaProps> = ({
  x,
  y,
  width = 860,
  height = 820,
  focusedTier = null,
  blurOtherTiers = false,
  spotlightCol = null,
  showPrices = false,
  reservedSlotCol = null,
  hiddenProductIds = [],
}) => {
  const frame = useCurrentFrame();
  const tiers: Array<{key: 'top' | 'eye' | 'bottom'; ratio: number; label: string}> = [
    {key: 'top', ratio: 0.25, label: 'SUPERIOR'},
    {key: 'eye', ratio: 0.58, label: 'ALTURA DE OJOS'},
    {key: 'bottom', ratio: 0.9, label: 'INFERIOR'},
  ];

  const colSpacing = (width - 140) / 3.2;

  return (
    <g transform={`translate(${x - width / 2}, ${y - height})`}>
      {/* Cuerpo de góndola */}
      <rect
        x={0}
        y={0}
        width={width}
        height={height}
        rx={18}
        fill={PALETTE.shelfBody}
        stroke={PALETTE.shelfEdge}
        strokeWidth={5}
      />

      {tiers.map((t) => {
        const shelfY = height * t.ratio;
        const isFocused = focusedTier === t.key;
        const isDimmed = blurOtherTiers && focusedTier !== null && !isFocused;
        const tierProducts = GONDOLA_PRODUCTS.filter((p) => p.tier === t.key);

        return (
          <g key={t.key} opacity={isDimmed ? 0.36 : 1}>
            {isFocused && (
              <rect
                x={14}
                y={shelfY - 126}
                width={width - 28}
                height={142}
                rx={12}
                fill="rgba(34, 197, 94, 0.14)"
                stroke={PALETTE.accentGreen}
                strokeWidth={4}
              />
            )}

            {/* Tabla del estante */}
            <rect
              x={20}
              y={shelfY}
              width={width - 40}
              height={16}
              rx={5}
              fill={isFocused ? PALETTE.accentGreen : PALETTE.shelfEdge}
            />

            {/* Etiqueta lateral de nivel */}
            <text
              x={width - 34}
              y={shelfY - 102}
              textAnchor="end"
              fill={isFocused ? PALETTE.mintGlow : PALETTE.greyLight}
              fontFamily={FONT_FAMILY}
              fontWeight="800"
              fontSize="16"
            >
              {t.label}
            </text>

            {tierProducts.map((prod) => {
              if (hiddenProductIds.includes(prod.id)) return null;
              const px = 72 + prod.col * colSpacing;
              const py = shelfY - 82;
              const isSpot = isFocused && spotlightCol === prod.col;
              const pulse = isSpot ? 1 + Math.sin(frame * 0.25) * 0.06 : 1;
              const isReserved = t.key === 'eye' && reservedSlotCol === prod.col;

              return (
                <g key={prod.id} transform={`translate(${px}, ${py}) scale(${pulse})`}>
                  {isSpot && (
                    <circle
                      cx={36}
                      cy={40}
                      r={56}
                      fill="rgba(74, 222, 128, 0.22)"
                    />
                  )}
                  <rect
                    x={0}
                    y={0}
                    width={72}
                    height={78}
                    rx={10}
                    fill={prod.color}
                    stroke={isSpot ? PALETTE.mintGlow : PALETTE.ink}
                    strokeWidth={isSpot ? 4.5 : 3.5}
                  />
                  <rect x={11} y={14} width={50} height={14} rx={4} fill="rgba(255,255,255,0.82)" />
                  <text
                    x={36}
                    y={52}
                    textAnchor="middle"
                    fill={PALETTE.white}
                    fontFamily={FONT_FAMILY}
                    fontWeight="900"
                    fontSize="13"
                  >
                    {prod.label}
                  </text>

                  {isReserved && (
                    <g transform="translate(36, -18)">
                      <rect
                        x={-52}
                        y={-15}
                        width={104}
                        height={26}
                        rx={6}
                        fill={PALETTE.amber}
                        stroke={PALETTE.ink}
                        strokeWidth={2.5}
                      />
                      <text
                        x={0}
                        y={3}
                        textAnchor="middle"
                        fill={PALETTE.ink}
                        fontFamily={FONT_FAMILY}
                        fontWeight="900"
                        fontSize="12"
                      >
                        RESERVADO
                      </text>
                    </g>
                  )}

                  {showPrices && (
                    <PriceBadge
                      x={36}
                      y={-28}
                      priceText={prod.priceText}
                      highlight={Boolean(prod.isPremium)}
                    />
                  )}
                </g>
              );
            })}
          </g>
        );
      })}
    </g>
  );
};
