import React from 'react';
import {useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';

export type StickmanAction =
  | 'walk'
  | 'idle'
  | 'look_eye'
  | 'look_up'
  | 'look_down'
  | 'crouch'
  | 'reach_eye'
  | 'reach_down'
  | 'reach_cart'
  | 'surprised'
  | 'point_up_down';

export interface StickmanProps {
  x: number;
  y: number;
  scale?: number;
  flipX?: boolean;
  action?: StickmanAction;
  actionProgress?: number;
  lookTarget?: {dx: number; dy: number};
  holdingItemColor?: string;
}

export const Stickman: React.FC<StickmanProps> = ({
  x,
  y,
  scale = 1,
  flipX = false,
  action = 'walk',
  actionProgress = 0.5,
  lookTarget = {dx: 0.7, dy: 0},
  holdingItemColor,
}) => {
  const frame = useCurrentFrame();
  const isWalking = action === 'walk';
  const phase = frame * 0.26;
  const stride = isWalking ? Math.sin(phase) : 0;
  const walkBounce = isWalking ? Math.abs(Math.cos(phase)) * 7 : Math.sin(frame * 0.11) * 2;
  const crouchDrop = action === 'crouch' ? 68 * Math.sin(Math.min(1, actionProgress) * Math.PI * 0.5) : 0;
  const breath = Math.sin(frame * 0.13) * 2.5;

  const blink = frame % 108 > 103 ? 0.15 : 1;
  const effectiveLookDy =
    action === 'look_up' || action === 'point_up_down'
      ? -0.85
      : action === 'look_down' || action === 'crouch' || action === 'reach_down'
      ? 0.85
      : lookTarget.dy;
  const pupilX = Math.max(-1, Math.min(1, lookTarget.dx)) * 5;
  const pupilY = Math.max(-1, Math.min(1, effectiveLookDy)) * 4.5;

  const hipY = -105 + crouchDrop * 0.65;
  const shoulderY = -212 + crouchDrop + breath;
  const headY = -286 + crouchDrop + breath;

  const leftFootX = -22 + stride * 32;
  const rightFootX = 22 - stride * 32;
  const leftKneeX = -24 + stride * 16;
  const rightKneeX = 24 - stride * 16;

  // Brazo derecho según acción
  let handR = {x: 62, y: shoulderY + 66};
  let elbowR = {x: 48, y: shoulderY + 34};

  if (action === 'reach_eye') {
    const ext = Math.sin(Math.min(1, actionProgress) * Math.PI);
    handR = {x: 56 + ext * 76, y: shoulderY - 12};
    elbowR = {x: 46 + ext * 38, y: shoulderY + 12};
  } else if (action === 'reach_down' || action === 'crouch') {
    handR = {x: 68, y: 12};
    elbowR = {x: 52, y: shoulderY + 75};
  } else if (action === 'reach_cart') {
    const arc = Math.sin(Math.min(1, actionProgress) * Math.PI);
    handR = {x: 74 + arc * 44, y: shoulderY + 18 + arc * 48};
    elbowR = {x: 56 + arc * 22, y: shoulderY + 24};
  } else if (action === 'point_up_down') {
    const dir = Math.sin(frame * 0.14) >= 0 ? -1 : 1;
    handR = {x: 84, y: shoulderY + dir * 72};
    elbowR = {x: 54, y: shoulderY + dir * 34};
  } else {
    handR = {x: 56 - stride * 18, y: shoulderY + 84};
    elbowR = {x: 48 - stride * 10, y: shoulderY + 42};
  }

  // Brazo izquierdo
  const handL =
    action === 'point_up_down'
      ? {x: -78, y: shoulderY - 68}
      : action === 'reach_down'
      ? {x: -44, y: 18}
      : {x: -56 + stride * 18, y: shoulderY + 84};
  const elbowL = {x: -46 + stride * 10, y: shoulderY + 42};

  const totalY = y - walkBounce;

  return (
    <g transform={`translate(${x}, ${totalY}) scale(${flipX ? -scale : scale}, ${scale})`}>
      <ellipse cx={0} cy={walkBounce} rx={62} ry={12} fill="rgba(0,0,0,0.42)" />

      {/* Piernas negras */}
      <polyline
        points={`-20,${hipY} ${leftKneeX},${(hipY + walkBounce) / 2} ${leftFootX},${walkBounce}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={15}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polyline
        points={`20,${hipY} ${rightKneeX},${(hipY + walkBounce) / 2} ${rightFootX},${walkBounce}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={15}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Brazo izquierdo */}
      <polyline
        points={`-40,${shoulderY + 8} ${elbowL.x},${elbowL.y} ${handL.x},${handL.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={13}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Sudadera verde */}
      <path
        d={`M -42 ${shoulderY - 8}
            Q 0 ${shoulderY - 18} 42 ${shoulderY - 8}
            L 48 ${hipY + 8}
            Q 0 ${hipY + 15} -48 ${hipY + 8} Z`}
        fill={PALETTE.sweaterGreen}
        stroke={PALETTE.ink}
        strokeWidth={4.5}
      />
      {/* Capucha / cuello de la sudadera */}
      <path
        d={`M -20 ${shoulderY - 8} Q 0 ${shoulderY + 14} 20 ${shoulderY - 8}`}
        fill="none"
        stroke={PALETTE.sweaterGreenDark}
        strokeWidth={5.5}
        strokeLinecap="round"
      />

      {/* Brazo derecho */}
      <polyline
        points={`40,${shoulderY + 8} ${elbowR.x},${elbowR.y} ${handR.x},${handR.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={13}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line
        x1={40}
        y1={shoulderY + 8}
        x2={elbowR.x}
        y2={elbowR.y}
        stroke={PALETTE.sweaterGreen}
        strokeWidth={18}
        strokeLinecap="round"
      />

      {/* Producto sostenido en la mano */}
      {holdingItemColor && (
        <g transform={`translate(${handR.x + 8}, ${handR.y - 16})`}>
          <rect
            x={-16}
            y={-22}
            width={32}
            height={42}
            rx={6}
            fill={holdingItemColor}
            stroke={PALETTE.ink}
            strokeWidth={3.5}
          />
          <rect x={-10} y={-12} width={20} height={8} rx={2} fill="rgba(255,255,255,0.75)" />
        </g>
      )}

      {/* Cabeza circular blanca sin cabello */}
      <circle
        cx={0}
        cy={headY}
        r={54}
        fill={PALETTE.white}
        stroke={PALETTE.ink}
        strokeWidth={5}
      />

      {/* Cejas y ojos */}
      <line
        x1={-26 + pupilX * 0.5}
        y1={headY - 22 + (action === 'surprised' ? -5 : 0)}
        x2={-9 + pupilX * 0.5}
        y2={headY - 23}
        stroke={PALETTE.ink}
        strokeWidth={4}
        strokeLinecap="round"
      />
      <line
        x1={9 + pupilX * 0.5}
        y1={headY - 23}
        x2={26 + pupilX * 0.5}
        y2={headY - 22 + (action === 'surprised' ? -5 : 0)}
        stroke={PALETTE.ink}
        strokeWidth={4}
        strokeLinecap="round"
      />
      <ellipse
        cx={-16 + pupilX}
        cy={headY - 7 + pupilY}
        rx={action === 'surprised' ? 6.5 : 5.2}
        ry={7.5 * blink}
        fill={PALETTE.ink}
      />
      <ellipse
        cx={16 + pupilX}
        cy={headY - 7 + pupilY}
        rx={action === 'surprised' ? 6.5 : 5.2}
        ry={7.5 * blink}
        fill={PALETTE.ink}
      />

      {/* Expresión bucal */}
      {action === 'surprised' ? (
        <ellipse cx={0} cy={headY + 18} rx={9} ry={12} fill={PALETTE.ink} />
      ) : (
        <line
          x1={-12}
          y1={headY + 17}
          x2={12}
          y2={headY + 17}
          stroke={PALETTE.ink}
          strokeWidth={4.2}
          strokeLinecap="round"
        />
      )}
    </g>
  );
};
