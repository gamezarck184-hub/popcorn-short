import React from 'react';
import {useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';

export interface CartItemSpec {
  color: string;
  label?: string;
}

export interface CartProps {
  x: number;
  y: number;
  scale?: number;
  items?: CartItemSpec[];
  rolling?: boolean;
}

export const Cart: React.FC<CartProps> = ({
  x,
  y,
  scale = 1,
  items = [],
  rolling = true,
}) => {
  const frame = useCurrentFrame();
  const wheelAngle = rolling ? frame * 14 : 0;
  const rattleY = rolling ? Math.sin(frame * 0.9) * 2 : 0;

  const slots = [
    {dx: -54, dy: -102, w: 30, h: 48},
    {dx: -20, dy: -96, w: 36, h: 42},
    {dx: 22, dy: -100, w: 32, h: 46},
    {dx: -44, dy: -130, w: 34, h: 32},
    {dx: -6, dy: -134, w: 36, h: 36},
    {dx: 32, dy: -128, w: 30, h: 32},
  ];

  return (
    <g transform={`translate(${x}, ${y + rattleY}) scale(${scale})`}>
      <ellipse cx={0} cy={6} rx={88} ry={12} fill="rgba(0,0,0,0.4)" />

      {items.slice(0, slots.length).map((it, i) => {
        const s = slots[i];
        return (
          <rect
            key={i}
            x={s.dx}
            y={s.dy}
            width={s.w}
            height={s.h}
            rx={6}
            fill={it.color}
            stroke={PALETTE.ink}
            strokeWidth={3.5}
          />
        );
      })}

      {/* Canasta metálica */}
      <polygon
        points="-72,-110 64,-110 46,-46 -50,-46"
        fill="rgba(226, 232, 240, 0.28)"
        stroke="#94A3B8"
        strokeWidth={5.5}
        strokeLinejoin="round"
      />
      <line x1="-62" y1="-86" x2="56" y2="-86" stroke="#CBD5E1" strokeWidth={3} />
      <line x1="-26" y1="-110" x2="-20" y2="-46" stroke="#CBD5E1" strokeWidth={3} />
      <line x1="16" y1="-110" x2="12" y2="-46" stroke="#CBD5E1" strokeWidth={3} />

      {/* Manillar */}
      <polyline
        points="-72,-110 -92,-128 -106,-128"
        fill="none"
        stroke="#475569"
        strokeWidth={6.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line x1="-50" y1="-30" x2="48" y2="-30" stroke="#475569" strokeWidth={5.5} />

      {/* Ruedas */}
      {[-38, 38].map((wx, idx) => (
        <g key={idx} transform={`translate(${wx}, -14) rotate(${wheelAngle})`}>
          <circle cx={0} cy={0} r={14} fill="#0F172A" stroke="#64748B" strokeWidth={4} />
          <line x1={-10} y1={0} x2={10} y2={0} stroke="#CBD5E1" strokeWidth={2.5} />
          <line x1={0} y1={-10} x2={0} y2={10} stroke="#CBD5E1" strokeWidth={2.5} />
        </g>
      ))}
    </g>
  );
};
