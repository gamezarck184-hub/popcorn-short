import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {HEIGHT, WIDTH} from '../config';

export interface CameraKeyframe {
  x: number;
  y: number;
  zoom: number;
}

export interface CameraRigProps {
  from: CameraKeyframe;
  to: CameraKeyframe;
  durationInFrames: number;
  shakeIntensity?: number;
  children: React.ReactNode;
}

export const CameraRig: React.FC<CameraRigProps> = ({
  from,
  to,
  durationInFrames,
  shakeIntensity = 0,
  children,
}) => {
  const frame = useCurrentFrame();
  const t = interpolate(frame, [0, Math.max(1, durationInFrames)], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  // Suavizado continuo en S para movimientos de cámara naturales
  const eased = t * t * (3 - 2 * t);

  const camX = interpolate(eased, [0, 1], [from.x, to.x]);
  const camY = interpolate(eased, [0, 1], [from.y, to.y]);
  const zoom = interpolate(eased, [0, 1], [from.zoom, to.zoom]);

  const microX = shakeIntensity > 0 ? Math.sin(frame * 0.7) * shakeIntensity : 0;
  const microY = shakeIntensity > 0 ? Math.cos(frame * 0.55) * shakeIntensity * 0.6 : 0;

  return (
    <div
      style={{
        width: WIDTH,
        height: HEIGHT,
        overflow: 'hidden',
        position: 'relative',
        transform: `translate3d(${(camX + microX).toFixed(2)}px, ${(camY + microY).toFixed(2)}px, 0) scale(${zoom.toFixed(4)})`,
        transformOrigin: '540px 960px',
      }}
    >
      {children}
    </div>
  );
};
