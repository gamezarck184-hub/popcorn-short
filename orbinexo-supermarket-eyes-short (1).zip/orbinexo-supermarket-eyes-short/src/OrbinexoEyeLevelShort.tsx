import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {
  NARRATION_AUDIO_FILE,
  PALETTE,
  TOTAL_FRAMES,
  secToFrame,
} from './config';
import {Scene01Entrance} from './scenes/Scene01Entrance';
import {Scene02EyeLevel} from './scenes/Scene02EyeLevel';
import {Scene03PrimeSpots} from './scenes/Scene03PrimeSpots';
import {Scene04EconomicOptions} from './scenes/Scene04EconomicOptions';
import {Scene05Psychology} from './scenes/Scene05Psychology';
import {Scene06Discovery} from './scenes/Scene06Discovery';
import {Scene07Closing} from './scenes/Scene07Closing';

export const OrbinexoEyeLevelShort: React.FC = () => {
  const frame = useCurrentFrame();

  const s1 = secToFrame(0);
  const s2 = secToFrame(6);
  const s3 = secToFrame(13);
  const s4 = secToFrame(22);
  const s5 = secToFrame(32);
  const s6 = secToFrame(43);
  const s7 = secToFrame(55);

  const narrationGain =
    interpolate(frame, [0, 8], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) *
    interpolate(frame, [TOTAL_FRAMES - 12, TOTAL_FRAMES], [1, 0], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    });

  const musicGain =
    interpolate(frame, [0, 24], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) *
    interpolate(frame, [TOTAL_FRAMES - 30, TOTAL_FRAMES], [1, 0], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    });

  const ambienceGain =
    interpolate(frame, [0, 24], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) *
    interpolate(frame, [TOTAL_FRAMES - 24, TOTAL_FRAMES], [1, 0], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    });

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgNavy}}>
      {/* Narración principal */}
      {NARRATION_AUDIO_FILE && (
        <Sequence from={0} durationInFrames={TOTAL_FRAMES}>
          <Audio
            src={staticFile(`audio/${NARRATION_AUDIO_FILE}`)}
            volume={1.0 * narrationGain}
          />
        </Sequence>
      )}

      {/* Música de fondo dinámica por debajo de la voz */}
      <Sequence from={0} durationInFrames={TOTAL_FRAMES}>
        <Audio
          src={staticFile('audio/bg-music.wav')}
          volume={0.18 * musicGain}
        />
      </Sequence>

      {/* Ambiente suave de supermercado a volumen discreto */}
      <Sequence from={0} durationInFrames={TOTAL_FRAMES}>
        <Audio
          src={staticFile('audio/sfx/ambience.wav')}
          volume={0.09 * ambienceGain}
        />
      </Sequence>

      {/* Escena 1: 0–6s */}
      <Sequence from={s1} durationInFrames={s2 - s1} name="Scene01Entrance">
        <Scene01Entrance />
      </Sequence>
      <Sequence from={s1 + 2} durationInFrames={22}>
        <Audio src={staticFile('audio/sfx/cart-wheels.wav')} volume={0.22} />
      </Sequence>
      <Sequence from={s1 + 12} durationInFrames={16}>
        <Audio src={staticFile('audio/sfx/auto-doors.wav')} volume={0.2} />
      </Sequence>

      {/* Escena 2: 6–13s */}
      <Sequence from={s2} durationInFrames={s3 - s2} name="Scene02EyeLevel">
        <Scene02EyeLevel />
      </Sequence>
      <Sequence from={s2} durationInFrames={10}>
        <Audio src={staticFile('audio/sfx/transition.wav')} volume={0.16} />
      </Sequence>
      <Sequence from={s2 + 88} durationInFrames={16}>
        <Audio src={staticFile('audio/sfx/discovery.wav')} volume={0.2} />
      </Sequence>

      {/* Escena 3: 13–22s */}
      <Sequence from={s3} durationInFrames={s4 - s3} name="Scene03PrimeSpots">
        <Scene03PrimeSpots />
      </Sequence>
      <Sequence from={s3} durationInFrames={10}>
        <Audio src={staticFile('audio/sfx/transition.wav')} volume={0.16} />
      </Sequence>
      <Sequence from={s3 + 120} durationInFrames={16}>
        <Audio src={staticFile('audio/sfx/discovery.wav')} volume={0.18} />
      </Sequence>

      {/* Escena 4: 22–32s */}
      <Sequence from={s4} durationInFrames={s5 - s4} name="Scene04EconomicOptions">
        <Scene04EconomicOptions />
      </Sequence>
      <Sequence from={s4} durationInFrames={10}>
        <Audio src={staticFile('audio/sfx/transition.wav')} volume={0.16} />
      </Sequence>
      <Sequence from={s4 + 38} durationInFrames={8}>
        <Audio src={staticFile('audio/sfx/item-pop.wav')} volume={0.22} />
      </Sequence>

      {/* Escena 5: 32–43s */}
      <Sequence from={s5} durationInFrames={s6 - s5} name="Scene05Psychology">
        <Scene05Psychology />
      </Sequence>
      <Sequence from={s5} durationInFrames={10}>
        <Audio src={staticFile('audio/sfx/transition.wav')} volume={0.16} />
      </Sequence>
      <Sequence from={s5 + 285} durationInFrames={8}>
        <Audio src={staticFile('audio/sfx/item-pop.wav')} volume={0.24} />
      </Sequence>

      {/* Escena 6: 43–55s */}
      <Sequence from={s6} durationInFrames={s7 - s6} name="Scene06Discovery">
        <Scene06Discovery />
      </Sequence>
      <Sequence from={s6} durationInFrames={10}>
        <Audio src={staticFile('audio/sfx/transition.wav')} volume={0.16} />
      </Sequence>
      <Sequence from={s6 + 150} durationInFrames={16}>
        <Audio src={staticFile('audio/sfx/discovery.wav')} volume={0.22} />
      </Sequence>

      {/* Escena 7: 55–59s (cubre íntegramente los ~58,83s de narración) */}
      <Sequence from={s7} durationInFrames={TOTAL_FRAMES - s7} name="Scene07Closing">
        <Scene07Closing />
      </Sequence>
      <Sequence from={s7} durationInFrames={10}>
        <Audio src={staticFile('audio/sfx/transition.wav')} volume={0.16} />
      </Sequence>
    </AbsoluteFill>
  );
};
