import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, FONT_FAMILY, HEIGHT, PALETTE, WIDTH} from '../config';
import {CameraRig} from '../components/CameraRig';
import {Stickman} from '../components/Stickman';
import {Gondola} from '../components/Gondola';
import {CalloutBadge} from '../components/CalloutBadge';

export const Scene03PrimeSpots: React.FC = () => {
  const frame = useCurrentFrame(); // 0..269 (9s)
  const inMeeting = frame >= 85 && frame < 195;
  const reservedProg = interpolate(frame, [115, 175], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgNavy}}>
      <CameraRig
        from={{x: 0, y: 0, zoom: 1.04}}
        to={{x: -25, y: -30, zoom: 1.12}}
        durationInFrames={270}
      >
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
          <rect width={WIDTH} height={HEIGHT} fill={PALETTE.wallSlate} />
          <rect x={0} y={FLOOR_Y} width={WIDTH} height={HEIGHT - FLOOR_Y} fill={PALETTE.floorMain} />

          {!inMeeting ? (
            <>
              <Gondola
                x={540}
                y={FLOOR_Y - 20}
                width={780}
                height={760}
                focusedTier="eye"
                spotlightCol={1}
                reservedSlotCol={frame >= 195 ? 1 : null}
              />
              <Stickman
                x={185}
                y={FLOOR_Y}
                scale={0.95}
                action="look_eye"
                lookTarget={{dx: 1, dy: 0}}
              />
            </>
          ) : (
            <g transform="translate(540, 920)">
              {/* Sala de reunión comercial con esquema de góndola */}
              <rect
                x={-440}
                y={-520}
                width={880}
                height={920}
                rx={24}
                fill="#13233A"
                stroke={PALETTE.sky}
                strokeWidth={4}
              />
              <text
                x={0}
                y={-455}
                textAnchor="middle"
                fill={PALETTE.white}
                fontFamily={FONT_FAMILY}
                fontWeight="900"
                fontSize="28"
              >
                ESQUEMA DE GÓNDOLA — ESPACIO CENTRAL
              </text>

              {/* Diagrama de estantes */}
              {[-240, -60, 120].map((sy, idx) => (
                <g key={idx}>
                  <rect x={-320} y={sy} width={640} height={90} rx={10} fill="#1E3352" stroke="#64748B" strokeWidth={3} />
                  {idx === 1 && (
                    <rect
                      x={-80}
                      y={sy + 8}
                      width={160}
                      height={74}
                      rx={8}
                      fill="rgba(245, 158, 11, 0.25)"
                      stroke={PALETTE.amber}
                      strokeWidth={4}
                    />
                  )}
                </g>
              ))}

              {/* Etiqueta de reserva colocándose en posición central */}
              <g
                transform={`translate(0, ${interpolate(reservedProg, [0, 1], [-190, -15])})`}
                opacity={interpolate(reservedProg, [0, 0.2], [0, 1], {
                  extrapolateLeft: 'clamp',
                  extrapolateRight: 'clamp',
                })}
              >
                <rect
                  x={-130}
                  y={-24}
                  width={260}
                  height={48}
                  rx={10}
                  fill={PALETTE.amber}
                  stroke={PALETTE.ink}
                  strokeWidth={3.5}
                />
                <text
                  x={0}
                  y={8}
                  textAnchor="middle"
                  fill={PALETTE.ink}
                  fontFamily={FONT_FAMILY}
                  fontWeight="900"
                  fontSize="20"
                >
                  ESPACIO RESERVADO
                </text>
              </g>

              {/* Dos personas observando el esquema */}
              <Stickman x={-210} y={390} scale={0.78} action="look_eye" lookTarget={{dx: 0.6, dy: -0.6}} />
              <Stickman x={220} y={390} scale={0.78} flipX={true} action="reach_eye" actionProgress={reservedProg} lookTarget={{dx: 0.6, dy: -0.6}} />
            </g>
          )}
        </svg>

        <CalloutBadge
          text="LOS LUGARES MÁS VISIBLES TIENEN VALOR"
          x={540}
          y={220}
          tone="amber"
          enterFrame={15}
        />
      </CameraRig>
    </AbsoluteFill>
  );
};
