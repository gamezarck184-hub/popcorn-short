import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, FONT_FAMILY, HEIGHT, PALETTE, WIDTH} from '../config';
import {CameraRig} from '../components/CameraRig';
import {Stickman} from '../components/Stickman';
import {Cart} from '../components/Cart';
import {CalloutBadge} from '../components/CalloutBadge';

export const Scene05Psychology: React.FC = () => {
  const frame = useCurrentFrame(); // 0..329 (11s)
  const focusProgress = interpolate(frame, [20, 95], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const placeInCartProg = interpolate(frame, [215, 295], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const itemPlaced = frame >= 285;
  const sideBlur = interpolate(focusProgress, [0, 1], [0, 5]);
  const sideOpacity = interpolate(focusProgress, [0, 1], [1, 0.45]);

  return (
    <AbsoluteFill style={{backgroundColor: '#050A12'}}>
      <CameraRig
        from={{x: 0, y: 0, zoom: 1.03}}
        to={{x: -20, y: -80, zoom: 1.15}}
        durationInFrames={330}
      >
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
          <rect width={WIDTH} height={HEIGHT} fill="#08111E" />
          <rect x={0} y={FLOOR_Y} width={WIDTH} height={HEIGHT - FLOOR_Y} fill="#132033" />

          {/* Haz de foco hacia el producto central */}
          <polygon
            points="690,520 560,1150 820,1150"
            fill="rgba(74, 222, 128, 0.14)"
          />

          {/* Producto izquierdo desenfocado */}
          <g
            transform="translate(460, 890)"
            style={{filter: `blur(${sideBlur.toFixed(1)}px)`, opacity: sideOpacity}}
          >
            <rect x={-48} y={-55} width={96} height={110} rx={14} fill="#0284C7" stroke={PALETTE.ink} strokeWidth={4} />
            <text x={0} y={8} textAnchor="middle" fill={PALETTE.white} fontFamily={FONT_FAMILY} fontWeight="800" fontSize="18">
              OPCIÓN A
            </text>
          </g>

          {/* Producto derecho desenfocado */}
          <g
            transform="translate(920, 890)"
            style={{filter: `blur(${sideBlur.toFixed(1)}px)`, opacity: sideOpacity}}
          >
            <rect x={-48} y={-55} width={96} height={110} rx={14} fill="#8B5CF6" stroke={PALETTE.ink} strokeWidth={4} />
            <text x={0} y={8} textAnchor="middle" fill={PALETTE.white} fontFamily={FONT_FAMILY} fontWeight="800" fontSize="18">
              OPCIÓN C
            </text>
          </g>

          {/* Producto central enfocado */}
          {!itemPlaced && (
            <g
              transform={`translate(${interpolate(placeInCartProg, [0, 1], [690, 440])}, ${interpolate(
                placeInCartProg,
                [0, 1],
                [890, FLOOR_Y - 125]
              )})`}
            >
              <circle cx={0} cy={0} r={82} fill="rgba(34, 197, 94, 0.22)" />
              <rect
                x={-54}
                y={-62}
                width={108}
                height={124}
                rx={16}
                fill={PALETTE.accentGreen}
                stroke={PALETTE.white}
                strokeWidth={4.5}
              />
              <text x={0} y={8} textAnchor="middle" fill={PALETTE.ink} fontFamily={FONT_FAMILY} fontWeight="900" fontSize="20">
                VISIBLE
              </text>
            </g>
          )}

          {/* Trayectoria visual desde los ojos hasta el producto central */}
          <line
            x1={255}
            y1={FLOOR_Y - 312}
            x2={640}
            y2={890}
            stroke={PALETTE.mintGlow}
            strokeWidth={6}
            strokeDasharray="14 10"
            opacity={0.85}
          />

          <Stickman
            x={245}
            y={FLOOR_Y}
            scale={1.04}
            action={frame >= 200 ? 'reach_cart' : 'look_eye'}
            actionProgress={placeInCartProg}
            lookTarget={{dx: 1, dy: -0.15}}
          />

          <Cart
            x={440}
            y={FLOOR_Y}
            scale={0.98}
            items={
              itemPlaced
                ? [{color: PALETTE.sky}, {color: PALETTE.amber}, {color: PALETTE.accentGreen}]
                : [{color: PALETTE.sky}, {color: PALETTE.amber}]
            }
            rolling={false}
          />
        </svg>

        <CalloutBadge
          text="MÁS VISIBILIDAD = MÁS ATENCIÓN"
          x={540}
          y={220}
          tone="green"
          enterFrame={15}
        />
      </CameraRig>
    </AbsoluteFill>
  );
};
