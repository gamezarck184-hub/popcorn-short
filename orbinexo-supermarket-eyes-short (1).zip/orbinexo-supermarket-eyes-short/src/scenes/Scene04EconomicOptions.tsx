import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, FONT_FAMILY, HEIGHT, PALETTE, WIDTH} from '../config';
import {CameraRig} from '../components/CameraRig';
import {Stickman} from '../components/Stickman';
import {Gondola} from '../components/Gondola';
import {CalloutBadge} from '../components/CalloutBadge';

export const Scene04EconomicOptions: React.FC = () => {
  const frame = useCurrentFrame(); // 0..299 (10s)
  const reachProg = interpolate(frame, [10, 65], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const crouchProg = interpolate(frame, [130, 215], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const isCrouching = frame >= 130 && frame < 235;
  const hiddenIds = frame >= 38 && frame < 245 ? ['eye-1'] : [];
  const holdingColor = frame >= 38 && frame < 245 ? '#16A34A' : undefined;

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgNavy}}>
      <CameraRig
        from={{x: -35, y: -150, zoom: 1.24}}
        to={{x: 0, y: 0, zoom: 1.03}}
        durationInFrames={300}
      >
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
          <rect width={WIDTH} height={HEIGHT} fill={PALETTE.wallSlate} />
          <rect x={0} y={FLOOR_Y} width={WIDTH} height={HEIGHT - FLOOR_Y} fill={PALETTE.floorMain} />

          <Gondola
            x={640}
            y={FLOOR_Y - 15}
            width={620}
            height={780}
            focusedTier={isCrouching ? 'bottom' : 'eye'}
            spotlightCol={0}
            showPrices={frame >= 80}
            hiddenProductIds={hiddenIds}
          />

          {/* Líneas horizontales que dividen visualmente las tres alturas */}
          {[0.25, 0.58, 0.9].map((ratio, idx) => (
            <line
              key={idx}
              x1={60}
              y1={FLOOR_Y - 15 - 780 * (1 - ratio)}
              x2={1020}
              y2={FLOOR_Y - 15 - 780 * (1 - ratio)}
              stroke="rgba(248, 250, 252, 0.14)"
              strokeWidth={2.5}
              strokeDasharray="10 10"
            />
          ))}

          <Stickman
            x={215}
            y={FLOOR_Y}
            scale={1.0}
            action={isCrouching ? 'crouch' : frame < 75 ? 'reach_eye' : 'idle'}
            actionProgress={isCrouching ? crouchProg : reachProg}
            holdingItemColor={holdingColor}
            lookTarget={{dx: 1, dy: isCrouching ? 0.7 : 0}}
          />

          {/* Comparación de precios ficticios en dólares */}
          {frame >= 185 && (
            <g transform="translate(540, 1340)">
              <rect
                x={-370}
                y={-42}
                width={740}
                height={76}
                rx={14}
                fill="rgba(8, 12, 20, 0.92)"
                stroke={PALETTE.accentGreen}
                strokeWidth={3.5}
              />
              <text
                x={0}
                y={6}
                textAnchor="middle"
                fill={PALETTE.white}
                fontFamily={FONT_FAMILY}
                fontWeight="800"
                fontSize="24"
              >
                CENTRAL: $8.90  VS.  INFERIOR: $4.20 (EJEMPLO)
              </text>
            </g>
          )}
        </svg>

        <CalloutBadge text="ESTANTE CENTRAL" x={540} y={180} tone="green" enterFrame={10} />
        {frame >= 115 && (
          <CalloutBadge text="ESTANTE INFERIOR" x={540} y={275} tone="sky" enterFrame={115} />
        )}
        {frame >= 185 && (
          <CalloutBadge text="COMPARÁ LOS PRECIOS" x={540} y={370} tone="amber" enterFrame={185} />
        )}
      </CameraRig>
    </AbsoluteFill>
  );
};
