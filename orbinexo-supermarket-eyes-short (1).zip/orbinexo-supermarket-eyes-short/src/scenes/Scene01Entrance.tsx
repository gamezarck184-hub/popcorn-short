import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, FONT_FAMILY, HEIGHT, PALETTE, WIDTH} from '../config';
import {CameraRig} from '../components/CameraRig';
import {Stickman} from '../components/Stickman';
import {Cart} from '../components/Cart';
import {Gondola} from '../components/Gondola';
import {CalloutBadge} from '../components/CalloutBadge';

export const Scene01Entrance: React.FC = () => {
  const frame = useCurrentFrame(); // 0..179 (6s)
  const doorOpen = interpolate(frame, [10, 48], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const cartX = interpolate(frame, [0, 95, 179], [280, 560, 650], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const cartScale = interpolate(frame, [0, 55, 179], [1.45, 1.05, 0.95], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const stickmanX = interpolate(frame, [38, 179], [160, 460], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const spotIdx = Math.floor(frame / 28) % 4;
  const flashOpacity = 0.45 + 0.45 * Math.sin(frame * 0.35);

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgNavy}}>
      <CameraRig
        from={{x: 0, y: 0, zoom: 1.06}}
        to={{x: -55, y: -25, zoom: 1.14}}
        durationInFrames={180}
      >
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
          <rect width={WIDTH} height={HEIGHT} fill={PALETTE.wallSlate} />

          {/* Perspectiva de pasillo y góndolas a ambos lados */}
          <polygon points="0,540 310,780 310,1430 0,1620" fill={PALETTE.aisleMid} />
          <polygon points="1080,540 770,780 770,1430 1080,1620" fill={PALETTE.aisleMid} />

          {/* Piso del supermercado */}
          <rect x={0} y={FLOOR_Y} width={WIDTH} height={HEIGHT - FLOOR_Y} fill={PALETTE.floorMain} />
          <line x1={0} y1={FLOOR_Y} x2={WIDTH} y2={FLOOR_Y} stroke={PALETTE.floorLine} strokeWidth={5} />

          {/* Luces comerciales en techo */}
          {[220, 540, 860].map((lx, i) => (
            <g key={i}>
              <polygon
                points={`${lx - 60},160 ${lx + 60},160 ${lx + 190},${FLOOR_Y} ${lx - 190},${FLOOR_Y}`}
                fill="rgba(248, 250, 252, 0.045)"
              />
              <rect x={lx - 65} y={145} width={130} height={14} rx={6} fill={PALETTE.white} />
            </g>
          ))}

          {/* Góndola principal de destino */}
          <Gondola
            x={790}
            y={FLOOR_Y - 10}
            width={440}
            height={660}
            focusedTier="eye"
            spotlightCol={spotIdx}
          />

          {/* Destellos breves en productos */}
          <circle
            cx={648 + spotIdx * 82}
            cy={FLOOR_Y - 410}
            r={34}
            fill={PALETTE.mintGlow}
            opacity={flashOpacity * 0.4}
          />

          {/* Stickman caminando y observando */}
          <Stickman
            x={stickmanX}
            y={FLOOR_Y}
            scale={0.96}
            action={frame < 42 ? 'idle' : 'walk'}
            lookTarget={{dx: 0.9, dy: -0.1}}
          />

          {/* Carrito avanzando */}
          <Cart
            x={cartX}
            y={FLOOR_Y}
            scale={cartScale}
            items={[{color: PALETTE.sky}, {color: PALETTE.amber}]}
            rolling={frame < 165}
          />

          {/* Puertas automáticas deslizantes */}
          <rect
            x={0 - doorOpen * 260}
            y={460}
            width={340}
            height={970}
            fill="rgba(56, 189, 248, 0.16)"
            stroke={PALETTE.sky}
            strokeWidth={5}
          />
          <rect
            x={740 + doorOpen * 260}
            y={460}
            width={340}
            height={970}
            fill="rgba(56, 189, 248, 0.16)"
            stroke={PALETTE.sky}
            strokeWidth={5}
          />

          <text
            x={540}
            y={1840}
            textAnchor="middle"
            fill={PALETTE.greyLight}
            fontFamily={FONT_FAMILY}
            fontWeight="700"
            fontSize="22"
          >
            ENTRADA AL SUPERMERCADO
          </text>
        </svg>

        <CalloutBadge text="NADA ESTÁ PUESTO AL AZAR" x={540} y={260} tone="green" enterFrame={12} />
      </CameraRig>
    </AbsoluteFill>
  );
};
