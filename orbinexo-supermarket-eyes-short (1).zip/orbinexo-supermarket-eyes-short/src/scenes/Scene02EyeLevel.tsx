import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, HEIGHT, PALETTE, WIDTH} from '../config';
import {CameraRig} from '../components/CameraRig';
import {Stickman} from '../components/Stickman';
import {Cart} from '../components/Cart';
import {Gondola} from '../components/Gondola';
import {CalloutBadge} from '../components/CalloutBadge';

export const Scene02EyeLevel: React.FC = () => {
  const frame = useCurrentFrame(); // 0..209 (7s)
  const lineProgress = interpolate(frame, [25, 130], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // Texto "A LA ALTURA DE TUS OJOS" aparece sincronizado con la mención en la narración
  const showText = frame >= 88;

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgNavy}}>
      <CameraRig
        from={{x: 0, y: -120, zoom: 1.12}}
        to={{x: -40, y: -220, zoom: 1.32}}
        durationInFrames={210}
      >
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
          <rect width={WIDTH} height={HEIGHT} fill={PALETTE.wallSlate} />
          <rect x={0} y={FLOOR_Y} width={WIDTH} height={HEIGHT - FLOOR_Y} fill={PALETTE.floorMain} />
          <line x1={0} y1={FLOOR_Y} x2={WIDTH} y2={FLOOR_Y} stroke={PALETTE.floorLine} strokeWidth={5} />

          <Gondola
            x={690}
            y={FLOOR_Y - 10}
            width={560}
            height={780}
            focusedTier="eye"
            blurOtherTiers={true}
            spotlightCol={1}
          />

          <Stickman
            x={260}
            y={FLOOR_Y}
            scale={1.08}
            action="look_eye"
            lookTarget={{dx: 1, dy: 0}}
          />

          <Cart
            x={135}
            y={FLOOR_Y}
            scale={0.96}
            items={[{color: PALETTE.sky}, {color: PALETTE.amber}]}
            rolling={false}
          />

          {/* Línea visual desde los ojos del personaje hasta los productos centrales */}
          <line
            x1={276}
            y1={FLOOR_Y - 316}
            x2={276 + (615 - 276) * lineProgress}
            y2={FLOOR_Y - 316}
            stroke={PALETTE.mintGlow}
            strokeWidth={7}
            strokeDasharray="16 10"
          />
          <circle
            cx={276 + (615 - 276) * lineProgress}
            cy={FLOOR_Y - 316}
            r={11}
            fill={PALETTE.accentGreen}
          />
        </svg>

        {showText && (
          <CalloutBadge
            text="A LA ALTURA DE TUS OJOS"
            x={540}
            y={250}
            tone="green"
            enterFrame={88}
          />
        )}
      </CameraRig>
    </AbsoluteFill>
  );
};
