import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, FONT_FAMILY, HEIGHT, PALETTE, WIDTH} from '../config';
import {CameraRig} from '../components/CameraRig';
import {Stickman} from '../components/Stickman';
import {Cart} from '../components/Cart';
import {Gondola} from '../components/Gondola';
import {CalloutBadge} from '../components/CalloutBadge';

export const Scene06Discovery: React.FC = () => {
  const frame = useCurrentFrame(); // 0..359 (12s)
  const lookDownProg = interpolate(frame, [45, 115], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const surprised = frame >= 150 && frame < 285;
  const returned = frame >= 285;

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgNavy}}>
      <CameraRig
        from={{x: 0, y: -40, zoom: 1.06}}
        to={{x: -25, y: 55, zoom: 1.14}}
        durationInFrames={360}
      >
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
          <rect width={WIDTH} height={HEIGHT} fill={PALETTE.wallSlate} />
          <rect x={0} y={FLOOR_Y} width={WIDTH} height={HEIGHT - FLOOR_Y} fill={PALETTE.floorMain} />

          <Gondola
            x={670}
            y={FLOOR_Y - 15}
            width={560}
            height={780}
            focusedTier={frame >= 70 ? 'bottom' : 'eye'}
            spotlightCol={0}
            showPrices={frame >= 110}
          />

          {/* Trayectoria visual hacia el estante inferior */}
          <path
            d={`M 275 ${FLOOR_Y - 310} Q 420 ${FLOOR_Y - 220} ${interpolate(
              lookDownProg,
              [0, 1],
              [560, 650]
            )} ${interpolate(lookDownProg, [0, 1], [FLOOR_Y - 310, FLOOR_Y - 110])}`}
            fill="none"
            stroke={PALETTE.sky}
            strokeWidth={6}
            strokeDasharray="14 10"
          />

          <Stickman
            x={260}
            y={FLOOR_Y}
            scale={1.02}
            action={surprised ? 'surprised' : frame >= 70 ? 'look_down' : 'reach_cart'}
            actionProgress={0.5}
            holdingItemColor={!returned ? '#16A34A' : undefined}
            lookTarget={{dx: 1, dy: frame >= 70 ? 0.9 : 0}}
          />

          <Cart
            x={135}
            y={FLOOR_Y}
            scale={0.94}
            items={[{color: PALETTE.sky}, {color: PALETTE.amber}]}
            rolling={false}
          />

          {frame >= 135 && (
            <g transform="translate(540, 1345)">
              <rect
                x={-360}
                y={-40}
                width={720}
                height={72}
                rx={14}
                fill="rgba(8, 12, 20, 0.92)"
                stroke={PALETTE.sky}
                strokeWidth={3.5}
              />
              <text
                x={0}
                y={6}
                textAnchor="middle"
                fill={PALETTE.white}
                fontFamily={FONT_FAMILY}
                fontWeight="800"
                fontSize="23"
              >
                {returned
                  ? 'DEVUELVE EL CARO Y ELIGE LA ALTERNATIVA'
                  : 'MISMA FUNCIÓN • PRECIO MENOR ABAJO'}
              </text>
            </g>
          )}
        </svg>

        <CalloutBadge
          text="TU ELECCIÓN PUEDE ESTAR INFLUENCIADA"
          x={540}
          y={220}
          tone="sky"
          enterFrame={15}
        />
      </CameraRig>
    </AbsoluteFill>
  );
};
