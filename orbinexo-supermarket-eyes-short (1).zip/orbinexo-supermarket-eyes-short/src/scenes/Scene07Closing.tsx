import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, HEIGHT, PALETTE, WIDTH} from '../config';
import {CameraRig} from '../components/CameraRig';
import {Stickman} from '../components/Stickman';
import {Cart} from '../components/Cart';
import {Gondola} from '../components/Gondola';
import {CalloutBadge} from '../components/CalloutBadge';

export const Scene07Closing: React.FC = () => {
  const frame = useCurrentFrame(); // 0..89 (3s)
  const tierCycle: Array<'top' | 'eye' | 'bottom'> = ['top', 'eye', 'bottom'];
  const activeTier = tierCycle[Math.floor(frame / 16) % 3];

  const cartX = interpolate(frame, [0, 35, 89], [360, 220, 220], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const charX = interpolate(frame, [0, 35, 89], [500, 360, 360], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgNavy}}>
      <CameraRig
        from={{x: 0, y: 0, zoom: 1.02}}
        to={{x: -35, y: -35, zoom: 1.12}}
        durationInFrames={90}
      >
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
          <rect width={WIDTH} height={HEIGHT} fill={PALETTE.wallSlate} />
          <rect x={0} y={FLOOR_Y} width={WIDTH} height={HEIGHT - FLOOR_Y} fill={PALETTE.floorMain} />

          <Gondola
            x={730}
            y={FLOOR_Y - 20}
            width={480}
            height={760}
            focusedTier={activeTier}
            showPrices={true}
          />

          <Stickman
            x={charX}
            y={FLOOR_Y}
            scale={0.98}
            action={frame >= 35 ? 'point_up_down' : 'walk'}
            lookTarget={{dx: 1, dy: activeTier === 'top' ? -0.9 : activeTier === 'bottom' ? 0.9 : 0}}
          />

          <Cart
            x={cartX}
            y={FLOOR_Y}
            scale={0.92}
            items={[{color: PALETTE.sky}, {color: PALETTE.amber}, {color: '#0D9488'}]}
            rolling={frame < 35}
          />
        </svg>

        <CalloutBadge
          text="MIRÁ ARRIBA. MIRÁ ABAJO. COMPARÁ"
          x={540}
          y={240}
          tone="green"
          enterFrame={4}
        />
      </CameraRig>
    </AbsoluteFill>
  );
};
