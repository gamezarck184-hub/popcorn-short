# ORBINEXO — YouTube Short: ¿Por qué los supermercados ponen los productos más caros a la altura de tus ojos?

Proyecto completo en Remotion (`1080 × 1920`, `30 fps`, `58 segundos`, `1740 frames`) con 7 escenas animadas mediante React, SVG y CSS sincronizadas con el frame de Remotion.

## Comandos

```bash
npm install
npm run typecheck
npm run dev
npm run render
```
