export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

// Duración real medida de public/audio/narration.mp3: 52.6890s (1581 frames) + cierre visual limpio
export const AUDIO_DURATION_SEC = 52.689;
export const DURATION_SEC = 54.0;
export const TOTAL_FRAMES = Math.round(DURATION_SEC * FPS); // 1620 frames

export const OVERLAP = 12;
export const GROUND_Y = 1445;
export const AUDIO_PATH = 'audio/narration.mp3';

export const PALETTE = {
  bgDark: '#09111E',
  skyHigh: '#0C1E38',
  skyMid: '#163A63',
  skyHorizon: '#2B5B8C',
  vintageSkyTop: '#1E2D3D',
  vintageSkyBot: '#465A6E',
  fuselageLight: '#F1F5F9',
  fuselageMid: '#CBD5E1',
  fuselageDark: '#64748B',
  metalDark: '#1E293B',
  metalPanel: '#131D2B',
  sweaterGreen: '#1E7A44',
  sweaterGreenDark: '#13522D',
  accentGreen: '#22C55E',
  white: '#F8FAFC',
  ink: '#070B12',
  alertRed: '#EF4444',
  alertAmber: '#F59E0B',
  blueprintBlue: '#38BDF8',
};
