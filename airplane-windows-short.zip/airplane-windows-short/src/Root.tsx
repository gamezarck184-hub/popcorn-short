import React from 'react';
import {Composition} from 'remotion';
import {AirplaneWindowsShort} from './AirplaneWindowsShort';
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from './config';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="AirplaneWindowsShort"
      component={AirplaneWindowsShort}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};
