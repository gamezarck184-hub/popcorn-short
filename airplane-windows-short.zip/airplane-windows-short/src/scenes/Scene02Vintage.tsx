import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {GROUND_Y, PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneDef} from '../script';
import {AirlinerProfile, CloudLayer} from '../components/Aviation';
import {Stickman} from '../components/Stickman';

export const Scene02Vintage: React.FC<{scene: SceneDef}> = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const tarmacPhase = interpolate(frame, [62, 82], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const walkX = interpolate(frame, [75, durationInFrames], [260, 485], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const fuselagePan = interpolate(frame, [75, durationInFrames], [40, -90], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.vintageSkyTop, overflow: 'hidden'}}>
      {/* Parte 1: De Havilland Comet volando en los años 50 (con reactores, sin hélices) */}
      <svg width="1080" height="1920" viewBox="0 0 1080 1920">
        <defs>
          <linearGradient id="sky50s" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={PALETTE.vintageSkyTop} />
            <stop offset="100%" stopColor={PALETTE.vintageSkyBot} />
          </linearGradient>
        </defs>
        <rect width="1080" height="1920" fill="url(#sky50s)" />
        <CloudLayer offsetX={frame * 5} y={620} scale={1.0} opacity={0.4} />
        <AirlinerProfile
          x={520 + frame * 1.4}
          y={890}
          scale={1.25}
          windowShape="square"
          isComet={true}
        />
      </svg>

      {/* Parte 2: Cámara recorriendo lateralmente el fuselaje con ventanas cuadradas */}
      <div style={{position: 'absolute', inset: 0, opacity: tarmacPhase}}>
        <svg width="1080" height="1920" viewBox="0 0 1080 1920">
          <rect width="1080" height="1920" fill="url(#sky50s)" />
          <rect x="0" y={GROUND_Y} width="1080" height={1920 - GROUND_Y} fill="#1E293B" />
          <line x1="0" y1={GROUND_Y} x2="1080" y2={GROUND_Y} stroke="#64748B" strokeWidth={4} />

          {/* Fuselaje cercano del De Havilland Comet */}
          <g transform={`translate(${fuselagePan}, 720)`}>
            <rect x="-120" y="0" width="1440" height="440" rx="40" fill="#E2E8F0" stroke="#475569" strokeWidth={5} />
            <rect x="-120" y="245" width="1440" height="36" fill="#0284C7" />

            {[160, 440, 720, 1000].map((wx, idx) => (
              <g key={idx} transform={`translate(${wx}, 125)`}>
                <rect
                  x="-72"
                  y="-86"
                  width="144"
                  height="172"
                  rx="8"
                  fill="#0F172A"
                  stroke={idx === 1 ? PALETTE.alertAmber : '#475569'}
                  strokeWidth={idx === 1 ? 8 : 6}
                />
                {idx === 1 && (
                  <circle
                    cx="72"
                    cy="86"
                    r={16 + Math.sin(frame * 0.25) * 4}
                    fill="none"
                    stroke={PALETTE.alertRed}
                    strokeWidth={4}
                  />
                )}
              </g>
            ))}
          </g>

          {/* Personaje caminando y señalando la esquina de la ventana cuadrada */}
          <Stickman
            x={walkX}
            y={GROUND_Y}
            scale={1.15}
            mood="pointing"
            armAngleDeg={-48}
            lookX={0.85}
            walkSpeed={0.22}
          />
        </svg>
      </div>

      {/* Etiqueta pequeña discreta: Década de 1950 */}
      <div
        style={{
          position: 'absolute',
          top: 130,
          left: 70,
          backgroundColor: 'rgba(15, 23, 42, 0.82)',
          border: '1px solid rgba(255,255,255,0.22)',
          borderRadius: 12,
          padding: '10px 22px',
          fontFamily,
          fontWeight: 800,
          fontSize: 26,
          color: PALETTE.white,
          letterSpacing: 1.5,
        }}
      >
        Década de 1950
      </div>
    </AbsoluteFill>
  );
};
