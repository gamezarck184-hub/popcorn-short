import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneDef} from '../script';
import {AirlinerProfile} from '../components/Aviation';

export const Scene03Problem: React.FC<{scene: SceneDef}> = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  // Transición de vista exterior histórica a corte transversal técnico
  const cutawayOpacity = interpolate(frame, [45, 68], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // Zoom progresivo hacia la esquina superior derecha de la ventana cuadrada
  const cornerZoom = interpolate(frame, [95, durationInFrames], [1.0, 1.55], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const pulse = Math.sin(frame * 0.2) * 10;

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark, overflow: 'hidden'}}>
      {/* Vista histórica respetuosa inicial */}
      <svg width="1080" height="1920" viewBox="0 0 1080 1920">
        <rect width="1080" height="1920" fill="#162233" />
        <AirlinerProfile
          x={520 + frame * 0.8}
          y={880}
          scale={1.15}
          windowShape="square"
          isComet={true}
        />
        <text
          x="540"
          y="360"
          textAnchor="middle"
          fill="#94A3B8"
          fontFamily={fontFamily}
          fontWeight="800"
          fontSize="32"
          letterSpacing="3"
        >
          DE HAVILLAND COMET · 1954
        </text>
      </svg>

      {/* Corte transversal técnico de la cabina presurizada */}
      <div style={{position: 'absolute', inset: 0, opacity: cutawayOpacity}}>
        <svg
          width="1080"
          height="1920"
          viewBox="0 0 1080 1920"
          style={{
            transform: `scale(${cornerZoom})`,
            transformOrigin: '675px 775px',
          }}
        >
          <rect width="1080" height="1920" fill={PALETTE.bgDark} />

          {/* Estructura metálica del fuselaje */}
          <rect
            x="140"
            y="430"
            width="800"
            height="860"
            rx="44"
            fill={PALETTE.metalPanel}
            stroke={PALETTE.fuselageDark}
            strokeWidth={12}
          />

          {/* Ventana cuadrada bajo presión */}
          <rect
            x="390"
            y="690"
            width="300"
            height="340"
            rx="10"
            fill="#0F172A"
            stroke="#CBD5E1"
            strokeWidth={10}
          />

          {/* Partículas de aire presurizado en movimiento */}
          {Array.from({length: 14}).map((_, i) => {
            const angle = (i / 14) * Math.PI * 2 + frame * 0.03;
            const radius = 210 + ((frame * 2 + i * 19) % 140);
            return (
              <circle
                key={i}
                cx={540 + Math.cos(angle) * radius}
                cy={860 + Math.sin(angle) * radius}
                r={5}
                fill={PALETTE.blueprintBlue}
                opacity={0.65}
              />
            );
          })}

          {/* Flechas de presión empujando hacia afuera */}
          {[
            {x: 540, y: 630, dx: 0, dy: -32 - pulse},
            {x: 540, y: 1090, dx: 0, dy: 32 + pulse},
            {x: 330, y: 860, dx: -32 - pulse, dy: 0},
            {x: 750, y: 860, dx: 32 + pulse, dy: 0},
          ].map((arr, idx) => (
            <g key={idx} transform={`translate(${arr.x}, ${arr.y})`}>
              <line
                x1={0}
                y1={0}
                x2={arr.dx}
                y2={arr.dy}
                stroke={PALETTE.blueprintBlue}
                strokeWidth={7}
                strokeLinecap="round"
              />
              <circle cx={arr.dx} cy={arr.dy} r={7} fill={PALETTE.blueprintBlue} />
            </g>
          ))}

          {/* Concentración de tensión en las 4 esquinas */}
          {[
            {cx: 390, cy: 690},
            {cx: 690, cy: 690},
            {cx: 390, cy: 1030},
            {cx: 690, cy: 1030},
          ].map((corner, idx) => (
            <g key={idx}>
              <circle
                cx={corner.cx}
                cy={corner.cy}
                r={36 + pulse * 0.8}
                fill="rgba(239, 68, 68, 0.25)"
                stroke={PALETTE.alertRed}
                strokeWidth={4}
              />
              <circle cx={corner.cx} cy={corner.cy} r={10} fill={PALETTE.alertRed} />
            </g>
          ))}
        </svg>
      </div>
    </AbsoluteFill>
  );
};
