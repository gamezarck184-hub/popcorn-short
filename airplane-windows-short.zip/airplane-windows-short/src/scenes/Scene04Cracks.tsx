import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {GROUND_Y, PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneDef} from '../script';
import {Stickman} from '../components/Stickman';

export const Scene04Cracks: React.FC<{scene: SceneDef}> = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  // Ciclos de presurización y despresurización
  const cycleWave = Math.sin(frame * 0.24);
  const pressureLevel = Math.round(55 + cycleWave * 40);

  // Crecimiento gradual de la grieta metálica desde la esquina de la ventana
  const crackProgress = interpolate(frame, [45, durationInFrames - 40], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // El ingeniero retrocede sorprendido al ver crecer la grieta
  const engineerX = interpolate(frame, [180, 260], [340, 250], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const isSurprised = frame > 175;

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark, overflow: 'hidden'}}>
      <svg width="1080" height="1920" viewBox="0 0 1080 1920">
        <rect width="1080" height="1920" fill={PALETTE.bgDark} />
        <rect x="0" y={GROUND_Y} width="1080" height={1920 - GROUND_Y} fill="#0F172A" />

        {/* Indicador superior de ciclos de presurización */}
        <g transform="translate(540, 320)">
          <rect
            x="-340"
            y="-65"
            width="680"
            height="130"
            rx="20"
            fill={PALETTE.metalPanel}
            stroke="#334155"
            strokeWidth={3}
          />
          <text
            x="0"
            y="-18"
            textAnchor="middle"
            fill={PALETTE.white}
            fontFamily={fontFamily}
            fontWeight="800"
            fontSize="24"
          >
            PRESIÓN DE CABINA (ASCENSO / DESCENSO)
          </text>
          <rect x="-260" y="10" width="520" height="24" rx="12" fill="#090D16" />
          <rect
            x="-260"
            y="10"
            width={(pressureLevel / 100) * 520}
            height="24"
            rx="12"
            fill={pressureLevel > 75 ? PALETTE.alertAmber : PALETTE.blueprintBlue}
          />
        </g>

        {/* Placa metálica del fuselaje con ventana cuadrada y grieta progresiva */}
        <g transform="translate(650, 840)">
          <rect
            x="-250"
            y="-280"
            width="500"
            height="560"
            rx="28"
            fill="#CBD5E1"
            stroke="#475569"
            strokeWidth={6}
          />

          {/* Ventana cuadrada */}
          <rect
            x="-130"
            y="-150"
            width="260"
            height="300"
            rx="8"
            fill="#0F172A"
            stroke="#334155"
            strokeWidth={10}
          />

          {/* Flechas internas expandiéndose y contrayéndose */}
          <line
            x1={-130}
            y1={-150}
            x2={-155 - cycleWave * 16}
            y2={-175 - cycleWave * 16}
            stroke={PALETTE.alertRed}
            strokeWidth={6}
            strokeLinecap="round"
          />

          {/* Grieta metálica creciendo desde la esquina superior izquierda */}
          <path
            d="M -130 -150 L -158 -182 L -174 -176 L -206 -215 L -222 -210 L -246 -248"
            fill="none"
            stroke={PALETTE.alertRed}
            strokeWidth={6}
            strokeLinecap="round"
            strokeDasharray="180"
            strokeDashoffset={180 * (1 - crackProgress)}
          />
        </g>

        {/* Personaje ingeniero examinando con lupa y retrocediendo sorprendido */}
        <Stickman
          x={engineerX}
          y={GROUND_Y}
          scale={1.15}
          mood={isSurprised ? 'surprised' : 'examining'}
          armAngleDeg={isSurprised ? -55 : -42}
          lookX={0.85}
          holdingMagnifier={!isSurprised}
          walkSpeed={frame > 180 && frame < 260 ? 0.25 : 0}
        />
      </svg>
    </AbsoluteFill>
  );
};
