import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneDef} from '../script';
import {AirlinerProfile, CloudLayer} from '../components/Aviation';
import {Stickman} from '../components/Stickman';

export const Scene01Mystery: React.FC<{scene: SceneDef}> = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  // Fases: 0..65 exterior volando con zoom a ventana -> 65..125 cabina interior -> 125..174 comparación flotante
  const interiorOpacity = interpolate(frame, [52, 68], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const compareOpacity = interpolate(frame, [118, 134], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const exteriorZoom = interpolate(frame, [0, 68], [1.0, 2.3], {
    extrapolateRight: 'clamp',
  });
  const planeX = interpolate(frame, [0, 68], [460, 560], {
    extrapolateRight: 'clamp',
  });

  const armAngle = interpolate(frame, [72, 95], [-15, -52], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.skyHigh, overflow: 'hidden'}}>
      {/* Plano 1: Avión moderno volando entre nubes con acercamiento */}
      <svg
        width="1080"
        height="1920"
        viewBox="0 0 1080 1920"
        style={{
          transform: `scale(${exteriorZoom})`,
          transformOrigin: '540px 880px',
        }}
      >
        <defs>
          <linearGradient id="skyS1" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={PALETTE.skyHigh} />
            <stop offset="100%" stopColor={PALETTE.skyHorizon} />
          </linearGradient>
        </defs>
        <rect width="1080" height="1920" fill="url(#skyS1)" />
        <CloudLayer offsetX={frame * 3.5} y={540} scale={0.9} opacity={0.45} />
        <AirlinerProfile
          x={planeX}
          y={880 + Math.sin(frame * 0.08) * 10}
          scale={1.15}
          windowShape="round"
        />
        <CloudLayer offsetX={frame * 7.5} y={1180} scale={1.25} opacity={0.85} />
      </svg>

      {/* Plano 2: Interior de cabina, personaje sentado señalando la ventana ovalada */}
      <div style={{position: 'absolute', inset: 0, opacity: interiorOpacity}}>
        <svg width="1080" height="1920" viewBox="0 0 1080 1920">
          <rect width="1080" height="1920" fill="#1E293B" />
          {/* Panel interior curvado */}
          <rect x="60" y="220" width="960" height="1220" rx="48" fill="#334155" stroke="#475569" strokeWidth={6} />

          {/* Ventana ovalada con cielo en movimiento */}
          <g transform="translate(650, 740)">
            <rect x="-150" y="-215" width="300" height="430" rx="145" fill="#0F172A" stroke="#CBD5E1" strokeWidth={18} />
            <rect x="-132" y="-197" width="264" height="394" rx="130" fill="#38BDF8" />
            <ellipse
              cx={-40 + ((frame * 3) % 140)}
              cy={40}
              rx={95}
              ry={34}
              fill="#F8FAFC"
              opacity={0.85}
            />
          </g>

          {/* Asiento de avión */}
          <rect x="220" y="820" width="210" height="420" rx="28" fill="#0F172A" />
          <rect x="220" y="1140" width="290" height="85" rx="22" fill="#1E3A8A" />

          {/* Personaje sentado observando y señalando el borde redondeado */}
          <Stickman
            x={335}
            y={1140}
            scale={1.32}
            seated={true}
            mood={frame > 78 ? 'pointing' : 'curious'}
            armAngleDeg={armAngle}
            lookX={0.9}
          />
        </svg>
      </div>

      {/* Plano 3: Comparación visual flotante (Redonda vs Cuadrada) */}
      <div style={{position: 'absolute', inset: 0, opacity: compareOpacity}}>
        <svg width="1080" height="1920" viewBox="0 0 1080 1920">
          <rect width="1080" height="1920" fill={PALETTE.bgDark} />
          <CloudLayer offsetX={frame * 4} y={1360} scale={1.1} opacity={0.25} />

          {/* Ventana Redonda */}
          <g transform={`translate(320, ${760 + Math.sin(frame * 0.1) * 10})`}>
            <rect x="-150" y="-210" width="300" height="420" rx="145" fill="#1E3A8A" stroke={PALETTE.accentGreen} strokeWidth={12} />
            <text x="0" y="275" textAnchor="middle" fill={PALETTE.accentGreen} fontFamily={fontFamily} fontWeight="900" fontSize="34">
              REDONDA
            </text>
          </g>

          <text x="540" y="775" textAnchor="middle" fill={PALETTE.white} fontFamily={fontFamily} fontWeight="900" fontSize="42">
            VS
          </text>

          {/* Ventana Cuadrada */}
          <g transform={`translate(760, ${760 - Math.sin(frame * 0.1) * 10})`}>
            <rect x="-150" y="-210" width="300" height="420" rx="10" fill="#1E293B" stroke={PALETTE.alertRed} strokeWidth={12} />
            <text x="0" y="275" textAnchor="middle" fill={PALETTE.alertRed} fontFamily={fontFamily} fontWeight="900" fontSize="34">
              CUADRADA
            </text>
          </g>

          <Stickman
            x={540}
            y={1440}
            scale={1.08}
            mood="curious"
            armAngleDeg={-40}
            lookX={-0.6}
          />
        </svg>
      </div>
    </AbsoluteFill>
  );
};
