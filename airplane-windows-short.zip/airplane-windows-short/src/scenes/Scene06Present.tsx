import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {PALETTE} from '../config';
import {AirlinerProfile, CloudLayer} from '../components/Aviation';
import {Stickman} from '../components/Stickman';
import {SceneDef} from '../script';

export const Scene06Present: React.FC<{scene: SceneDef}> = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  // Fase 1 (0..185): Interior tranquilo mirando el cielo por ventana ovalada
  // Fase 2 (185..final): Plano exterior con alejamiento cinematográfico final
  const exteriorOpacity = interpolate(frame, [175, 205], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const finalPullBack = interpolate(frame, [205, durationInFrames], [1.22, 0.85], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const planeFlyX = interpolate(frame, [180, durationInFrames], [470, 680], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.skyHigh, overflow: 'hidden'}}>
      {/* Vista interior moderna junto a la ventana ovalada */}
      <svg width="1080" height="1920" viewBox="0 0 1080 1920">
        <rect width="1080" height="1920" fill="#1E293B" />
        <rect x="60" y="220" width="960" height="1220" rx="48" fill="#334155" stroke="#475569" strokeWidth={6} />

        {/* Ventana ovalada moderna */}
        <g transform="translate(650, 740)">
          <rect x="-150" y="-215" width="300" height="430" rx="145" fill="#0F172A" stroke="#E2E8F0" strokeWidth={18} />
          <rect x="-132" y="-197" width="264" height="394" rx="130" fill="#0284C7" />
          <ellipse
            cx={-60 + ((frame * 2.4) % 160)}
            cy={55}
            rx={105}
            ry={36}
            fill="#F8FAFC"
            opacity={0.9}
          />
        </g>

        {/* Asiento y personaje mirando el cielo y sonriendo */}
        <rect x="220" y="820" width="210" height="420" rx="28" fill="#0F172A" />
        <rect x="220" y="1140" width="290" height="85" rx="22" fill="#1E3A8A" />
        <Stickman
          x={335}
          y={1140}
          scale={1.32}
          seated={true}
          mood="smiling"
          armAngleDeg={-18}
          lookX={0.9}
        />
      </svg>

      {/* Plano exterior final del avión alejándose sobre las nubes */}
      <div style={{position: 'absolute', inset: 0, opacity: exteriorOpacity}}>
        <svg
          width="1080"
          height="1920"
          viewBox="0 0 1080 1920"
          style={{
            transform: `scale(${finalPullBack})`,
            transformOrigin: '540px 920px',
          }}
        >
          <defs>
            <linearGradient id="skyFinal" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={PALETTE.skyHigh} />
              <stop offset="100%" stopColor={PALETTE.skyHorizon} />
            </linearGradient>
          </defs>
          <rect width="1080" height="1920" fill="url(#skyFinal)" />
          <CloudLayer offsetX={frame * 3} y={560} scale={0.95} opacity={0.45} />
          <AirlinerProfile
            x={planeFlyX}
            y={890 + Math.sin(frame * 0.07) * 8}
            scale={1.18}
            windowShape="round"
          />
          <CloudLayer offsetX={frame * 6.5} y={1180} scale={1.3} opacity={0.85} />
        </svg>
      </div>
    </AbsoluteFill>
  );
};
