import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {GROUND_Y, PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneDef} from '../script';
import {Stickman} from '../components/Stickman';

export const Scene05Solution: React.FC<{scene: SceneDef}> = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  // Morfología suave de esquina cuadrada (rx=10) a ventana redondeada (rx=135)
  const morphRadius = interpolate(frame, [15, 95], [10, 135], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // Rotación ligera del modelo técnico
  const modelTilt = Math.sin(frame * 0.05) * 4;
  const flowDash = -(frame * 3) % 60;

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark, overflow: 'hidden'}}>
      <svg width="1080" height="1920" viewBox="0 0 1080 1920">
        <rect width="1080" height="1920" fill={PALETTE.bgDark} />
        <rect x="0" y={GROUND_Y} width="1080" height={1920 - GROUND_Y} fill="#0F172A" />

        {/* Comparación técnica superior: Tensión concentrada vs Tensión distribuida */}
        <g transform="translate(540, 440)">
          {/* Izquierda: Cuadrada con puntos rojos en esquinas */}
          <g transform="translate(-230, 0)">
            <rect x="-90" y="-110" width="180" height="220" rx="8" fill={PALETTE.metalPanel} stroke={PALETTE.alertRed} strokeWidth={5} />
            <circle cx="-90" cy="-110" r="14" fill={PALETTE.alertRed} />
            <circle cx="90" cy="-110" r="14" fill={PALETTE.alertRed} />
            <circle cx="-90" cy="110" r="14" fill={PALETTE.alertRed} />
            <circle cx="90" cy="110" r="14" fill={PALETTE.alertRed} />
            <text x="0" y="155" textAnchor="middle" fill={PALETTE.alertRed} fontFamily={fontFamily} fontWeight="800" fontSize="24">
              TENSIÓN CONCENTRADA
            </text>
          </g>

          {/* Derecha: Redondeada con flujo continuo verde */}
          <g transform="translate(230, 0)">
            <rect
              x="-90"
              y="-110"
              width="180"
              height="220"
              rx="90"
              fill={PALETTE.metalPanel}
              stroke={PALETTE.accentGreen}
              strokeWidth={5}
            />
            <rect
              x="-106"
              y="-126"
              width="212"
              height="252"
              rx="105"
              fill="none"
              stroke={PALETTE.accentGreen}
              strokeWidth={4}
              strokeDasharray="18 12"
              strokeDashoffset={flowDash}
            />
            <text x="0" y="155" textAnchor="middle" fill={PALETTE.accentGreen} fontFamily={fontFamily} fontWeight="800" fontSize="24">
              TENSIÓN DISTRIBUIDA
            </text>
          </g>
        </g>

        {/* Modelo central interactivo que se transforma de cuadrado a ovalado */}
        <g transform={`translate(660, 960) rotate(${modelTilt})`}>
          <rect
            x="-210"
            y="-240"
            width="420"
            height="480"
            rx="32"
            fill="#1E293B"
            stroke="#475569"
            strokeWidth={5}
          />
          <rect
            x="-135"
            y="-165"
            width="270"
            height="330"
            rx={morphRadius}
            fill="#09111E"
            stroke={morphRadius > 80 ? PALETTE.accentGreen : PALETTE.alertAmber}
            strokeWidth={10}
          />
          <rect
            x="-155"
            y="-185"
            width="310"
            height="370"
            rx={morphRadius + 16}
            fill="none"
            stroke={PALETTE.accentGreen}
            strokeWidth={4}
            strokeDasharray="20 10"
            strokeDashoffset={flowDash}
            opacity={morphRadius > 70 ? 0.9 : 0}
          />
        </g>

        {/* Personaje explicando y señalando la ventana redondeada */}
        <Stickman
          x={285}
          y={GROUND_Y}
          scale={1.15}
          mood="pointing"
          armAngleDeg={-38 + Math.sin(frame * 0.12) * 8}
          lookX={0.85}
        />
      </svg>
    </AbsoluteFill>
  );
};
