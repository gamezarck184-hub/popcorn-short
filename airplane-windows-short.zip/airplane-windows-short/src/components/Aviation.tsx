import React from 'react';
import {PALETTE} from '../config';

export const CloudLayer: React.FC<{
  offsetX: number;
  y: number;
  scale?: number;
  opacity?: number;
}> = ({offsetX, y, scale = 1, opacity = 0.85}) => {
  const positions = [-200, 260, 740, 1220];
  return (
    <g opacity={opacity}>
      {positions.map((baseX, idx) => {
        const cx = ((baseX - offsetX) % 1500 + 1500) % 1500 - 220;
        return (
          <g
            key={idx}
            transform={`translate(${cx}, ${y + (idx % 2) * 32}) scale(${scale})`}
          >
            <ellipse cx={0} cy={0} rx={135} ry={42} fill="#E2E8F0" />
            <circle cx={-55} cy={-18} r={44} fill="#F8FAFC" />
            <circle cx={10} cy={-26} r={54} fill="#F8FAFC" />
            <circle cx={68} cy={-14} r={38} fill="#F1F5F9" />
          </g>
        );
      })}
    </g>
  );
};

export const AirlinerProfile: React.FC<{
  x: number;
  y: number;
  scale?: number;
  windowShape: 'round' | 'square';
  isComet?: boolean;
}> = ({x, y, scale = 1, windowShape, isComet = false}) => {
  const windowOffsets = [-190, -135, -80, -25, 30, 85, 140, 195];

  return (
    <g transform={`translate(${x}, ${y}) scale(${scale})`}>
      {/* Sombra inferior del fuselaje */}
      <ellipse cx={0} cy={125} rx={360} ry={18} fill="rgba(0,0,0,0.22)" />

      {/* Estabilizador vertical (cola) */}
      <path
        d="M -310 -20 L -385 -155 L -320 -155 L -235 -20 Z"
        fill={isComet ? '#94A3B8' : '#1E3A8A'}
        stroke="#0F172A"
        strokeWidth={3}
      />

      {/* Fuselaje principal */}
      <path
        d="M -340 28 L -340 -26 Q -340 -52 -290 -52 L 250 -52 Q 375 -52 415 6 Q 385 38 270 38 L -290 38 Q -340 38 -340 28 Z"
        fill={isComet ? '#E2E8F0' : PALETTE.fuselageLight}
        stroke="#334155"
        strokeWidth={3.5}
      />

      {/* Franja decorativa lateral */}
      <rect
        x={-315}
        y={-6}
        width={670}
        height={11}
        fill={isComet ? '#0284C7' : '#2563EB'}
        opacity={0.85}
      />

      {/* Cabina de pilotos */}
      <path
        d="M 305 -42 L 368 -14 L 325 -14 Z"
        fill="#0F172A"
      />

      {/* Ventanas de pasajeros (cuadradas para el Comet 1950s, ovaladas/redondas para moderno) */}
      {windowOffsets.map((wx, i) =>
        windowShape === 'square' ? (
          <rect
            key={i}
            x={wx - 13}
            y={-32}
            width={26}
            height={24}
            rx={2}
            fill="#0F172A"
            stroke="#475569"
            strokeWidth={2.5}
          />
        ) : (
          <rect
            key={i}
            x={wx - 11}
            y={-32}
            width={22}
            height={26}
            rx={11}
            fill="#0F172A"
            stroke="#64748B"
            strokeWidth={2.5}
          />
        )
      )}

      {/* Ala y motor a reacción (sin hélices) */}
      <path
        d="M -45 14 L 85 14 L -35 88 L -105 88 Z"
        fill="#CBD5E1"
        stroke="#475569"
        strokeWidth={3}
      />
      {isComet ? (
        /* Motor a reacción integrado en la raíz del ala del De Havilland Comet */
        <rect
          x={-45}
          y={2}
          width={95}
          height={26}
          rx={10}
          fill="#64748B"
          stroke="#1E293B"
          strokeWidth={3}
        />
      ) : (
        /* Turbina bajo el ala en avión moderno */
        <g transform="translate(15, 42)">
          <rect
            x={-48}
            y={-18}
            width={96}
            height={36}
            rx={16}
            fill="#94A3B8"
            stroke="#1E293B"
            strokeWidth={3}
          />
          <ellipse cx={46} cy={0} rx={6} ry={15} fill="#0F172A" />
        </g>
      )}
    </g>
  );
};
