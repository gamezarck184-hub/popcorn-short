import React from 'react';
import {useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';

export type StickmanMood =
  | 'curious'
  | 'pointing'
  | 'examining'
  | 'surprised'
  | 'smiling';

export interface StickmanProps {
  x: number;
  y: number;
  scale?: number;
  flipX?: boolean;
  mood?: StickmanMood;
  armAngleDeg?: number;
  lookX?: number;
  walkSpeed?: number;
  seated?: boolean;
  holdingMagnifier?: boolean;
}

export const Stickman: React.FC<StickmanProps> = ({
  x,
  y,
  scale = 1,
  flipX = false,
  mood = 'curious',
  armAngleDeg = -35,
  lookX = 0.6,
  walkSpeed = 0,
  seated = false,
  holdingMagnifier = false,
}) => {
  const frame = useCurrentFrame();

  const breath = Math.sin(frame * 0.11) * 2.5;
  const walkPhase = !seated && walkSpeed > 0 ? Math.sin(frame * walkSpeed) : 0;
  const stepLift = !seated && walkSpeed > 0 ? Math.abs(Math.cos(frame * walkSpeed)) * 6 : 0;

  const blink = frame % 118 > 113 ? 0.12 : 1;
  const pupilDx = lookX * 4.5;

  const leftFootX = -20 + walkPhase * 22;
  const rightFootX = 20 - walkPhase * 22;
  const leftKneeX = -22 + walkPhase * 12;
  const rightKneeX = 22 - walkPhase * 12;

  const rad = (armAngleDeg * Math.PI) / 180;
  const shoulderR = {x: 34, y: -158 + breath};
  const handR = {
    x: shoulderR.x + Math.cos(rad) * 102,
    y: shoulderR.y + Math.sin(rad) * 102,
  };
  const elbowR = {
    x: (shoulderR.x + handR.x) / 2 + 6,
    y: (shoulderR.y + handR.y) / 2 + 12,
  };

  const shoulderL = {x: -34, y: -158 + breath};
  const handL =
    mood === 'curious'
      ? {x: -12, y: -194 + breath}
      : {x: -54 - walkPhase * 14, y: -74 + breath * 0.5};
  const elbowL =
    mood === 'curious'
      ? {x: -56, y: -138 + breath}
      : {x: -52 - walkPhase * 8, y: -116 + breath};

  const renderMouth = () => {
    switch (mood) {
      case 'surprised':
        return <ellipse cx={0} cy={-212 + breath} rx={7} ry={9.5} fill={PALETTE.ink} />;
      case 'smiling':
      case 'pointing':
        return (
          <path
            d={`M -14 ${-216 + breath} Q 0 ${-198 + breath} 14 ${-216 + breath}`}
            stroke={PALETTE.ink}
            strokeWidth={4}
            fill="none"
            strokeLinecap="round"
          />
        );
      case 'examining':
      case 'curious':
      default:
        return (
          <line
            x1={-11}
            y1={-212 + breath}
            x2={11}
            y2={-214 + breath}
            stroke={PALETTE.ink}
            strokeWidth={4}
            strokeLinecap="round"
          />
        );
    }
  };

  return (
    <g
      transform={`translate(${x}, ${y - stepLift}) scale(${flipX ? -scale : scale}, ${scale})`}
    >
      {/* Sombra suave en el suelo */}
      {!seated && (
        <ellipse cx={0} cy={stepLift} rx={56} ry={11} fill="rgba(0,0,0,0.42)" />
      )}

      {/* Piernas negras */}
      {seated ? (
        <>
          <polyline
            points="-14,-82 42,-82 48,-16"
            fill="none"
            stroke={PALETTE.ink}
            strokeWidth={13}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <polyline
            points="14,-82 54,-82 60,-16"
            fill="none"
            stroke={PALETTE.ink}
            strokeWidth={13}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </>
      ) : (
        <>
          <polyline
            points={`-18,-82 ${leftKneeX},-40 ${leftFootX},${stepLift}`}
            fill="none"
            stroke={PALETTE.ink}
            strokeWidth={13}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <polyline
            points={`18,-82 ${rightKneeX},-40 ${rightFootX},${stepLift}`}
            fill="none"
            stroke={PALETTE.ink}
            strokeWidth={13}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </>
      )}

      {/* Brazo izquierdo */}
      <polyline
        points={`${shoulderL.x},${shoulderL.y} ${elbowL.x},${elbowL.y} ${handL.x},${handL.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={11}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Sudadera verde */}
      <path
        d={`M -34 ${-168 + breath}
            Q 0 ${-176 + breath} 34 ${-168 + breath}
            L 40 ${-80 + breath * 0.4}
            Q 0 ${-74 + breath * 0.4} -40 ${-80 + breath * 0.4} Z`}
        fill={PALETTE.sweaterGreen}
        stroke={PALETTE.ink}
        strokeWidth={4}
      />
      <path
        d={`M -16 ${-169 + breath} Q 0 ${-154 + breath} 16 ${-169 + breath}`}
        fill="none"
        stroke={PALETTE.sweaterGreenDark}
        strokeWidth={5}
        strokeLinecap="round"
      />
      <line
        x1={0}
        y1={-158 + breath}
        x2={0}
        y2={-80 + breath * 0.4}
        stroke={PALETTE.sweaterGreenDark}
        strokeWidth={3}
      />

      {/* Brazo derecho */}
      <polyline
        points={`${shoulderR.x},${shoulderR.y} ${elbowR.x},${elbowR.y} ${handR.x},${handR.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={11}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line
        x1={shoulderR.x}
        y1={shoulderR.y}
        x2={(shoulderR.x + elbowR.x) / 2}
        y2={(shoulderR.y + elbowR.y) / 2}
        stroke={PALETTE.sweaterGreen}
        strokeWidth={16}
        strokeLinecap="round"
      />

      {/* Lupa opcional cuando examina grietas */}
      {holdingMagnifier && (
        <g transform={`translate(${handR.x + 18}, ${handR.y - 16})`}>
          <line
            x1={-18}
            y1={16}
            x2={0}
            y2={0}
            stroke="#475569"
            strokeWidth={7}
            strokeLinecap="round"
          />
          <circle
            cx={18}
            cy={-16}
            r={24}
            fill="rgba(56, 189, 248, 0.25)"
            stroke="#E2E8F0"
            strokeWidth={5}
          />
        </g>
      )}

      {/* Cabeza circular blanca sin pelo */}
      <circle
        cx={0}
        cy={-224 + breath}
        r={44}
        fill={PALETTE.white}
        stroke={PALETTE.ink}
        strokeWidth={4.5}
      />

      {/* Cejas */}
      <line
        x1={-21 + pupilDx * 0.5}
        y1={mood === 'surprised' ? -246 + breath : -241 + breath}
        x2={-7 + pupilDx * 0.5}
        y2={-242 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.5}
        strokeLinecap="round"
      />
      <line
        x1={7 + pupilDx * 0.5}
        y1={-242 + breath}
        x2={21 + pupilDx * 0.5}
        y2={mood === 'surprised' ? -246 + breath : -241 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.5}
        strokeLinecap="round"
      />

      {/* Ojos */}
      <ellipse
        cx={-13 + pupilDx}
        cy={-230 + breath}
        rx={4.5}
        ry={6.5 * blink}
        fill={PALETTE.ink}
      />
      <ellipse
        cx={13 + pupilDx}
        cy={-230 + breath}
        rx={4.5}
        ry={6.5 * blink}
        fill={PALETTE.ink}
      />

      {/* Boca */}
      {renderMouth()}
    </g>
  );
};
