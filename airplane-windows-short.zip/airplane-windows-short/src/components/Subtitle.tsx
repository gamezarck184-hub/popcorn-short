import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SCENES, sec} from '../script';

export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const cues = SCENES.flatMap((s) => s.cues);
  const active = cues.find((c) => frame >= sec(c.from) && frame < sec(c.to));

  if (!active) return null;

  const startF = sec(active.from);
  const endF = sec(active.to);
  const fadeIn = interpolate(frame, [startF, startF + 4], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const fadeOut = interpolate(frame, [endF - 3, endF], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const slideY = interpolate(frame, [startF, startF + 5], [14, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const highlightWords = new Set(
    active.highlights.map((w) => w.toLowerCase())
  );

  const lines = active.text.split('\n');

  return (
    <div
      style={{
        position: 'absolute',
        left: 56,
        right: 56,
        bottom: 225,
        display: 'flex',
        justifyContent: 'center',
        pointerEvents: 'none',
        opacity: fadeIn * fadeOut,
        transform: `translateY(${slideY}px)`,
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(9, 17, 30, 0.84)',
          border: '1px solid rgba(255, 255, 255, 0.14)',
          borderRadius: 20,
          padding: '16px 28px',
          boxShadow: '0 14px 34px rgba(0, 0, 0, 0.65)',
          textAlign: 'center',
          fontFamily,
          fontWeight: 800,
          fontSize: 44,
          lineHeight: 1.22,
          color: PALETTE.white,
          maxWidth: 940,
          textShadow: '0 3px 10px rgba(0, 0, 0, 0.9)',
        }}
      >
        {lines.map((line, lIdx) => {
          const words = line.split(' ');
          return (
            <div key={lIdx}>
              {words.map((word, wIdx) => {
                const isHighlight = highlightWords.has(word.toLowerCase());
                return (
                  <span
                    key={wIdx}
                    style={{
                      color: isHighlight ? PALETTE.accentGreen : PALETTE.white,
                    }}
                  >
                    {word}
                    {wIdx < words.length - 1 ? ' ' : ''}
                  </span>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
};
