import {FPS} from './config';

export const sec = (s: number): number => Math.round(s * FPS);

export type SubtitleCue = {
  from: number;
  to: number;
  text: string;
  highlights: string[];
};

export type SceneDef = {
  id: string;
  start: number;
  end: number;
  cues: SubtitleCue[];
};

export const SCENES: SceneDef[] = [
  {
    id: 'scene-01-mystery',
    start: 0.0,
    end: 5.8,
    cues: [
      {
        from: 0.1,
        to: 3.1,
        text: '¿Alguna vez te preguntaste por qué\nlas ventanas de los aviones son redondas',
        highlights: ['ventanas', 'aviones', 'redondas'],
      },
      {
        from: 3.1,
        to: 5.5,
        text: 'y no cuadradas?',
        highlights: ['cuadradas?'],
      },
    ],
  },
  {
    id: 'scene-02-vintage',
    start: 5.8,
    end: 12.2,
    cues: [
      {
        from: 5.8,
        to: 8.2,
        text: 'No siempre fueron así.',
        highlights: ['siempre'],
      },
      {
        from: 8.2,
        to: 12.2,
        text: 'En los años cincuenta, algunos aviones\ncomerciales tenían ventanas cuadradas.',
        highlights: ['cincuenta,', 'ventanas', 'cuadradas.'],
      },
    ],
  },
  {
    id: 'scene-03-problem',
    start: 12.2,
    end: 19.2,
    cues: [
      {
        from: 12.2,
        to: 16.0,
        text: 'Pero en 1954, varios accidentes\ndel avión De Havilland Comet',
        highlights: ['1954,', 'Havilland', 'Comet'],
      },
      {
        from: 16.0,
        to: 19.2,
        text: 'revelaron un problema peligroso.',
        highlights: ['problema', 'peligroso.'],
      },
    ],
  },
  {
    id: 'scene-04-cracks',
    start: 19.2,
    end: 32.5,
    cues: [
      {
        from: 19.2,
        to: 23.0,
        text: 'Durante cada vuelo, la cabina\nse presurizaba y despresurizaba.',
        highlights: ['presurizaba', 'despresurizaba.'],
      },
      {
        from: 23.0,
        to: 26.2,
        text: 'Eso generaba tensión repetida\nen el fuselaje.',
        highlights: ['tensión', 'repetida', 'fuselaje.'],
      },
      {
        from: 26.2,
        to: 29.4,
        text: 'Las esquinas de las ventanas cuadradas\nconcentraban demasiada tensión,',
        highlights: ['esquinas', 'concentraban', 'tensión,'],
      },
      {
        from: 29.4,
        to: 32.5,
        text: 'provocando pequeñas grietas que podían\ncrecer hasta causar una ruptura.',
        highlights: ['grietas', 'crecer', 'ruptura.'],
      },
    ],
  },
  {
    id: 'scene-05-solution',
    start: 32.5,
    end: 40.6,
    cues: [
      {
        from: 32.5,
        to: 36.8,
        text: 'Los ingenieros descubrieron que las\nventanas redondeadas distribuían mejor',
        highlights: ['ventanas', 'redondeadas', 'distribuían'],
      },
      {
        from: 36.8,
        to: 40.6,
        text: 'esa tensión y reducían\nel riesgo de fracturas.',
        highlights: ['tensión', 'reducían', 'fracturas.'],
      },
    ],
  },
  {
    id: 'scene-06-present',
    start: 40.6,
    end: 54.0,
    cues: [
      {
        from: 40.6,
        to: 45.2,
        text: 'Desde entonces, las ventanas redondas\nse convirtieron en un estándar comercial.',
        highlights: ['ventanas', 'redondas', 'estándar'],
      },
      {
        from: 45.2,
        to: 49.0,
        text: 'Así que la próxima vez que mires\npor la ventana de un avión,',
        highlights: ['próxima', 'ventana', 'avión,'],
      },
      {
        from: 49.0,
        to: 52.8,
        text: 'recordá que su forma puede marcar\nla diferencia entre seguridad y tragedia.',
        highlights: ['forma', 'seguridad', 'tragedia.'],
      },
    ],
  },
];
