import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {AUDIO_PATH, OVERLAP, PALETTE} from './config';
import {SCENES, sec} from './script';
import {Subtitle} from './components/Subtitle';
import {Scene01Mystery} from './scenes/Scene01Mystery';
import {Scene02Vintage} from './scenes/Scene02Vintage';
import {Scene03Problem} from './scenes/Scene03Problem';
import {Scene04Cracks} from './scenes/Scene04Cracks';
import {Scene05Solution} from './scenes/Scene05Solution';
import {Scene06Present} from './scenes/Scene06Present';

const SCENE_COMPONENTS = [
  Scene01Mystery,
  Scene02Vintage,
  Scene03Problem,
  Scene04Cracks,
  Scene05Solution,
  Scene06Present,
];

export const AirplaneWindowsShort: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark}}>
      <Audio src={staticFile(AUDIO_PATH)} />

      {SCENES.map((scene, idx) => {
        const SceneComponent = SCENE_COMPONENTS[idx];
        const fromFrame = Math.max(0, sec(scene.start) - (idx > 0 ? OVERLAP : 0));
        const endFrame = sec(scene.end);
        const durationInFrames = Math.max(1, endFrame - fromFrame);

        return (
          <Sequence
            key={scene.id}
            from={fromFrame}
            durationInFrames={durationInFrames}
            name={scene.id}
          >
            <SceneComponent scene={scene} />
          </Sequence>
        );
      })}

      {/* Viñeta cinematográfica suave */}
      <AbsoluteFill
        style={{
          pointerEvents: 'none',
          background:
            'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 58%, rgba(0,0,0,0.45) 100%)',
        }}
      />

      {/* Subtítulos en español sincronizados en zona segura */}
      <Subtitle />
    </AbsoluteFill>
  );
};
