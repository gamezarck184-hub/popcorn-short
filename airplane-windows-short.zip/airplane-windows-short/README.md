# AirplaneWindowsShort — Documental 2D en Remotion

Video vertical (`1080x1920`, `30 fps`, MP4 H.264) sobre ingeniería aeronáutica: *¿Por qué los aviones tienen ventanas redondas?*

## Comandos

```bash
npm install
npm run typecheck
npm run render
```

El video final se genera en `out/airplane-windows-short.mp4`.
