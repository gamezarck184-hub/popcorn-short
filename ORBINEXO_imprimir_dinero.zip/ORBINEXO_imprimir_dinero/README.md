# ORBINEXO — ¿Por qué los países no imprimen dinero para hacerse ricos?

Proyecto completo de Remotion (`1080x1920`, `30 FPS`, vertical 9:16) para YouTube Short.

## Narración
El archivo original se encuentra en `public/audio/voz.mp3` y se utiliza sin modificar ni renombrar.

## Renderizar en GitHub Codespaces
```bash
npm install
npm run render
```

El archivo final se generará en `out/ORBINEXO_imprimir_dinero.mp4`.
