import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const audioPath = path.resolve("public/audio/voz.mp3");
if (!fs.existsSync(audioPath)) {
  console.error("ERROR: Falta public/audio/voz.mp3");
  process.exit(1);
}

fs.mkdirSync("out", { recursive: true });

execSync(
  "npx remotion render src/index.ts OrbinexoImprimirDinero out/ORBINEXO_imprimir_dinero.mp4 --codec=h264 --audio-codec=aac --pixel-format=yuv420p",
  { stdio: "inherit" }
);
