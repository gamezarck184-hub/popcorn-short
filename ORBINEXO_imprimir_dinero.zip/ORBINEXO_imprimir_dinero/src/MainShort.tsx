import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useVideoConfig } from "remotion";
import { SCENES } from "./data/script";
import { CaptionsOverlay } from "./components/CaptionsOverlay";
import { Escena1Fabrica } from "./scenes/Escena1Fabrica";
import { Escena2LluviaRiqueza } from "./scenes/Escena2LluviaRiqueza";
import { Escena3DobleDinero } from "./scenes/Escena3DobleDinero";
import { Escena4Supermercado } from "./scenes/Escena4Supermercado";
import { Escena5Inflacion } from "./scenes/Escena5Inflacion";
import { Escena6PoderCompra } from "./scenes/Escena6PoderCompra";
import { Escena7Zimbabue } from "./scenes/Escena7Zimbabue";
import { Escena8VerdaderaRiqueza } from "./scenes/Escena8VerdaderaRiqueza";
import { Escena9Cierre } from "./scenes/Escena9Cierre";

const SCENE_COMPONENTS = [
  Escena1Fabrica,
  Escena2LluviaRiqueza,
  Escena3DobleDinero,
  Escena4Supermercado,
  Escena5Inflacion,
  Escena6PoderCompra,
  Escena7Zimbabue,
  Escena8VerdaderaRiqueza,
  Escena9Cierre,
];

export const MainShort: React.FC = () => {
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill style={{ backgroundColor: "#070B14" }}>
      <Audio src={staticFile("audio/voz.mp3")} volume={1} />
      <Audio src={staticFile("audio/bg_documental.wav")} volume={0.14} loop />

      {SCENES.map((scene, idx) => {
        const SceneComponent = SCENE_COMPONENTS[idx];
        const fromFrame = Math.round(scene.startSec * fps);
        const durationInFrames = Math.max(1, Math.round((scene.endSec - scene.startSec) * fps));

        return (
          <Sequence key={scene.id} from={fromFrame} durationInFrames={durationInFrames}>
            <SceneComponent />
            {idx === 0 && <Audio src={staticFile("audio/sfx_printer.wav")} volume={0.22} />}
            {idx === 4 && <Audio src={staticFile("audio/sfx_ding.wav")} volume={0.25} />}
            {idx > 0 && <Audio src={staticFile("audio/sfx_whoosh.wav")} volume={0.18} />}
          </Sequence>
        );
      })}

      <CaptionsOverlay />
    </AbsoluteFill>
  );
};
