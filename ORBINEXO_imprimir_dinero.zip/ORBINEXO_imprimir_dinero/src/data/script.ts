import { SceneDefinition, SubtitleSegment } from "../types";

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const EXACT_AUDIO_DURATION_SEC = 64.29;

export const SCENES: SceneDefinition[] = [
  { id: 1, name: "El gran interrogante", bannerText: "¿POR QUÉ NO IMPRIMIR MÁS DINERO?", startSec: 0.0, endSec: 5.5 },
  { id: 2, name: "La solución que parece perfecta", bannerText: "MÁS BILLETES ≠ MÁS RIQUEZA", startSec: 5.5, endSec: 12.1 },
  { id: 3, name: "Todos reciben más dinero", bannerText: "EL DOBLE DE DINERO", startSec: 12.1, endSec: 17.5 },
  { id: 4, name: "Los productos siguen siendo los mismos", bannerText: "MÁS DINERO. LOS MISMOS PRODUCTOS.", startSec: 17.5, endSec: 26.8 },
  { id: 5, name: "Los precios comienzan a subir", bannerText: "INFLACIÓN", startSec: 26.8, endSec: 33.4 },
  { id: 6, name: "Tu dinero vale menos", bannerText: "MÁS BILLETES, MENOS PODER DE COMPRA", startSec: 33.4, endSec: 41.2 },
  { id: 7, name: "El caso de Zimbabue", bannerText: "ZIMBABUE — HIPERINFLACIÓN", startSec: 41.2, endSec: 49.0 },
  { id: 8, name: "La verdadera riqueza", bannerText: "LA RIQUEZA SE PRODUCE", startSec: 49.0, endSec: 57.5 },
  { id: 9, name: "Cierre impactante", bannerText: "NO PODÉS IMPRIMIR RIQUEZA", startSec: 57.5, endSec: 64.29 },
];

export const SUBTITLES: SubtitleSegment[] = [
  { id: "sub-01", startSec: 0.0, endSec: 2.7, text: "Si un país puede imprimir dinero," },
  { id: "sub-02", startSec: 2.7, endSec: 5.5, text: "¿por qué no fabrica millones y acaba con la pobreza?" },
  { id: "sub-03", startSec: 5.5, endSec: 8.4, text: "Parece una solución sencilla, ¿verdad?" },
  { id: "sub-04", startSec: 8.4, endSec: 12.1, text: "Pero hay un problema: imprimir billetes no significa crear riqueza." },
  { id: "sub-05", startSec: 12.1, endSec: 17.5, text: "Imaginá que todos recibieran el doble de dinero de un día para otro." },
  { id: "sub-06", startSec: 17.5, endSec: 20.6, text: "Al principio parecería una buena noticia," },
  { id: "sub-07", startSec: 20.6, endSec: 24.0, text: "pero si la cantidad de productos y servicios sigue siendo la misma," },
  { id: "sub-08", startSec: 24.0, endSec: 26.8, text: "habría más dinero intentando comprar las mismas cosas." },
  { id: "sub-09", startSec: 26.8, endSec: 30.1, text: "Y cuando la demanda supera lo que se puede ofrecer," },
  { id: "sub-10", startSec: 30.1, endSec: 33.4, text: "los precios pueden empezar a subir. Eso se llama inflación." },
  { id: "sub-11", startSec: 33.4, endSec: 36.8, text: "Entonces, aunque tengas más billetes en el bolsillo," },
  { id: "sub-12", startSec: 36.8, endSec: 41.2, text: "quizás puedas comprar exactamente lo mismo o incluso menos que antes." },
  { id: "sub-13", startSec: 41.2, endSec: 44.6, text: "Esto puede verse en casos como el de Zimbabue," },
  { id: "sub-14", startSec: 44.6, endSec: 49.0, text: "donde la emisión descontrolada de dinero contribuyó a una hiperinflación histórica." },
  { id: "sub-15", startSec: 49.0, endSec: 52.8, text: "Por eso, un país no se vuelve rico por imprimir más billetes." },
  { id: "sub-16", startSec: 52.8, endSec: 57.5, text: "La verdadera riqueza está en producir bienes, ofrecer servicios y desarrollar su economía." },
  { id: "sub-17", startSec: 57.5, endSec: 60.8, text: "Porque podés imprimir todo el dinero que quieras," },
  { id: "sub-18", startSec: 60.8, endSec: 64.29, text: "pero no podés imprimir alimentos, casas ni electricidad." },
];
