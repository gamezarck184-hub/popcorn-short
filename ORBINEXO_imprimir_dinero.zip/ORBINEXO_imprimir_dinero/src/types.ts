export interface SubtitleSegment {
  id: string;
  startSec: number;
  endSec: number;
  text: string;
}

export interface SceneDefinition {
  id: number;
  name: string;
  bannerText: string;
  startSec: number;
  endSec: number;
}
