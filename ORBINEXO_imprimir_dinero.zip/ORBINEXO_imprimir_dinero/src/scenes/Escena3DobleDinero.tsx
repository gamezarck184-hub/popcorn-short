import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { StickmanOrbinexo } from "../components/StickmanOrbinexo";

export const Escena3DobleDinero: React.FC = () => {
  const frame = useCurrentFrame();
  const cityPanX = interpolate(frame, [0, 160], [0, -140]);
  const openEnvelope = interpolate(frame, [35, 65], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <SceneShell bannerText="EL DOBLE DE DINERO">
      <div
        style={{
          position: "absolute",
          top: 280,
          left: 40,
          display: "flex",
          gap: 26,
          transform: `translateX(${cityPanX}px)`,
        }}
      >
        {[280, 340, 260, 320, 290].map((h, idx) => (
          <div
            key={idx}
            style={{
              width: 210,
              height: h,
              backgroundColor: "#1E293B",
              border: "3px solid #475569",
              borderRadius: "16px 16px 0 0",
              padding: 18,
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
            }}
          >
            <div style={{ fontSize: 22, fontWeight: 800, color: "#94A3B8" }}>HOGAR #{idx + 1}</div>
            <div
              style={{
                backgroundColor: "#14532D",
                border: "2px solid #4ADE80",
                borderRadius: 12,
                padding: "10px 14px",
                textAlign: "center",
                fontSize: 26,
                fontWeight: 900,
                color: "#86EFAC",
              }}
            >
              ✉️ 2X DINERO
            </div>
          </div>
        ))}
      </div>

      <div
        style={{
          position: "absolute",
          top: 690,
          left: 140,
          width: 340,
          backgroundColor: "#FEF3C7",
          border: "4px solid #D97706",
          borderRadius: 20,
          padding: 24,
          color: "#78350F",
          transform: `scale(${0.9 + openEnvelope * 0.15})`,
        }}
      >
        <div style={{ fontSize: 24, fontWeight: 900 }}>TU SOBRE HOY:</div>
        <div style={{ fontSize: 44, fontWeight: 900, color: "#15803D", marginTop: 8 }}>
          100 → 200 💰
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 390, right: 160 }}>
        <StickmanOrbinexo scale={1.25} expression="excited" pose="celebrate" flipX />
      </div>
    </SceneShell>
  );
};
