import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { StickmanOrbinexo } from "../components/StickmanOrbinexo";

export const Escena2LluviaRiqueza: React.FC = () => {
  const frame = useCurrentFrame();
  const splitProgress = interpolate(frame, [85, 110], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <SceneShell bannerText="MÁS BILLETES ≠ MÁS RIQUEZA">
      {splitProgress < 0.95 && (
        <div style={{ position: "absolute", inset: 0, opacity: 1 - splitProgress }}>
          {Array.from({ length: 14 }).map((_, i) => {
            const fallY = ((frame * 12 + i * 135) % 1100) + 220;
            const leftX = 90 + ((i * 173) % 860);
            const rot = Math.sin(frame * 0.1 + i) * 22;
            return (
              <div
                key={i}
                style={{
                  position: "absolute",
                  top: fallY,
                  left: leftX,
                  width: 92,
                  height: 44,
                  backgroundColor: "#4ADE80",
                  border: "3px solid #15803D",
                  borderRadius: 8,
                  transform: `rotate(${rot}deg)`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#052E16",
                  fontWeight: 900,
                  fontSize: 22,
                }}
              >
                $100
              </div>
            );
          })}
          <div style={{ position: "absolute", bottom: 400, left: 420 }}>
            <StickmanOrbinexo scale={1.3} expression="excited" pose="celebrate" />
          </div>
        </div>
      )}

      {splitProgress > 0.05 && (
        <div
          style={{
            position: "absolute",
            top: 290,
            left: 60,
            right: 60,
            opacity: splitProgress,
            display: "flex",
            flexDirection: "column",
            gap: 28,
          }}
        >
          <div style={{ display: "flex", gap: 24, justifyContent: "space-between" }}>
            <div
              style={{
                flex: 1,
                backgroundColor: "#052E16",
                border: "4px solid #22C55E",
                borderRadius: 24,
                padding: 26,
                textAlign: "center",
              }}
            >
              <div style={{ fontSize: 28, fontWeight: 900, color: "#4ADE80" }}>PAPEL IMPRESO</div>
              <div style={{ fontSize: 64, fontWeight: 900, margin: "18px 0" }}>$$$$$$</div>
              <div style={{ fontSize: 24, color: "#BBF7D0" }}>Crece sin límite</div>
            </div>

            <div
              style={{
                flex: 1,
                backgroundColor: "#1E293B",
                border: "4px solid #F59E0B",
                borderRadius: 24,
                padding: 26,
                textAlign: "center",
              }}
            >
              <div style={{ fontSize: 28, fontWeight: 900, color: "#FBBF24" }}>BIENES REALES</div>
              <div style={{ fontSize: 26, margin: "18px 0", lineHeight: 1.5 }}>
                🍞 2 panes
                <br />🏠 1 casa
                <br />📦 3 productos
              </div>
              <div style={{ fontSize: 24, color: "#FDE68A" }}>Siguen limitados</div>
            </div>
          </div>

          <div style={{ display: "flex", justifyContent: "center", marginTop: 20 }}>
            <StickmanOrbinexo scale={1.15} expression="worried" pose="point" />
          </div>
        </div>
      )}
    </SceneShell>
  );
};
