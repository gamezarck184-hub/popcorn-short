import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { StickmanOrbinexo } from "../components/StickmanOrbinexo";

export const Escena8VerdaderaRiqueza: React.FC = () => {
  const frame = useCurrentFrame();
  const walkX = interpolate(frame, [0, 240], [-180, 180]);

  const pillars = [
    { icon: "🏭", title: "PRODUCIR BIENES", desc: "Industria y manufactura" },
    { icon: "🌾", title: "COSECHAR ALIMENTOS", desc: "Agricultura y campo" },
    { icon: "🏗️", title: "CONSTRUIR VIVIENDAS", desc: "Infraestructura real" },
    { icon: "💼", title: "OFRECER SERVICIOS", desc: "Trabajo y desarrollo" },
  ];

  return (
    <SceneShell bannerText="LA RIQUEZA SE PRODUCE" accentColor="#22C55E">
      <div
        style={{
          position: "absolute",
          top: 285,
          left: 65,
          right: 65,
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 22,
        }}
      >
        {pillars.map((item, idx) => (
          <div
            key={idx}
            style={{
              backgroundColor: "rgba(30, 41, 59, 0.94)",
              border: "3px solid #22C55E",
              borderRadius: 22,
              padding: 24,
              display: "flex",
              flexDirection: "column",
              gap: 10,
            }}
          >
            <div style={{ fontSize: 54 }}>{item.icon}</div>
            <div style={{ fontSize: 25, fontWeight: 900, color: "#4ADE80" }}>{item.title}</div>
            <div style={{ fontSize: 22, color: "#E2E8F0" }}>{item.desc}</div>
          </div>
        ))}
      </div>

      <div style={{ position: "absolute", bottom: 390, left: 420 + walkX }}>
        <StickmanOrbinexo scale={1.2} expression="confident" pose="walk" />
      </div>
    </SceneShell>
  );
};
