import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { StickmanOrbinexo } from "../components/StickmanOrbinexo";

export const Escena4Supermercado: React.FC = () => {
  const frame = useCurrentFrame();
  const afterPhase = interpolate(frame, [110, 145], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const moneyCount = afterPhase > 0.5 ? 12 : 4;

  return (
    <SceneShell bannerText="MÁS DINERO. LOS MISMOS PRODUCTOS.">
      <div
        style={{
          position: "absolute",
          top: 280,
          left: 70,
          right: 70,
          backgroundColor: "#1E293B",
          border: "4px solid #64748B",
          borderRadius: 24,
          padding: 28,
        }}
      >
        <div style={{ fontSize: 28, fontWeight: 900, color: "#38BDF8", marginBottom: 18 }}>
          SUPERMERCADO — STOCK DISPONIBLE (SIN CAMBIOS)
        </div>
        <div style={{ display: "flex", justifyContent: "space-around" }}>
          {["🍞 PAN", "🥛 LECHE", "🍎 FRUTA", "🧀 QUESO"].map((item, idx) => (
            <div
              key={idx}
              style={{
                width: 190,
                height: 150,
                backgroundColor: "#0F172A",
                border: "3px solid #334155",
                borderRadius: 16,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 28,
                fontWeight: 800,
              }}
            >
              {item}
            </div>
          ))}
        </div>
      </div>

      <div
        style={{
          position: "absolute",
          top: 575,
          left: 70,
          right: 70,
          backgroundColor: "rgba(15, 23, 42, 0.92)",
          border: "3px solid #22C55E",
          borderRadius: 24,
          padding: 24,
        }}
      >
        <div style={{ fontSize: 28, fontWeight: 900, color: "#4ADE80", marginBottom: 14 }}>
          {afterPhase > 0.5 ? "DESPUÉS: MUCHOS MÁS BILLETES" : "ANTES: POCOS BILLETES"}
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 14 }}>
          {Array.from({ length: moneyCount }).map((_, idx) => (
            <div
              key={idx}
              style={{
                padding: "12px 20px",
                backgroundColor: "#16A34A",
                borderRadius: 10,
                fontWeight: 900,
                fontSize: 26,
                color: "#FFFFFF",
              }}
            >
              $100
            </div>
          ))}
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 390, left: 220 }}>
        <StickmanOrbinexo scale={1.15} expression="surprised" pose="point" />
      </div>
      <div style={{ position: "absolute", bottom: 390, right: 220 }}>
        <StickmanOrbinexo scale={1.15} expression="excited" pose="point" flipX />
      </div>
    </SceneShell>
  );
};
