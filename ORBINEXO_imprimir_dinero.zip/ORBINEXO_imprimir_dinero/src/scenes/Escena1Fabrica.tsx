import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { StickmanOrbinexo } from "../components/StickmanOrbinexo";

export const Escena1Fabrica: React.FC = () => {
  const frame = useCurrentFrame();
  const beltOffset = (frame * 14) % 140;
  const zoomToCharacter = interpolate(frame, [95, 135], [1, 1.25], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <SceneShell bannerText="¿POR QUÉ NO IMPRIMIR MÁS DINERO?">
      <div style={{ position: "absolute", inset: 0, transform: `scale(${zoomToCharacter})` }}>
        <div
          style={{
            position: "absolute",
            top: 290,
            left: 80,
            width: 480,
            height: 360,
            backgroundColor: "#334155",
            borderRadius: 24,
            border: "5px solid #64748B",
            padding: 24,
            boxShadow: "0 20px 45px rgba(0,0,0,0.4)",
          }}
        >
          <div style={{ fontSize: 24, fontWeight: 800, color: "#94A3B8", marginBottom: 16 }}>
            IMPRENTA NACIONAL
          </div>
          <div style={{ display: "flex", gap: 28, justifyContent: "center", marginTop: 20 }}>
            {[0, 1].map((r) => (
              <div
                key={r}
                style={{
                  width: 110,
                  height: 110,
                  borderRadius: "50%",
                  backgroundColor: "#1E293B",
                  border: "8px solid #22C55E",
                  transform: `rotate(${frame * (r === 0 ? 12 : -12)}deg)`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <div style={{ width: 70, height: 8, backgroundColor: "#4ADE80" }} />
              </div>
            ))}
          </div>
          <div
            style={{
              marginTop: 34,
              height: 54,
              backgroundColor: "#0F172A",
              borderRadius: 12,
              overflow: "hidden",
              position: "relative",
            }}
          >
            {[0, 1, 2, 3, 4].map((b) => (
              <div
                key={b}
                style={{
                  position: "absolute",
                  top: 9,
                  left: b * 140 + beltOffset - 120,
                  width: 96,
                  height: 36,
                  backgroundColor: "#4ADE80",
                  border: "2px solid #14532D",
                  borderRadius: 6,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#052E16",
                  fontWeight: 900,
                }}
              >
                $$$
              </div>
            ))}
          </div>
        </div>

        <div
          style={{
            position: "absolute",
            top: 710,
            left: 90,
            width: 390,
            height: 220,
            backgroundColor: "#16A34A",
            borderRadius: "180px 180px 24px 24px",
            border: "5px solid #86EFAC",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 34,
            fontWeight: 900,
            color: "#ECFDF5",
          }}
        >
          MILLONES DE BILLETES
        </div>

        <div
          style={{
            position: "absolute",
            top: 680,
            right: 75,
            width: 360,
            backgroundColor: "rgba(30, 41, 59, 0.92)",
            border: "3px solid #F59E0B",
            borderRadius: 20,
            padding: 22,
          }}
        >
          <div style={{ fontSize: 22, fontWeight: 800, color: "#FCD34D", marginBottom: 12 }}>
            NECESIDADES REALES
          </div>
          <div style={{ fontSize: 26, color: "#E2E8F0", lineHeight: 1.4 }}>
            • Viviendas precarias
            <br />• Escasez de alimentos
            <br />• Falta de empleo
          </div>
        </div>

        <div style={{ position: "absolute", bottom: 390, left: 420 }}>
          <StickmanOrbinexo scale={1.25} expression="surprised" pose="point" />
        </div>
      </div>
    </SceneShell>
  );
};
