import React from "react";
import { useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { StickmanOrbinexo } from "../components/StickmanOrbinexo";

export const Escena5Inflacion: React.FC = () => {
  const frame = useCurrentFrame();
  const currentPrice = frame < 65 ? 10 : frame < 130 ? 20 : 30;
  const tagBounce = Math.sin(frame * 0.35) * 6;

  return (
    <SceneShell bannerText="INFLACIÓN" accentColor="#EF4444">
      <div
        style={{
          position: "absolute",
          top: 300,
          left: 110,
          right: 110,
          backgroundColor: "#1E293B",
          border: "4px solid #EF4444",
          borderRadius: 28,
          padding: 36,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 24,
        }}
      >
        <div style={{ fontSize: 34, fontWeight: 900, color: "#FCA5A5" }}>
          DEMANDA ALTA + OFERTA IGUAL
        </div>
        <div style={{ fontSize: 96 }}>🍞</div>
        <div
          style={{
            backgroundColor: "#DC2626",
            color: "#FFFFFF",
            padding: "20px 52px",
            borderRadius: 20,
            fontSize: 74,
            fontWeight: 900,
            transform: `translateY(${tagBounce}px)`,
            boxShadow: "0 14px 30px rgba(220,38,38,0.45)",
          }}
        >
          PRECIO: {currentPrice}
        </div>
        <div style={{ fontSize: 28, color: "#E2E8F0", fontWeight: 700 }}>
          10 → 20 → 30 unidades
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 390, left: 420 }}>
        <StickmanOrbinexo scale={1.25} expression="worried" pose="point" />
      </div>
    </SceneShell>
  );
};
