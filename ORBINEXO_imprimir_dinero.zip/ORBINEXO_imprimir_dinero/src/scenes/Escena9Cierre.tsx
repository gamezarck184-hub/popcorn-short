import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { StickmanOrbinexo } from "../components/StickmanOrbinexo";

export const Escena9Cierre: React.FC = () => {
  const frame = useCurrentFrame();
  const focusElements = interpolate(frame, [60, 120], [1, 1.12], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <SceneShell bannerText="NO PODÉS IMPRIMIR RIQUEZA" accentColor="#22C55E">
      <div
        style={{
          position: "absolute",
          top: 290,
          left: 65,
          right: 65,
          display: "flex",
          gap: 24,
          alignItems: "stretch",
        }}
      >
        <div
          style={{
            flex: 1,
            backgroundColor: "#1E293B",
            border: "3px solid #64748B",
            borderRadius: 24,
            padding: 24,
            textAlign: "center",
          }}
        >
          <div style={{ fontSize: 24, fontWeight: 900, color: "#94A3B8" }}>MÁQUINA</div>
          <div style={{ fontSize: 56, margin: "16px 0" }}>🖨️💵</div>
          <div style={{ fontSize: 24, color: "#CBD5E1" }}>Solo imprime papel</div>
        </div>

        <div
          style={{
            flex: 1.2,
            backgroundColor: "#052E16",
            border: "4px solid #22C55E",
            borderRadius: 24,
            padding: 24,
            transform: `scale(${focusElements})`,
          }}
        >
          <div style={{ fontSize: 24, fontWeight: 900, color: "#4ADE80", marginBottom: 12 }}>
            NO SE IMPRIMEN:
          </div>
          <div style={{ fontSize: 30, fontWeight: 800, lineHeight: 1.55 }}>
            🍎 Alimentos
            <br />🏠 Casas
            <br />⚡ Electricidad
          </div>
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 390, left: 420 }}>
        <StickmanOrbinexo scale={1.3} expression="confident" pose="idle" />
      </div>

      <div
        style={{
          position: "absolute",
          bottom: 90,
          right: 54,
          fontSize: 24,
          fontWeight: 800,
          letterSpacing: 3,
          color: "rgba(248, 250, 252, 0.55)",
        }}
      >
        ORBINEXO
      </div>
    </SceneShell>
  );
};
