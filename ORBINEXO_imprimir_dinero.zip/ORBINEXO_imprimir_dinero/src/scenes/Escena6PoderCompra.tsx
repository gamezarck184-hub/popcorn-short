import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { StickmanOrbinexo } from "../components/StickmanOrbinexo";

export const Escena6PoderCompra: React.FC = () => {
  const frame = useCurrentFrame();
  const transition = interpolate(frame, [95, 135], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <SceneShell bannerText="MÁS BILLETES, MENOS PODER DE COMPRA" accentColor="#F59E0B">
      <div
        style={{
          position: "absolute",
          top: 300,
          left: 70,
          right: 70,
          display: "flex",
          gap: 24,
        }}
      >
        <div
          style={{
            flex: 1,
            backgroundColor: "#1E293B",
            border: "3px solid #22C55E",
            borderRadius: 24,
            padding: 24,
            opacity: 1 - transition * 0.45,
          }}
        >
          <div style={{ fontSize: 26, fontWeight: 900, color: "#4ADE80" }}>ANTES</div>
          <div style={{ fontSize: 26, marginTop: 14, lineHeight: 1.5 }}>
            🛒 Cesta llena:
            <br />🍞 Pan
            <br />🥛 Leche
            <br />🍎 Frutas
            <br />🧀 Queso
          </div>
        </div>

        <div
          style={{
            flex: 1,
            backgroundColor: "#1E293B",
            border: "4px solid #EF4444",
            borderRadius: 24,
            padding: 24,
            transform: `scale(${0.95 + transition * 0.08})`,
          }}
        >
          <div style={{ fontSize: 26, fontWeight: 900, color: "#F87171" }}>AHORA (CON MÁS BILLETES)</div>
          <div style={{ fontSize: 26, marginTop: 14, lineHeight: 1.5 }}>
            🛒 Cesta casi vacía:
            <br />🍞 Solo 1 pan
            <br />❌ No alcanza para más
          </div>
        </div>
      </div>

      <div
        style={{
          position: "absolute",
          bottom: 420,
          left: 150,
          backgroundColor: "#15803D",
          border: "3px solid #86EFAC",
          borderRadius: 16,
          padding: "16px 26px",
          fontSize: 30,
          fontWeight: 900,
        }}
      >
        💵💵💵 FAJO LLENO
      </div>

      <div style={{ position: "absolute", bottom: 390, right: 180 }}>
        <StickmanOrbinexo scale={1.25} expression="worried" pose="hold" flipX />
      </div>
    </SceneShell>
  );
};
