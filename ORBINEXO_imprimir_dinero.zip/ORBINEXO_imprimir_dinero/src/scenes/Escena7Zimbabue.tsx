import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { StickmanOrbinexo } from "../components/StickmanOrbinexo";

export const Escena7Zimbabue: React.FC = () => {
  const frame = useCurrentFrame();
  const mapZoom = interpolate(frame, [0, 120], [1, 1.45], {
    extrapolateRight: "clamp",
  });
  const labelStep = Math.floor(frame / 18) % 4;
  const priceLabels = ["SUBE", "SUBE MÁS", "HIPERINFLACIÓN", "PÉRDIDA DE VALOR"];

  return (
    <SceneShell bannerText="ZIMBABUE — HIPERINFLACIÓN" accentColor="#F59E0B">
      <div
        style={{
          position: "absolute",
          top: 285,
          left: 90,
          width: 440,
          height: 460,
          backgroundColor: "#0F172A",
          border: "3px solid #475569",
          borderRadius: 24,
          overflow: "hidden",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <svg
          width="360"
          height="380"
          viewBox="0 0 360 380"
          style={{ transform: `scale(${mapZoom})`, transformOrigin: "210px 255px" }}
        >
          <path
            d="M120 35 L210 40 L255 110 L290 165 L245 250 L205 335 L165 330 L145 245 L85 190 L80 110 Z"
            fill="#334155"
            stroke="#94A3B8"
            strokeWidth="4"
          />
          <circle cx="212" cy="255" r="16" fill="#EF4444" stroke="#FEF08A" strokeWidth="4" />
          <text x="155" y="292" fill="#FDE047" fontSize="18" fontWeight="800">
            ZIMBABUE
          </text>
        </svg>
      </div>

      <div
        style={{
          position: "absolute",
          top: 285,
          right: 80,
          width: 410,
          display: "flex",
          flexDirection: "column",
          gap: 22,
        }}
      >
        <div
          style={{
            backgroundColor: "#1E293B",
            border: "3px solid #F59E0B",
            borderRadius: 20,
            padding: 22,
          }}
        >
          <div style={{ fontSize: 22, fontWeight: 800, color: "#FCD34D" }}>CASO HISTÓRICO</div>
          <div style={{ fontSize: 28, fontWeight: 900, marginTop: 8 }}>
            Billetes de gran denominación
          </div>
          <div style={{ fontSize: 22, color: "#CBD5E1", marginTop: 8 }}>
            Emisión monetaria descontrolada
          </div>
        </div>

        <div
          style={{
            backgroundColor: "#7F1D1D",
            border: "3px solid #FCA5A5",
            borderRadius: 20,
            padding: 22,
            textAlign: "center",
          }}
        >
          <div style={{ fontSize: 22, color: "#FECACA", fontWeight: 700 }}>ETIQUETAS DE PRECIOS</div>
          <div style={{ fontSize: 34, fontWeight: 900, color: "#FFFFFF", marginTop: 8 }}>
            {priceLabels[labelStep]}
          </div>
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 390, left: 420 }}>
        <StickmanOrbinexo scale={1.2} expression="worried" pose="point" />
      </div>
    </SceneShell>
  );
};
