import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { SUBTITLES } from "../data/script";

export const CaptionsOverlay: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const currentSec = frame / fps;

  const active = SUBTITLES.find((s) => currentSec >= s.startSec && currentSec < s.endSec);
  if (!active) return null;

  return (
    <div
      style={{
        position: "absolute",
        bottom: 200,
        left: 52,
        right: 52,
        display: "flex",
        justifyContent: "center",
        pointerEvents: "none",
      }}
    >
      <div
        style={{
          backgroundColor: "rgba(9, 13, 22, 0.88)",
          color: "#F8FAFC",
          padding: "20px 30px",
          borderRadius: 20,
          border: "2px solid rgba(34, 197, 94, 0.55)",
          fontSize: 40,
          fontWeight: 800,
          lineHeight: 1.25,
          textAlign: "center",
          fontFamily: "Inter, system-ui, sans-serif",
          boxShadow: "0 12px 30px rgba(0, 0, 0, 0.5)",
        }}
      >
        {active.text}
      </div>
    </div>
  );
};
