import React from "react";
import { interpolate, useCurrentFrame } from "remotion";

export type StickmanExpression = "neutral" | "surprised" | "excited" | "worried" | "confident";
export type StickmanPose = "idle" | "walk" | "point" | "celebrate" | "hold";

interface StickmanOrbinexoProps {
  scale?: number;
  expression?: StickmanExpression;
  pose?: StickmanPose;
  flipX?: boolean;
  x?: number;
  y?: number;
}

export const StickmanOrbinexo: React.FC<StickmanOrbinexoProps> = ({
  scale = 1,
  expression = "neutral",
  pose = "idle",
  flipX = false,
  x = 0,
  y = 0,
}) => {
  const frame = useCurrentFrame();

  const walkSwing = pose === "walk" ? Math.sin(frame * 0.35) * 34 : Math.sin(frame * 0.08) * 4;
  const bobY =
    pose === "celebrate"
      ? -Math.abs(Math.sin(frame * 0.3)) * 18
      : interpolate(Math.abs(Math.sin(frame * 0.16)), [0, 1], [0, -5]);

  const leftArmAngle =
    pose === "celebrate"
      ? -135 + Math.sin(frame * 0.35) * 14
      : pose === "point"
      ? 45
      : pose === "hold"
      ? -15
      : 35 + Math.sin(frame * 0.22) * 18;

  const rightArmAngle =
    pose === "celebrate"
      ? -45 - Math.sin(frame * 0.35) * 14
      : pose === "point"
      ? -30 + Math.sin(frame * 0.2) * 6
      : pose === "hold"
      ? -165
      : 145 - Math.sin(frame * 0.22) * 18;

  const leftHandX = 78 + Math.cos((leftArmAngle * Math.PI) / 180) * 58;
  const leftHandY = 162 + Math.sin((leftArmAngle * Math.PI) / 180) * 58;
  const rightHandX = 162 + Math.cos((rightArmAngle * Math.PI) / 180) * 58;
  const rightHandY = 162 + Math.sin((rightArmAngle * Math.PI) / 180) * 58;

  return (
    <div
      style={{
        transform: `translate(${x}px, ${y + bobY}px) scale(${flipX ? -scale : scale}, ${scale})`,
        transformOrigin: "center bottom",
        display: "inline-block",
      }}
    >
      <svg width={240} height={370} viewBox="0 0 240 370" style={{ overflow: "visible" }}>
        <ellipse cx="120" cy="354" rx="54" ry="10" fill="rgba(0,0,0,0.32)" />
        <line x1="104" y1="240" x2={104 + walkSwing} y2="348" stroke="#0B0F19" strokeWidth="13" strokeLinecap="round" />
        <line x1="136" y1="240" x2={136 - walkSwing} y2="348" stroke="#0B0F19" strokeWidth="13" strokeLinecap="round" />
        <path
          d="M74 144 Q120 130 166 144 L176 244 L64 244 Z"
          fill="#16A34A"
          stroke="#0B0F19"
          strokeWidth="6"
          strokeLinejoin="round"
        />
        <path d="M90 144 Q120 168 150 144" fill="none" stroke="#14532D" strokeWidth="5" strokeLinecap="round" />
        <line x1="108" y1="156" x2="108" y2="184" stroke="#DCFCE7" strokeWidth="3.5" strokeLinecap="round" />
        <line x1="132" y1="156" x2="132" y2="184" stroke="#DCFCE7" strokeWidth="3.5" strokeLinecap="round" />
        <line x1="78" y1="162" x2={leftHandX} y2={leftHandY} stroke="#0B0F19" strokeWidth="11" strokeLinecap="round" />
        <line x1="162" y1="162" x2={rightHandX} y2={rightHandY} stroke="#0B0F19" strokeWidth="11" strokeLinecap="round" />
        <circle cx="120" cy="82" r="52" fill="#FFFFFF" stroke="#0B0F19" strokeWidth="6.5" />
        {expression === "surprised" && (
          <>
            <circle cx="101" cy="76" r="8.5" fill="#0B0F19" />
            <circle cx="139" cy="76" r="8.5" fill="#0B0F19" />
            <circle cx="103" cy="73" r="2.8" fill="#FFFFFF" />
            <circle cx="141" cy="73" r="2.8" fill="#FFFFFF" />
            <ellipse cx="120" cy="103" rx="9" ry="12" fill="#0B0F19" />
          </>
        )}
        {expression === "excited" && (
          <>
            <path d="M91 76 Q101 64 111 76" fill="none" stroke="#0B0F19" strokeWidth="5" strokeLinecap="round" />
            <path d="M129 76 Q139 64 149 76" fill="none" stroke="#0B0F19" strokeWidth="5" strokeLinecap="round" />
            <path d="M97 95 Q120 119 143 95 Z" fill="#0B0F19" />
          </>
        )}
        {expression === "worried" && (
          <>
            <circle cx="101" cy="79" r="6" fill="#0B0F19" />
            <circle cx="139" cy="79" r="6" fill="#0B0F19" />
            <line x1="90" y1="64" x2="111" y2="70" stroke="#0B0F19" strokeWidth="4.5" strokeLinecap="round" />
            <line x1="150" y1="64" x2="129" y2="70" stroke="#0B0F19" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M99 106 Q120 93 141 106" fill="none" stroke="#0B0F19" strokeWidth="5" strokeLinecap="round" />
          </>
        )}
        {(expression === "neutral" || expression === "confident") && (
          <>
            <circle cx="101" cy="76" r="6.5" fill="#0B0F19" />
            <circle cx="139" cy="76" r="6.5" fill="#0B0F19" />
            <path
              d={expression === "confident" ? "M98 96 Q120 112 142 96" : "M102 99 Q120 106 138 99"}
              fill="none"
              stroke="#0B0F19"
              strokeWidth="5"
              strokeLinecap="round"
            />
          </>
        )}
      </svg>
    </div>
  );
};
