import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";

interface SceneShellProps {
  bannerText: string;
  accentColor?: string;
  children: React.ReactNode;
}

export const SceneShell: React.FC<SceneShellProps> = ({
  bannerText,
  accentColor = "#22C55E",
  children,
}) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();

  const enterScale = spring({ frame, fps, config: { damping: 15, stiffness: 120 } });
  const cameraZoom = interpolate(frame, [0, durationInFrames], [1.0, 1.045], {
    extrapolateRight: "clamp",
  });
  const fadeIn = interpolate(frame, [0, 8], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(circle at 50% 25%, #1E293B 0%, #0F172A 65%, #070B14 100%)",
        fontFamily: "Inter, system-ui, -apple-system, sans-serif",
        color: "#F8FAFC",
        opacity: fadeIn,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage:
            "linear-gradient(rgba(148,163,184,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.06) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
        }}
      />
      <AbsoluteFill style={{ transform: `scale(${cameraZoom})` }}>{children}</AbsoluteFill>
      <div
        style={{
          position: "absolute",
          top: 96,
          left: 48,
          right: 48,
          display: "flex",
          justifyContent: "center",
          transform: `scale(${enterScale})`,
        }}
      >
        <div
          style={{
            backgroundColor: "rgba(15, 23, 42, 0.9)",
            border: `3px solid ${accentColor}`,
            borderRadius: 20,
            padding: "18px 30px",
            fontSize: 34,
            fontWeight: 900,
            letterSpacing: 0.8,
            textAlign: "center",
            color: "#FFFFFF",
            boxShadow: "0 14px 34px rgba(0,0,0,0.45)",
          }}
        >
          {bannerText}
        </div>
      </div>
    </AbsoluteFill>
  );
};
