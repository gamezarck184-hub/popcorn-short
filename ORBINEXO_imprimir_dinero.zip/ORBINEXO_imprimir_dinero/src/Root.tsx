import React from "react";
import { Composition, staticFile } from "remotion";
import { getAudioDurationInSeconds } from "@remotion/media-utils";
import { EXACT_AUDIO_DURATION_SEC, FPS, HEIGHT, WIDTH } from "./data/script";
import { MainShort } from "./MainShort";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="OrbinexoImprimirDinero"
      component={MainShort}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      durationInFrames={Math.ceil(EXACT_AUDIO_DURATION_SEC * FPS)}
      calculateMetadata={async () => {
        try {
          const duration = await getAudioDurationInSeconds(staticFile("audio/voz.mp3"));
          return {
            durationInFrames: Math.ceil(duration * FPS),
          };
        } catch {
          return {
            durationInFrames: Math.ceil(EXACT_AUDIO_DURATION_SEC * FPS),
          };
        }
      }}
    />
  );
};
