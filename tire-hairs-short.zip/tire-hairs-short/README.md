# TireHairsShort — Proyecto Remotion

YouTube Short documental 2D (`1080x1920`, `30 fps`, H.264) sobre por qué los neumáticos nuevos tienen pequeños filamentos de goma.

## Ejecución en GitHub Codespaces o entorno local

1. Instalar dependencias:
```bash
npm install
```

2. Abrir vista previa en vivo (Remotion Studio):
```bash
npm run dev
```

3. Renderizar el video final (`out/tire-hairs-short.mp4`):
```bash
npm run render
```
