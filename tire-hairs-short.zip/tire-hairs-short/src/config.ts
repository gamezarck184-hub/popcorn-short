export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

// Audio real: 39.81s (1194 frames) + 1.69s de cierre visual = 41.5s
export const AUDIO_DURATION_SEC = 39.81;
export const DURATION_SEC = 41.5;
export const TOTAL_FRAMES = Math.round(DURATION_SEC * FPS); // 1245 frames

export const OVERLAP = 12;
export const GROUND = 1430;
export const AUDIO_PATH = 'audio/narration.mp3';

export const PALETTE = {
  bgDark: '#0A0D10',
  bgPanel: '#13181E',
  bgSteel: '#1E252D',
  metalLight: '#8E99A4',
  metalMid: '#525C66',
  metalDark: '#2A3138',
  rubber: '#15181B',
  rubberHighlight: '#2E343B',
  rubberHot: '#D95338',
  greenPrimary: '#22C55E',
  greenDark: '#14532D',
  greenSweater: '#1B6B3A',
  greenSweaterDark: '#114726',
  greenSweaterLight: '#2E8B52',
  white: '#F8FAFC',
  ink: '#090B0E',
  yellowAccent: '#FACC15',
  airCyan: '#7DD3FC',
};
