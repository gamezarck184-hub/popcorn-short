import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneConfig} from '../script';
import {SceneHeader} from '../components/SceneHeader';

export const Scene03Manufacturing: React.FC<{scene: SceneConfig}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const pressProgress = interpolate(frame, [20, 95], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const vulcanize = interpolate(frame, [95, durationInFrames - 15], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const topMoldY = interpolate(pressProgress, [0, 1], [470, 745]);
  const bottomMoldY = interpolate(pressProgress, [0, 1], [1320, 1045]);

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark}}>
      <svg width="1080" height="1920" viewBox="0 0 1080 1920">
        <defs>
          <linearGradient id="steelGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#262E37" />
            <stop offset="50%" stopColor="#4B5563" />
            <stop offset="100%" stopColor="#262E37" />
          </linearGradient>
        </defs>

        <rect x="130" y="390" width="55" height="1060" fill="#181E25" stroke="#334155" strokeWidth="3" />
        <rect x="895" y="390" width="55" height="1060" fill="#181E25" stroke="#334155" strokeWidth="3" />

        <g transform="translate(540, 965)">
          <rect
            x={-260}
            y={-85}
            width={520}
            height={170}
            rx={36}
            fill={vulcanize > 0.2 ? '#291D1C' : '#181B20'}
            stroke={vulcanize > 0.2 ? PALETTE.rubberHot : PALETTE.rubberHighlight}
            strokeWidth={6}
          />
          {Array.from({length: 11}).map((_, i) => {
            const tx = -215 + i * 43;
            const toothHeight = vulcanize * 18;
            return (
              <React.Fragment key={i}>
                <rect
                  x={tx - 12}
                  y={-85 - toothHeight}
                  width={24}
                  height={toothHeight + 4}
                  rx={3}
                  fill={vulcanize > 0.2 ? '#3A2320' : '#232830'}
                />
                <rect
                  x={tx - 12}
                  y={81}
                  width={24}
                  height={toothHeight + 4}
                  rx={3}
                  fill={vulcanize > 0.2 ? '#3A2320' : '#232830'}
                />
              </React.Fragment>
            );
          })}

          <text
            x={0}
            y={8}
            textAnchor="middle"
            fill={PALETTE.white}
            fontFamily={fontFamily}
            fontWeight="800"
            fontSize="26"
          >
            {vulcanize > 0.35 ? 'VULCANIZACIÓN: CALOR Y PRESIÓN' : 'CAUCHO EN EL MOLDE'}
          </text>
        </g>

        <g transform={`translate(210, ${topMoldY})`}>
          <rect x="260" y="-260" width="140" height="260" fill="#374151" />
          <rect
            x="0"
            y="0"
            width="660"
            height="135"
            rx="14"
            fill="url(#steelGrad)"
            stroke={PALETTE.metalLight}
            strokeWidth="4"
          />
          <text
            x="330"
            y="78"
            textAnchor="middle"
            fill={PALETTE.white}
            fontFamily={fontFamily}
            fontWeight="800"
            fontSize="24"
          >
            MOLDE SUPERIOR
          </text>
        </g>

        <g transform={`translate(210, ${bottomMoldY})`}>
          <rect x="260" y="135" width="140" height="260" fill="#374151" />
          <rect
            x="0"
            y="0"
            width="660"
            height="135"
            rx="14"
            fill="url(#steelGrad)"
            stroke={PALETTE.metalLight}
            strokeWidth="4"
          />
          <text
            x="330"
            y="78"
            textAnchor="middle"
            fill={PALETTE.white}
            fontFamily={fontFamily}
            fontWeight="800"
            fontSize="24"
          >
            MOLDE INFERIOR
          </text>
        </g>
      </svg>

      <SceneHeader badge={scene.badge} title={scene.title} />
    </AbsoluteFill>
  );
};
