import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneConfig} from '../script';
import {SceneHeader} from '../components/SceneHeader';

const CHANNELS = [270, 540, 810];

export const Scene04AirEscape: React.FC<{scene: SceneConfig}> = ({scene}) => {
  const frame = useCurrentFrame();

  const rubberPush = interpolate(frame, [0, 140], [0, 110], {
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark}}>
      <svg width="1080" height="1920" viewBox="0 0 1080 1920">
        <path
          d="M 110 470 L 970 470 L 970 860 L 824 860 L 824 540 L 796 540 L 796 860 L 554 860 L 554 540 L 526 540 L 526 860 L 284 860 L 284 540 L 256 540 L 256 860 L 110 860 Z"
          fill={PALETTE.bgSteel}
          stroke={PALETTE.metalLight}
          strokeWidth={4}
        />

        <text
          x={540}
          y={435}
          textAnchor="middle"
          fill={PALETTE.yellowAccent}
          fontFamily={fontFamily}
          fontWeight="800"
          fontSize="26"
        >
          CANALES DE VENTILACIÓN DEL MOLDE
        </text>

        <rect
          x={114}
          y={1040 - rubberPush}
          width={852}
          height={420}
          fill={PALETTE.rubber}
          stroke={PALETTE.rubberHighlight}
          strokeWidth={4}
        />
        <text
          x={540}
          y={1210 - rubberPush * 0.5}
          textAnchor="middle"
          fill={PALETTE.white}
          fontFamily={fontFamily}
          fontWeight="800"
          fontSize="30"
        >
          CAUCHO PRESIONANDO HACIA ARRIBA
        </text>

        {CHANNELS.map((cx, idx) => {
          const cycle = (frame * 6 + idx * 25) % 180;
          const particleY = 920 - cycle * 2.2;
          const opacity = particleY < 510 ? 0 : 1;

          return (
            <g key={idx}>
              <rect
                x={cx - 18}
                y={540}
                width={36}
                height={320}
                fill="rgba(125, 211, 252, 0.10)"
              />
              <g transform={`translate(${cx}, ${particleY})`} opacity={opacity}>
                <circle cx={0} cy={0} r={10} fill={PALETTE.airCyan} />
                <polyline
                  points="-12,-14 0,-28 12,-14"
                  fill="none"
                  stroke={PALETTE.airCyan}
                  strokeWidth={4}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>
            </g>
          );
        })}

        <text
          x={540}
          y={905}
          textAnchor="middle"
          fill={PALETTE.airCyan}
          fontFamily={fontFamily}
          fontWeight="800"
          fontSize="26"
        >
          EL AIRE ATRAPADO ESCAPA SIN DEJAR BURBUJAS
        </text>
      </svg>

      <SceneHeader badge={scene.badge} title={scene.title} />
    </AbsoluteFill>
  );
};
