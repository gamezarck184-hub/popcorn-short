import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {GROUND, PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneConfig} from '../script';
import {SceneHeader} from '../components/SceneHeader';
import {Stickman} from '../components/Stickman';
import {Tire} from '../components/Tire';

export const Scene01Mystery: React.FC<{scene: SceneConfig}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const camScale = interpolate(frame, [0, durationInFrames], [1, 1.28], {
    extrapolateRight: 'clamp',
  });
  const camX = interpolate(frame, [0, durationInFrames], [0, -110], {
    extrapolateRight: 'clamp',
  });
  const camY = interpolate(frame, [0, durationInFrames], [0, 75], {
    extrapolateRight: 'clamp',
  });

  const calloutOpacity = interpolate(frame, [28, 45], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark, overflow: 'hidden'}}>
      <svg
        width="1080"
        height="1920"
        viewBox="0 0 1080 1920"
        style={{
          transform: `scale(${camScale}) translate(${camX}px, ${camY}px)`,
          transformOrigin: '620px 880px',
        }}
      >
        <defs>
          <radialGradient id="studioGlow" cx="55%" cy="46%" r="55%">
            <stop offset="0%" stopColor="#26313D" stopOpacity="0.65" />
            <stop offset="100%" stopColor={PALETTE.bgDark} stopOpacity="1" />
          </radialGradient>
        </defs>

        <rect width="1080" height="1920" fill="url(#studioGlow)" />
        <rect x="0" y={GROUND} width="1080" height={1920 - GROUND} fill="#0F1318" />
        <line x1="0" y1={GROUND} x2="1080" y2={GROUND} stroke="#232B35" strokeWidth="3" />

        <Tire
          cx={650}
          cy={1135}
          radius={275}
          rotation={frame * 0.25}
          showHairs={true}
          hairLength={24}
          highlightHairIndex={14}
        />

        <g opacity={calloutOpacity}>
          <circle
            cx={448}
            cy={935}
            r={38}
            fill="none"
            stroke={PALETTE.yellowAccent}
            strokeWidth={4}
            strokeDasharray="8 6"
          />
          <polyline
            points="415,910 315,825 140,825"
            fill="none"
            stroke={PALETTE.yellowAccent}
            strokeWidth={3.5}
          />
          <text
            x={140}
            y={810}
            fill={PALETTE.yellowAccent}
            fontFamily={fontFamily}
            fontWeight="800"
            fontSize="26"
          >
            FILAMENTO DE GOMA
          </text>
        </g>

        <Stickman
          x={230}
          y={GROUND}
          scale={1.15}
          expression="curious"
          pointingAngle={-42}
          lookX={0.8}
        />
      </svg>

      <SceneHeader badge={scene.badge} title={scene.title} />
    </AbsoluteFill>
  );
};
