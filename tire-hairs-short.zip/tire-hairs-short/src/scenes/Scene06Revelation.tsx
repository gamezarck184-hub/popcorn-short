import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {GROUND, PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneConfig} from '../script';
import {SceneHeader} from '../components/SceneHeader';
import {Stickman} from '../components/Stickman';
import {Tire} from '../components/Tire';

export const Scene06Revelation: React.FC<{scene: SceneConfig}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const camScale = interpolate(frame, [0, durationInFrames], [1.12, 1.0], {
    extrapolateRight: 'clamp',
  });

  const badgePop = interpolate(frame, [18, 34], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark, overflow: 'hidden'}}>
      <svg
        width="1080"
        height="1920"
        viewBox="0 0 1080 1920"
        style={{
          transform: `scale(${camScale})`,
          transformOrigin: '540px 1050px',
        }}
      >
        <defs>
          <radialGradient id="finalGlow" cx="50%" cy="48%" r="55%">
            <stop offset="0%" stopColor="#193424" stopOpacity="0.65" />
            <stop offset="100%" stopColor={PALETTE.bgDark} stopOpacity="1" />
          </radialGradient>
        </defs>

        <rect width="1080" height="1920" fill="url(#finalGlow)" />
        <rect x="0" y={GROUND} width="1080" height={1920 - GROUND} fill="#0F1318" />
        <line x1="0" y1={GROUND} x2="1080" y2={GROUND} stroke="#232B35" strokeWidth="3" />

        <Tire
          cx={660}
          cy={1135}
          radius={275}
          rotation={frame * 0.6}
          showHairs={true}
          hairLength={24}
          highlightHairIndex={13}
        />

        <Stickman
          x={230}
          y={GROUND}
          scale={1.18}
          expression="eureka"
          pointingAngle={-32}
          lookX={0.85}
        />

        <g transform="translate(230, 1110)" opacity={badgePop}>
          <line x1="-45" y1="-15" x2="-65" y2="-30" stroke={PALETTE.yellowAccent} strokeWidth="5" strokeLinecap="round" />
          <line x1="0" y1="-35" x2="0" y2="-60" stroke={PALETTE.yellowAccent} strokeWidth="5" strokeLinecap="round" />
          <line x1="45" y1="-15" x2="65" y2="-30" stroke={PALETTE.yellowAccent} strokeWidth="5" strokeLinecap="round" />
          <text
            x={0}
            y={-75}
            textAnchor="middle"
            fill={PALETTE.greenPrimary}
            fontFamily={fontFamily}
            fontWeight="900"
            fontSize="28"
          >
            ¡RESUELTO!
          </text>
        </g>
      </svg>

      <SceneHeader badge={scene.badge} title={scene.title} />
    </AbsoluteFill>
  );
};
