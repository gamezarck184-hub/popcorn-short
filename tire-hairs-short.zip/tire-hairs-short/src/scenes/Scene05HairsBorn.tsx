import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneConfig} from '../script';
import {SceneHeader} from '../components/SceneHeader';

export const Scene05HairsBorn: React.FC<{scene: SceneConfig}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const fillProgress = interpolate(frame, [0, 65], [0, 1], {
    extrapolateRight: 'clamp',
  });

  const coolProgress = interpolate(frame, [65, 125], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const openMold = interpolate(frame, [125, durationInFrames - 10], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const moldOffsetY = openMold * -260;
  const hairHeight = fillProgress * 230;

  const rubberFill = coolProgress > 0.5 ? '#1B2026' : '#5C261E';
  const rubberStroke = coolProgress > 0.5 ? PALETTE.greenPrimary : PALETTE.rubberHot;

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark}}>
      <svg width="1080" height="1920" viewBox="0 0 1080 1920">
        <g transform={`translate(0, ${moldOffsetY})`}>
          <path
            d="M 160 520 L 920 520 L 920 920 L 758 920 L 758 630 L 732 630 L 732 920 L 553 920 L 553 630 L 527 630 L 527 920 L 348 920 L 348 630 L 322 630 L 322 920 L 160 920 Z"
            fill={PALETTE.bgSteel}
            stroke={PALETTE.metalLight}
            strokeWidth={4}
          />
          <text
            x={540}
            y={490}
            textAnchor="middle"
            fill={PALETTE.metalLight}
            fontFamily={fontFamily}
            fontWeight="800"
            fontSize="24"
          >
            {openMold > 0.2 ? 'EL MOLDE SE ABRE' : 'MICROCANALES DE VENTILACIÓN'}
          </text>
        </g>

        <g>
          {[335, 540, 745].map((cx, idx) => (
            <rect
              key={idx}
              x={cx - 11}
              y={920 - hairHeight}
              width={22}
              height={hairHeight + 10}
              rx={10}
              fill={rubberFill}
              stroke={rubberStroke}
              strokeWidth={3.5}
            />
          ))}

          <rect
            x={160}
            y={920}
            width={760}
            height={380}
            rx={16}
            fill={PALETTE.rubber}
            stroke={PALETTE.rubberHighlight}
            strokeWidth={5}
          />

          <text
            x={540}
            y={1090}
            textAnchor="middle"
            fill={PALETTE.white}
            fontFamily={fontFamily}
            fontWeight="800"
            fontSize="30"
          >
            {openMold > 0.3
              ? 'FILAMENTOS SOLIDIFICADOS EN EL NEUMÁTICO'
              : coolProgress > 0.4
              ? 'ENFRIANDO Y SOLIDIFICANDO...'
              : 'CAUCHO ENTRANDO POR PRESIÓN'}
          </text>
        </g>
      </svg>

      <SceneHeader badge={scene.badge} title={scene.title} />
    </AbsoluteFill>
  );
};
