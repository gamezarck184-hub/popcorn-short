import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneConfig} from '../script';
import {SceneHeader} from '../components/SceneHeader';
import {Tire} from '../components/Tire';

const MYTHS = [
  {label: 'MÁS AGARRE', x: 240, y: 540, delay: 12},
  {label: 'VELOCIDAD', x: 540, y: 470, delay: 32},
  {label: 'RESISTENCIA', x: 840, y: 540, delay: 52},
];

export const Scene02NotDecor: React.FC<{scene: SceneConfig}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const factoryShift = interpolate(
    frame,
    [durationInFrames - 55, durationInFrames],
    [0, 1],
    {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}
  );

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark}}>
      <svg width="1080" height="1920" viewBox="0 0 1080 1920">
        <g opacity={0.18 + factoryShift * 0.72}>
          <rect x="80" y="760" width="920" height="670" fill="#141A21" stroke="#28323E" strokeWidth="3" />
          <polygon points="80,760 310,640 310,760" fill="#1A222B" />
          <polygon points="310,760 540,640 540,760" fill="#1A222B" />
          <polygon points="540,760 770,640 770,760" fill="#1A222B" />
          <polygon points="770,760 1000,640 1000,760" fill="#1A222B" />
          {[150, 360, 570, 780].map((wx, idx) => (
            <rect
              key={idx}
              x={wx}
              y={830}
              width={140}
              height={95}
              rx={6}
              fill="rgba(34, 197, 94, 0.14)"
              stroke="#334155"
              strokeWidth="2"
            />
          ))}
        </g>

        <Tire
          cx={540}
          cy={1060 + factoryShift * 80}
          radius={260 - factoryShift * 35}
          rotation={frame * 1.4}
          showHairs={true}
          hairLength={20}
        />

        {MYTHS.map((item, idx) => {
          const appear = interpolate(frame, [item.delay, item.delay + 12], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
          });
          const strike = interpolate(frame, [item.delay + 22, item.delay + 34], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
          });
          const fadeOut = 1 - factoryShift;

          return (
            <g
              key={idx}
              transform={`translate(${item.x}, ${item.y})`}
              opacity={appear * fadeOut}
            >
              <circle
                cx={0}
                cy={0}
                r={74}
                fill={PALETTE.bgPanel}
                stroke={strike > 0.5 ? '#EF4444' : PALETTE.metalLight}
                strokeWidth={4}
              />
              {idx === 0 && (
                <path
                  d="M -26 16 L 0 -22 L 26 16"
                  fill="none"
                  stroke={PALETTE.white}
                  strokeWidth={6}
                  strokeLinecap="round"
                />
              )}
              {idx === 1 && (
                <path
                  d="M -28 12 A 30 30 0 0 1 28 12 M 0 12 L 16 -12"
                  fill="none"
                  stroke={PALETTE.white}
                  strokeWidth={6}
                  strokeLinecap="round"
                />
              )}
              {idx === 2 && (
                <polygon
                  points="0,-26 24,-10 18,22 -18,22 -24,-10"
                  fill="none"
                  stroke={PALETTE.white}
                  strokeWidth={5}
                />
              )}

              {strike > 0 && (
                <g opacity={strike}>
                  <line x1={-42} y1={-42} x2={42} y2={42} stroke="#EF4444" strokeWidth={7} strokeLinecap="round" />
                  <line x1={42} y1={-42} x2={-42} y2={42} stroke="#EF4444" strokeWidth={7} strokeLinecap="round" />
                </g>
              )}

              <text
                x={0}
                y={108}
                textAnchor="middle"
                fill={PALETTE.white}
                fontFamily={fontFamily}
                fontWeight="800"
                fontSize="22"
              >
                {item.label}
              </text>
            </g>
          );
        })}
      </svg>

      <SceneHeader badge={scene.badge} title={scene.title} />
    </AbsoluteFill>
  );
};
