import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {AUDIO_PATH, OVERLAP, PALETTE} from './config';
import {SCENES, sec} from './script';
import {Subtitle} from './components/Subtitle';
import {Scene01Mystery} from './scenes/Scene01Mystery';
import {Scene02NotDecor} from './scenes/Scene02NotDecor';
import {Scene03Manufacturing} from './scenes/Scene03Manufacturing';
import {Scene04AirEscape} from './scenes/Scene04AirEscape';
import {Scene05HairsBorn} from './scenes/Scene05HairsBorn';
import {Scene06Revelation} from './scenes/Scene06Revelation';

const SCENE_COMPONENTS = [
  Scene01Mystery,
  Scene02NotDecor,
  Scene03Manufacturing,
  Scene04AirEscape,
  Scene05HairsBorn,
  Scene06Revelation,
];

export const TireHairsShort: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDark}}>
      <Audio src={staticFile(AUDIO_PATH)} />

      {SCENES.map((scene, index) => {
        const Component = SCENE_COMPONENTS[index];
        const fromFrame = Math.max(0, sec(scene.start) - (index > 0 ? OVERLAP : 0));
        const endFrame = sec(scene.end);
        const durationInFrames = Math.max(1, endFrame - fromFrame);

        return (
          <Sequence
            key={scene.id}
            from={fromFrame}
            durationInFrames={durationInFrames}
            name={scene.id}
          >
            <Component scene={scene} />
          </Sequence>
        );
      })}

      {/* Viñeta cinematográfica sutil */}
      <AbsoluteFill
        style={{
          pointerEvents: 'none',
          background:
            'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 58%, rgba(0,0,0,0.52) 100%)',
        }}
      />

      {/* Subtítulos inferiores sincronizados */}
      <Subtitle />
    </AbsoluteFill>
  );
};
