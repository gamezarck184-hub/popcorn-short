import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SCENES, sec} from '../script';

export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const allCues = SCENES.flatMap((s) => s.cues);
  const active = allCues.find(
    (c) => frame >= sec(c.from) && frame < sec(c.to)
  );

  if (!active) return null;

  const startF = sec(active.from);
  const endF = sec(active.to);
  const opacityIn = interpolate(frame, [startF, startF + 4], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const opacityOut = interpolate(frame, [endF - 3, endF], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const translateY = interpolate(frame, [startF, startF + 5], [14, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const highlightSet = new Set(
    active.highlights.map((w) => w.toLowerCase())
  );

  const lines = active.text.split('\n');

  return (
    <div
      style={{
        position: 'absolute',
        left: 60,
        right: 60,
        bottom: 240,
        display: 'flex',
        justifyContent: 'center',
        pointerEvents: 'none',
        opacity: opacityIn * opacityOut,
        transform: `translateY(${translateY}px)`,
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(10, 13, 16, 0.82)',
          border: '1px solid rgba(255, 255, 255, 0.12)',
          borderRadius: 22,
          padding: '16px 32px',
          boxShadow: '0 14px 34px rgba(0, 0, 0, 0.6)',
          textAlign: 'center',
          fontFamily,
          fontWeight: 800,
          fontSize: 48,
          lineHeight: 1.22,
          color: PALETTE.white,
          maxWidth: 920,
        }}
      >
        {lines.map((line, lineIdx) => (
          <div key={lineIdx}>
            {line.split(' ').map((word, wordIdx) => {
              const isHighlighted = highlightSet.has(word.toLowerCase());
              return (
                <span
                  key={wordIdx}
                  style={{
                    color: isHighlighted ? PALETTE.greenPrimary : PALETTE.white,
                  }}
                >
                  {word}
                  {wordIdx < line.split(' ').length - 1 ? ' ' : ''}
                </span>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};
