import React from 'react';
import {PALETTE} from '../config';

export interface TireProps {
  cx: number;
  cy: number;
  radius: number;
  rotation?: number;
  showHairs?: boolean;
  hairLength?: number;
  highlightHairIndex?: number;
  hasTread?: boolean;
}

export const Tire: React.FC<TireProps> = ({
  cx,
  cy,
  radius,
  rotation = 0,
  showHairs = true,
  hairLength = 18,
  highlightHairIndex = -1,
  hasTread = true,
}) => {
  const numTreads = 24;
  const numHairs = 18;
  const rimRadius = radius * 0.56;

  return (
    <g transform={`translate(${cx}, ${cy})`}>
      <ellipse
        cx={0}
        cy={radius + 16}
        rx={radius * 0.82}
        ry={22}
        fill="rgba(0,0,0,0.55)"
      />

      <g transform={`rotate(${rotation})`}>
        {showHairs &&
          Array.from({length: numHairs}).map((_, i) => {
            const angle = (i * 360) / numHairs;
            const rad = (angle * Math.PI) / 180;
            const x1 = Math.cos(rad) * (radius - 2);
            const y1 = Math.sin(rad) * (radius - 2);
            const x2 = Math.cos(rad) * (radius + hairLength);
            const y2 = Math.sin(rad) * (radius + hairLength);
            const isHighlighted = i === highlightHairIndex;

            return (
              <g key={`hair-${i}`}>
                <line
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke={isHighlighted ? PALETTE.yellowAccent : '#23282E'}
                  strokeWidth={isHighlighted ? 5 : 3.2}
                  strokeLinecap="round"
                />
                {isHighlighted && (
                  <circle
                    cx={x2}
                    cy={y2}
                    r={14}
                    fill="none"
                    stroke={PALETTE.yellowAccent}
                    strokeWidth={3}
                  />
                )}
              </g>
            );
          })}

        {hasTread &&
          Array.from({length: numTreads}).map((_, i) => {
            const angle = (i * 360) / numTreads;
            return (
              <rect
                key={`tread-${i}`}
                x={-11}
                y={-radius - 6}
                width={22}
                height={14}
                rx={4}
                fill={PALETTE.rubberHighlight}
                transform={`rotate(${angle})`}
              />
            );
          })}

        <circle
          cx={0}
          cy={0}
          r={radius}
          fill={PALETTE.rubber}
          stroke={PALETTE.rubberHighlight}
          strokeWidth={6}
        />

        <circle
          cx={0}
          cy={0}
          r={radius * 0.78}
          fill="none"
          stroke="#22272D"
          strokeWidth={14}
        />

        <circle
          cx={0}
          cy={0}
          r={rimRadius}
          fill={PALETTE.bgSteel}
          stroke={PALETTE.metalLight}
          strokeWidth={8}
        />

        {Array.from({length: 5}).map((_, i) => {
          const angle = (i * 360) / 5;
          return (
            <rect
              key={`spoke-${i}`}
              x={-10}
              y={-rimRadius + 6}
              width={20}
              height={rimRadius * 2 - 12}
              rx={6}
              fill={PALETTE.metalMid}
              transform={`rotate(${angle})`}
            />
          );
        })}

        <circle
          cx={0}
          cy={0}
          r={rimRadius * 0.28}
          fill={PALETTE.metalDark}
          stroke={PALETTE.metalLight}
          strokeWidth={4}
        />
      </g>
    </g>
  );
};
