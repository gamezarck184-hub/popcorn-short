import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';

export const SceneHeader: React.FC<{badge: string; title: string}> = ({
  badge,
  title,
}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 12], [0, 1], {
    extrapolateRight: 'clamp',
  });
  const y = interpolate(frame, [0, 14], [-22, 0], {
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        position: 'absolute',
        top: 130,
        left: 70,
        right: 70,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 14,
        opacity,
        transform: `translateY(${y}px)`,
        pointerEvents: 'none',
      }}
    >
      <div
        style={{
          fontFamily,
          fontWeight: 700,
          fontSize: 22,
          letterSpacing: 3,
          color: PALETTE.yellowAccent,
          backgroundColor: 'rgba(250, 204, 21, 0.12)',
          border: '1px solid rgba(250, 204, 21, 0.35)',
          padding: '6px 18px',
          borderRadius: 999,
        }}
      >
        {badge}
      </div>
      <div
        style={{
          fontFamily,
          fontWeight: 900,
          fontSize: 46,
          color: PALETTE.white,
          textAlign: 'center',
          letterSpacing: 0.5,
          textShadow: '0 6px 24px rgba(0,0,0,0.75)',
        }}
      >
        {title}
      </div>
    </div>
  );
};
