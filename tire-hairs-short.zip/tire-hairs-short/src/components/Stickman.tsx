import React from 'react';
import {useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';

export type StickmanExpression = 'curious' | 'thinking' | 'surprised' | 'eureka' | 'pointing';

export interface StickmanProps {
  x: number;
  y: number;
  scale?: number;
  flipX?: boolean;
  expression?: StickmanExpression;
  pointingAngle?: number;
  lookX?: number;
}

export const Stickman: React.FC<StickmanProps> = ({
  x,
  y,
  scale = 1,
  flipX = false,
  expression = 'curious',
  pointingAngle = -35,
  lookX = 0.5,
}) => {
  const frame = useCurrentFrame();

  const breath = Math.sin(frame * 0.1) * 3;
  const blinkCycle = frame % 110;
  const isBlinking = blinkCycle > 105;
  const eyeScaleY = isBlinking ? 0.12 : 1;

  const pupilOffset = lookX * 5;

  const rad = (pointingAngle * Math.PI) / 180;
  const shoulderR = {x: 34, y: -158 + breath};
  const handR = {
    x: shoulderR.x + Math.cos(rad) * 105,
    y: shoulderR.y + Math.sin(rad) * 105,
  };
  const elbowR = {
    x: (shoulderR.x + handR.x) / 2 + 8,
    y: (shoulderR.y + handR.y) / 2 + 12,
  };

  const shoulderL = {x: -34, y: -158 + breath};
  const handL =
    expression === 'thinking'
      ? {x: -14, y: -195 + breath}
      : {x: -54, y: -72 + breath * 0.5};
  const elbowL =
    expression === 'thinking'
      ? {x: -56, y: -140 + breath}
      : {x: -52, y: -115 + breath};

  const renderMouth = () => {
    switch (expression) {
      case 'surprised':
        return <ellipse cx={0} cy={-212 + breath} rx={7} ry={9} fill={PALETTE.ink} />;
      case 'eureka':
      case 'pointing':
        return (
          <path
            d={`M -14 ${-216 + breath} Q 0 ${-198 + breath} 14 ${-216 + breath}`}
            stroke={PALETTE.ink}
            strokeWidth={4}
            fill="none"
            strokeLinecap="round"
          />
        );
      case 'thinking':
        return (
          <line
            x1={-11}
            y1={-211 + breath}
            x2={11}
            y2={-214 + breath}
            stroke={PALETTE.ink}
            strokeWidth={4}
            strokeLinecap="round"
          />
        );
      case 'curious':
      default:
        return (
          <path
            d={`M -10 ${-213 + breath} Q 0 ${-207 + breath} 10 ${-213 + breath}`}
            stroke={PALETTE.ink}
            strokeWidth={4}
            fill="none"
            strokeLinecap="round"
          />
        );
    }
  };

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${flipX ? -scale : scale}, ${scale})`}
    >
      <ellipse cx={0} cy={0} rx={58} ry={12} fill="rgba(0,0,0,0.45)" />

      <polyline
        points="-20,-82 -24,-40 -26,0"
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={13}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polyline
        points="20,-82 24,-40 26,0"
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={13}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      <polyline
        points={`${shoulderL.x},${shoulderL.y} ${elbowL.x},${elbowL.y} ${handL.x},${handL.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={11}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      <path
        d={`M -34 ${-168 + breath}
            Q 0 ${-176 + breath} 34 ${-168 + breath}
            L 40 ${-80 + breath * 0.4}
            Q 0 ${-74 + breath * 0.4} -40 ${-80 + breath * 0.4} Z`}
        fill={PALETTE.greenSweater}
        stroke={PALETTE.ink}
        strokeWidth={4}
      />
      <path
        d={`M -16 ${-169 + breath} Q 0 ${-154 + breath} 16 ${-169 + breath}`}
        fill="none"
        stroke={PALETTE.greenSweaterDark}
        strokeWidth={5}
        strokeLinecap="round"
      />
      <line
        x1={0}
        y1={-158 + breath}
        x2={0}
        y2={-80 + breath * 0.4}
        stroke={PALETTE.greenSweaterDark}
        strokeWidth={3}
      />

      <polyline
        points={`${shoulderR.x},${shoulderR.y} ${elbowR.x},${elbowR.y} ${handR.x},${handR.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={11}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line
        x1={shoulderR.x}
        y1={shoulderR.y}
        x2={(shoulderR.x + elbowR.x) / 2}
        y2={(shoulderR.y + elbowR.y) / 2}
        stroke={PALETTE.greenSweater}
        strokeWidth={16}
        strokeLinecap="round"
      />

      <circle
        cx={0}
        cy={-224 + breath}
        r={44}
        fill={PALETTE.white}
        stroke={PALETTE.ink}
        strokeWidth={4.5}
      />

      <line
        x1={-21 + pupilOffset * 0.5}
        y1={expression === 'surprised' || expression === 'eureka' ? -246 + breath : -241 + breath}
        x2={-7 + pupilOffset * 0.5}
        y2={-242 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.5}
        strokeLinecap="round"
      />
      <line
        x1={7 + pupilOffset * 0.5}
        y1={-242 + breath}
        x2={21 + pupilOffset * 0.5}
        y2={expression === 'surprised' || expression === 'eureka' ? -246 + breath : -241 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.5}
        strokeLinecap="round"
      />

      <ellipse
        cx={-13 + pupilOffset}
        cy={-230 + breath}
        rx={4.5}
        ry={6.5 * eyeScaleY}
        fill={PALETTE.ink}
      />
      <ellipse
        cx={13 + pupilOffset}
        cy={-230 + breath}
        rx={4.5}
        ry={6.5 * eyeScaleY}
        fill={PALETTE.ink}
      />

      {renderMouth()}
    </g>
  );
};
