import React from 'react';
import {Composition} from 'remotion';
import {TireHairsShort} from './TireHairsShort';
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from './config';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="TireHairsShort"
      component={TireHairsShort}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};
