import {FPS} from './config';

export const sec = (s: number) => Math.round(s * FPS);

export type SubtitleCue = {
  from: number;
  to: number;
  text: string;
  highlights: string[];
};

export type SceneConfig = {
  id: string;
  start: number;
  end: number;
  badge: string;
  title: string;
  cues: SubtitleCue[];
};

export const SCENES: SceneConfig[] = [
  {
    id: 'scene-01-mystery',
    start: 0.0,
    end: 4.1,
    badge: '01 · EL MISTERIO',
    title: '¿POR QUÉ TIENEN PELOS?',
    cues: [
      {
        from: 0.1,
        to: 2.1,
        text: '¿Alguna vez te fijaste en esos\npequeños pelitos',
        highlights: ['pequeños', 'pelitos'],
      },
      {
        from: 2.1,
        to: 4.1,
        text: 'que tienen los\nneumáticos nuevos?',
        highlights: ['neumáticos', 'nuevos?'],
      },
    ],
  },
  {
    id: 'scene-02-not-decor',
    start: 4.1,
    end: 11.4,
    badge: '02 · MITO DESCARTADO',
    title: 'NO MEJORAN EL AGARRE',
    cues: [
      {
        from: 4.1,
        to: 7.5,
        text: 'Aunque parecen estar ahí\npor alguna razón especial,',
        highlights: ['razón', 'especial,'],
      },
      {
        from: 7.5,
        to: 11.4,
        text: 'en realidad son restos\ndel proceso de fabricación.',
        highlights: ['restos', 'fabricación.'],
      },
    ],
  },
  {
    id: 'scene-03-manufacturing',
    start: 11.4,
    end: 18.8,
    badge: '03 · VULCANIZACIÓN',
    title: 'EL PROCESO DE FABRICACIÓN',
    cues: [
      {
        from: 11.4,
        to: 14.3,
        text: 'Cuando se fabrica\nun neumático,',
        highlights: ['fabrica', 'neumático,'],
      },
      {
        from: 14.3,
        to: 18.8,
        text: 'el caucho caliente se introduce\ndentro de un molde para darle su forma.',
        highlights: ['caucho', 'molde', 'forma.'],
      },
    ],
  },
  {
    id: 'scene-04-air-escape',
    start: 18.8,
    end: 27.6,
    badge: '04 · VENTILACIÓN',
    title: 'PEQUEÑOS CANALES DE VENTILACIÓN',
    cues: [
      {
        from: 18.8,
        to: 22.1,
        text: 'Pero durante ese proceso,\nel aire atrapado necesita escapar',
        highlights: ['aire', 'atrapado', 'escapar'],
      },
      {
        from: 22.1,
        to: 24.4,
        text: 'para evitar que queden\ndefectos en la goma.',
        highlights: ['evitar', 'defectos'],
      },
      {
        from: 24.4,
        to: 27.6,
        text: 'Por eso, los moldes tienen\npequeños canales de ventilación.',
        highlights: ['canales', 'ventilación.'],
      },
    ],
  },
  {
    id: 'scene-05-hairs-born',
    start: 27.6,
    end: 34.4,
    badge: '05 · SOLIDIFICACIÓN',
    title: 'ASÍ SE FORMAN',
    cues: [
      {
        from: 27.6,
        to: 30.8,
        text: 'Parte del caucho entra\nen esos diminutos canales',
        highlights: ['caucho', 'diminutos', 'canales'],
      },
      {
        from: 30.8,
        to: 34.4,
        text: 'y, al enfriarse, forma esos pequeños\nfilamentos que parecen pelitos.',
        highlights: ['enfriarse,', 'filamentos', 'pelitos.'],
      },
    ],
  },
  {
    id: 'scene-06-revelation',
    start: 34.4,
    end: 41.5,
    badge: '06 · CONCLUSIÓN',
    title: 'UNA HUELLA DE SU FABRICACIÓN',
    cues: [
      {
        from: 34.4,
        to: 37.3,
        text: 'Así que la próxima vez que veas\nun neumático nuevo, ya sabes de dónde vienen.',
        highlights: ['neumático', 'nuevo,'],
      },
      {
        from: 37.3,
        to: 40.3,
        text: '¡Son una pequeña huella\ndel proceso de fabricación!',
        highlights: ['pequeña', 'huella', 'fabricación!'],
      },
    ],
  },
];
