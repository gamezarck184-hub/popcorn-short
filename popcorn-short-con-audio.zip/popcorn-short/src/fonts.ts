import {continueRender, delayRender} from 'remotion';
// Bundled with npm (no internet needed at render time).
import '@fontsource/montserrat/latin-700.css';
import '@fontsource/montserrat/latin-800.css';
import '@fontsource/montserrat/latin-900.css';

export const fontFamily = `'Montserrat', 'Segoe UI', Arial, sans-serif`;

if (typeof document !== 'undefined') {
  const handle = delayRender('Loading Montserrat');
  Promise.all(['700', '800', '900'].map((w) => document.fonts.load(`${w} 40px Montserrat`)))
    .then(() => continueRender(handle))
    .catch(() => continueRender(handle));
}
