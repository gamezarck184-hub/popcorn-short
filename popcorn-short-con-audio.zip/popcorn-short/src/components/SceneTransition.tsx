import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {OVERLAP} from '../config';
import {E, prog} from '../lib/anim';

/** The incoming scene is revealed over the previous one (crossfade / iris / wipe). */
export const SceneTransition: React.FC<{index: number; children: React.ReactNode}> = ({index, children}) => {
  const f = useCurrentFrame();
  if (index === 0) return <AbsoluteFill style={{overflow: 'hidden'}}>{children}</AbsoluteFill>;
  const t = prog(f, 0, OVERLAP, E.inOut);
  const kind = index % 3;
  let style: React.CSSProperties = {overflow: 'hidden'};
  if (kind === 0) style = {...style, opacity: t, transform: `scale(${1.06 - 0.06 * t})`};
  if (kind === 1) style = {...style, clipPath: `circle(${t * 150}% at 50% 62%)`};
  if (kind === 2) style = {...style, clipPath: `inset(0 ${(1 - t) * 100}% 0 0)`};
  return <AbsoluteFill style={style}>{children}</AbsoluteFill>;
};
