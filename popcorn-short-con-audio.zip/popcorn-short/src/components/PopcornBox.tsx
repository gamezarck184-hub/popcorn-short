import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS} from '../config';
import {seeded} from '../lib/anim';
import {fontFamily} from '../fonts';

const INK = COLORS.ink;
export type BoxSize = 'S' | 'M' | 'L';

export const BOX = {
  S: {w: 150, h: 170, mound: 34, n: 10, seed: 11},
  M: {w: 200, h: 230, mound: 48, n: 18, seed: 23},
  L: {w: 260, h: 310, mound: 74, n: 30, seed: 37},
};

export const Kernel: React.FC<{cx: number; cy: number; r: number; rot: number}> = ({cx, cy, r, rot}) => (
  <g transform={`translate(${cx} ${cy}) rotate(${rot})`}>
    <g fill="#FFF6DC" stroke="#E4B547" strokeWidth={2.5}>
      <circle cx={-r * 0.45} cy={r * 0.05} r={r * 0.62} />
      <circle cx={r * 0.45} cy={-r * 0.05} r={r * 0.6} />
      <circle cx={0} cy={-r * 0.5} r={r * 0.65} />
    </g>
    <circle cx={r * 0.1} cy={r * 0.1} r={r * 0.28} fill={COLORS.butter} opacity={0.85} />
  </g>
);

type Props = {
  size: BoxSize;
  /** Center x. */
  x: number;
  /** Y of the BASE of the box. */
  y: number;
  scale?: number;
  rot?: number;
  opacity?: number;
  /** 0…1 how much the popcorn mound is heaped. */
  heap?: number;
  glow?: boolean;
};

export const PopcornBox: React.FC<Props> = ({size, x, y, scale = 1, rot = 0, opacity = 1, heap = 1, glow = false}) => {
  const frame = useCurrentFrame();
  const {w, h, mound, n, seed} = BOX[size];
  const bw = w * 0.76;
  const rnd = seeded(seed);
  const kernels = Array.from({length: n}, (_, i) => {
    const kx = (rnd() - 0.5) * w * 0.9;
    const maxUp = mound * heap * (1 - Math.pow((2 * kx) / w, 2) * 0.85);
    const ky = -h + 10 - rnd() * maxUp;
    return {
      cx: kx + Math.sin(frame / 9 + i) * 1.2,
      cy: ky,
      r: 15 + rnd() * 6,
      rot: rnd() * 360,
    };
  }).sort((a, b) => a.cy - b.cy);
  const front = Array.from({length: 5}, () => ({
    cx: (rnd() - 0.5) * w * 0.8,
    cy: -h - 2 + rnd() * 6,
    r: 14 + rnd() * 5,
    rot: rnd() * 360,
  }));
  const stripes = 6;
  const stripePolys = Array.from({length: stripes}, (_, i) => {
    if (i % 2 !== 0) return null;
    const tl = -w / 2 + (i * w) / stripes;
    const tr = -w / 2 + ((i + 1) * w) / stripes;
    const bl = -bw / 2 + (i * bw) / stripes;
    const br = -bw / 2 + ((i + 1) * bw) / stripes;
    return (
      <polygon key={i} points={`${tl},${-h} ${tr},${-h} ${br},0 ${bl},0`} fill={COLORS.red} />
    );
  });
  const outline = `${-w / 2},${-h} ${w / 2},${-h} ${bw / 2},0 ${-bw / 2},0`;

  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${scale})`} opacity={opacity}>
      <defs>
        <linearGradient id="box-shade" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#000" stopOpacity="0.22" />
          <stop offset="0.5" stopColor="#000" stopOpacity="0" />
          <stop offset="1" stopColor="#000" stopOpacity="0.16" />
        </linearGradient>
        <radialGradient id="box-glow">
          <stop offset="0" stopColor="#FFE08A" stopOpacity="0.85" />
          <stop offset="1" stopColor="#FFE08A" stopOpacity="0" />
        </radialGradient>
      </defs>
      {glow ? <circle cx={0} cy={-h * 0.55} r={w * 1.05} fill="url(#box-glow)" /> : null}
      {kernels.map((k, i) => (
        <Kernel key={i} {...k} />
      ))}
      <polygon points={outline} fill={COLORS.cream} />
      {stripePolys}
      <polygon points={outline} fill="url(#box-shade)" />
      <polygon points={outline} fill="none" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <rect x={-w / 2 - 6} y={-h - 10} width={w + 12} height={22} rx={9} fill={COLORS.redDark} stroke={INK} strokeWidth={5} />
      {front.map((k, i) => (
        <Kernel key={`f${i}`} {...k} />
      ))}
      <circle cx={0} cy={-h * 0.5} r={w * 0.2} fill="#fff" stroke={INK} strokeWidth={5} />
      <text
        x={0}
        y={-h * 0.5 + 1}
        textAnchor="middle"
        dominantBaseline="central"
        fontFamily={fontFamily}
        fontWeight={900}
        fontSize={w * 0.26}
        fill={COLORS.red}
      >
        {size}
      </text>
    </g>
  );
};
