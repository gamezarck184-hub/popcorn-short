import React from 'react';
import {COLORS, COUNTER_TOP, GROUND, HEIGHT, WIDTH} from '../config';
import {fontFamily} from '../fonts';
import {Dust} from './Props';

const INK = COLORS.ink;

const Floor: React.FC = () => (
  <g>
    <defs>
      <linearGradient id="bg-floor" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#4A3472" />
        <stop offset="1" stopColor="#1E1236" />
      </linearGradient>
    </defs>
    <rect x={0} y={GROUND - 20} width={WIDTH} height={HEIGHT - GROUND + 20} fill="url(#bg-floor)" />
    <rect x={0} y={GROUND - 24} width={WIDTH} height={10} fill="#1A0F2E" />
    {Array.from({length: 15}, (_, i) => {
      const k = i - 7;
      return <line key={i} x1={540 + k * 60} y1={GROUND - 10} x2={540 + k * 300} y2={HEIGHT} stroke="#fff" strokeOpacity={0.07} strokeWidth={4} />;
    })}
    {[0, 1, 2, 3].map((i) => (
      <rect key={i} x={0} y={GROUND + 20 + i * i * 22 + i * 14} width={WIDTH} height={6} fill="#fff" opacity={0.05} />
    ))}
  </g>
);

/** Lobby / snack-bar wall with warm cinematic lighting. */
export const CinemaBg: React.FC<{variant: 'lobby' | 'snack'; frame: number}> = ({variant, frame}) => {
  const bulbs = 15;
  return (
    <g>
      <defs>
        <linearGradient id="bg-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#24174A" />
          <stop offset="0.5" stopColor="#6A2C70" />
          <stop offset="1" stopColor="#B84A6E" />
        </linearGradient>
        <radialGradient id="bg-sconce">
          <stop offset="0" stopColor="#FFD98A" stopOpacity="0.85" />
          <stop offset="1" stopColor="#FFD98A" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="bg-cone" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FFE9B0" stopOpacity="0.5" />
          <stop offset="1" stopColor="#FFE9B0" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="bg-poster1" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FF9A5A" />
          <stop offset="1" stopColor="#7A2CC4" />
        </linearGradient>
        <linearGradient id="bg-poster2" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4FD1C5" />
          <stop offset="1" stopColor="#1B3B7A" />
        </linearGradient>
      </defs>
      <rect width={WIDTH} height={HEIGHT} fill="url(#bg-wall)" />
      {/* wall panels */}
      {Array.from({length: 7}, (_, i) => (
        <rect key={i} x={i * 160 - 10} y={150} width={4} height={GROUND - 170} fill="#000" opacity={0.12} />
      ))}

      {variant === 'lobby' ? (
        <g>
          <rect x={0} y={50} width={WIDTH} height={86} fill="#2A0F2B" />
          {Array.from({length: bulbs}, (_, i) => {
            const on = (Math.floor(frame / 5) + i) % 3 === 0;
            return <circle key={i} cx={36 + i * 72} cy={93} r={13} fill={on ? '#FFE27A' : '#8A6B2F'} />;
          })}
          {[{x: 60, g: 'bg-poster1'}, {x: 330, g: 'bg-poster2'}].map((p, i) => (
            <g key={i}>
              <polygon points={`${p.x - 10},120 ${p.x + 240},120 ${p.x + 340},560 ${p.x - 110},560`} fill="url(#bg-cone)" opacity={0.18} />
              <rect x={p.x} y={520} width={220} height={330} rx={10} fill="#1A0F2E" stroke="#E9D9A6" strokeWidth={8} />
              <rect x={p.x + 12} y={532} width={196} height={306} rx={4} fill={`url(#${p.g})`} />
              {i === 0 ? (
                <g>
                  <circle cx={p.x + 110} cy={640} r={46} fill="#FFE27A" />
                  <polygon points={`${p.x + 12},838 ${p.x + 90},720 ${p.x + 150},800 ${p.x + 208},700 ${p.x + 208},838`} fill="#3B1458" />
                </g>
              ) : (
                <g>
                  <polygon points={`${p.x + 12},838 ${p.x + 110},700 ${p.x + 208},838`} fill="#12284F" />
                  <circle cx={p.x + 160} cy={606} r={26} fill="#E7FFF8" />
                </g>
              )}
            </g>
          ))}
        </g>
      ) : (
        <g>
          {[310, 540, 770].map((x, i) => (
            <polygon key={i} points={`${x - 40},140 ${x + 40},140 ${x + 170},${COUNTER_TOP}  ${x - 170},${COUNTER_TOP}`} fill="url(#bg-cone)" opacity={0.3} />
          ))}
        </g>
      )}

      {/* sconces */}
      {[40, 1040].map((x) => (
        <g key={x}>
          <circle cx={x} cy={760} r={190} fill="url(#bg-sconce)" opacity={0.7 + 0.1 * Math.sin(frame / 11 + x)} />
          <rect x={x - 12} y={730} width={24} height={60} rx={10} fill="#FFE9B0" />
        </g>
      ))}
      <Floor />
      <Dust frame={frame} n={22} seed={variant === 'lobby' ? 3 : 8} />
    </g>
  );
};

export const Counter: React.FC<{x0?: number; frame?: number}> = ({x0 = 0, frame = 0}) => {
  const top = COUNTER_TOP;
  const bottom = GROUND + 6;
  return (
    <g>
      <defs>
        <linearGradient id="ct-front" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2C4584" />
          <stop offset="1" stopColor="#16244D" />
        </linearGradient>
      </defs>
      <rect x={x0} y={top + 24} width={WIDTH - x0 + 10} height={bottom - top - 24} fill="url(#ct-front)" stroke={INK} strokeWidth={5} />
      {Array.from({length: 9}, (_, i) => (
        <rect key={i} x={x0 + 40 + i * 120} y={top + 70} width={70} height={bottom - top - 100} rx={8} fill="#fff" opacity={0.06} />
      ))}
      <rect x={x0} y={top + 34} width={WIDTH - x0 + 10} height={8} fill="#FFD36B" opacity={0.85 + 0.1 * Math.sin(frame / 8)} />
      <rect x={x0 - 12} y={top} width={WIDTH - x0 + 22} height={28} rx={9} fill="#F5E8CC" stroke={INK} strokeWidth={5} />
      <rect x={x0} y={top + 4} width={WIDTH - x0} height={6} rx={3} fill="#fff" opacity={0.6} />
    </g>
  );
};

/** Abstract "mind" space used for the psychology scene. */
export const MindBg: React.FC<{frame: number}> = ({frame}) => (
  <g>
    <defs>
      <linearGradient id="bg-mind" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#0B1033" />
        <stop offset="0.6" stopColor="#1E2468" />
        <stop offset="1" stopColor="#3A2A7A" />
      </linearGradient>
    </defs>
    <rect width={WIDTH} height={HEIGHT} fill="url(#bg-mind)" />
    {[0, 1, 2, 3, 4].map((i) => {
      const t = ((frame / 70 + i / 5) % 1);
      return <circle key={i} cx={340} cy={1010} r={80 + t * 900} fill="none" stroke="#7FA8FF" strokeWidth={4} opacity={0.35 * (1 - t)} />;
    })}
    {Array.from({length: 14}, (_, i) => (
      <line key={i} x1={i * 90 - 40} y1={0} x2={i * 90 - 40} y2={HEIGHT} stroke="#7FA8FF" strokeOpacity={0.06} strokeWidth={3} />
    ))}
    {Array.from({length: 24}, (_, i) => (
      <line key={i} x1={0} y1={i * 90} x2={WIDTH} y2={i * 90} stroke="#7FA8FF" strokeOpacity={0.06} strokeWidth={3} />
    ))}
    <rect x={0} y={GROUND - 20} width={WIDTH} height={HEIGHT - GROUND + 20} fill="#14184A" />
    <rect x={0} y={GROUND - 24} width={WIDTH} height={8} fill="#7FA8FF" opacity={0.5} />
    <Dust frame={frame} n={30} seed={21} color="#BBD0FF" opacity={0.4} />
  </g>
);

/** Dark theater with screen glow + projector beam. */
export const TheaterBg: React.FC<{frame: number}> = ({frame}) => (
  <g>
    <defs>
      <linearGradient id="bg-theater" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#08060F" />
        <stop offset="1" stopColor="#2A1240" />
      </linearGradient>
      <linearGradient id="bg-beam" x1="0" y1="1" x2="0" y2="0">
        <stop offset="0" stopColor="#FFF3C9" stopOpacity="0.05" />
        <stop offset="1" stopColor="#FFF3C9" stopOpacity="0.28" />
      </linearGradient>
      <radialGradient id="bg-screenglow">
        <stop offset="0" stopColor="#9CC8FF" stopOpacity="0.55" />
        <stop offset="1" stopColor="#9CC8FF" stopOpacity="0" />
      </radialGradient>
    </defs>
    <rect width={WIDTH} height={HEIGHT} fill="url(#bg-theater)" />
    <circle cx={540} cy={690} r={640} fill="url(#bg-screenglow)" opacity={0.7 + 0.05 * Math.sin(frame / 5)} />
    <polygon points={`500,1500 580,1500 960,470 120,470`} fill="url(#bg-beam)" opacity={0.55 + 0.08 * Math.sin(frame / 3)} />
    <rect x={120} y={470} width={840} height={480} rx={16} fill="#EAF3FF" stroke="#1A1033" strokeWidth={10} />
    {[0, 1].map((row) => (
      <g key={row}>
        {Array.from({length: row === 0 ? 8 : 7}, (_, i) => (
          <rect key={i} x={(row === 0 ? 20 : 70) + i * 140} y={1040 + row * 110} width={96} height={130} rx={36} fill={row === 0 ? '#3A1030' : '#4B1638'} />
        ))}
      </g>
    ))}
    <rect x={0} y={GROUND - 4} width={WIDTH} height={HEIGHT - GROUND + 4} fill="#1A0D2E" />
    <Dust frame={frame} n={36} seed={13} color="#FFF3C9" opacity={0.45} speed={0.5} />
  </g>
);
