import React from 'react';
import {COLORS} from '../config';
import {fontFamily} from '../fonts';
import {clamp} from '../lib/anim';

const INK = COLORS.ink;

export const Sparkle: React.FC<{x: number; y: number; s?: number; rot?: number; color?: string; opacity?: number}> = ({
  x, y, s = 1, rot = 0, color = '#FFE27A', opacity = 1,
}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`} opacity={opacity}>
    <path d="M0 -30 Q4 -4 30 0 Q4 4 0 30 Q-4 4 -30 0 Q-4 -4 0 -30 Z" fill={color} />
  </g>
);

export const Coin: React.FC<{x: number; y: number; r?: number; spin?: number; opacity?: number}> = ({
  x, y, r = 26, spin = 0, opacity = 1,
}) => {
  const sx = Math.max(0.18, Math.abs(Math.cos(spin)));
  return (
    <g transform={`translate(${x} ${y}) scale(${sx} 1)`} opacity={opacity}>
      <circle r={r} fill="#FFC83D" stroke="#B8821A" strokeWidth={4} />
      <circle r={r * 0.7} fill="none" stroke="#B8821A" strokeWidth={3} opacity={0.7} />
      <text textAnchor="middle" dominantBaseline="central" y={1} fontSize={r} fontWeight={900} fill="#9A6A0E" fontFamily={fontFamily}>
        $
      </text>
    </g>
  );
};

export const Starburst: React.FC<{
  x: number; y: number; r?: number; points?: number; rot?: number; fill?: string; text?: string; fontSize?: number; scale?: number;
}> = ({x, y, r = 120, points = 14, rot = 0, fill = COLORS.coral, text = '', fontSize = 56, scale = 1}) => {
  const pts = Array.from({length: points * 2}, (_, i) => {
    const a = (i / (points * 2)) * Math.PI * 2;
    const rr = i % 2 ? r * 0.82 : r;
    return `${Math.cos(a) * rr},${Math.sin(a) * rr}`;
  }).join(' ');
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      <g transform={`rotate(${rot})`}>
        <polygon points={pts} fill={fill} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
      </g>
      <text textAnchor="middle" dominantBaseline="central" fontFamily={fontFamily} fontWeight={900} fontSize={fontSize} fill="#fff" stroke={INK} strokeWidth={8} paintOrder="stroke" transform="rotate(-8)">
        {text}
      </text>
    </g>
  );
};

export const PriceTag: React.FC<{x: number; y: number; text: string; t?: number; tilt?: number; color?: string; fs?: number}> = ({
  x, y, text, t = 1, tilt = -5, color = COLORS.butter, fs = 62,
}) => (
  <g transform={`translate(${x} ${y}) rotate(${tilt}) scale(${t})`} opacity={clamp(t * 2)}>
    <path d="M 0 -44 L 0 -70" stroke={INK} strokeWidth={4} />
    <rect x={-84} y={-44} width={168} height={88} rx={22} fill={color} stroke={INK} strokeWidth={6} />
    <circle cx={-58} cy={0} r={9} fill="#2A1736" stroke={INK} strokeWidth={3} />
    <text x={16} y={2} textAnchor="middle" dominantBaseline="central" fontFamily={fontFamily} fontWeight={900} fontSize={fs} fill={INK}>
      {text}
    </text>
  </g>
);

/** Rotating light rays used to draw attention. */
export const Rays: React.FC<{x: number; y: number; r?: number; n?: number; rot?: number; color?: string; opacity?: number}> = ({
  x, y, r = 700, n = 12, rot = 0, color = '#FFE08A', opacity = 0.18,
}) => {
  const step = (Math.PI * 2) / n;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot})`} opacity={opacity}>
      {Array.from({length: n}, (_, i) => {
        if (i % 2) return null;
        const a = i * step;
        const b = a + step;
        return (
          <polygon key={i} points={`0,0 ${Math.cos(a) * r},${Math.sin(a) * r} ${Math.cos(b) * r},${Math.sin(b) * r}`} fill={color} />
        );
      })}
    </g>
  );
};

export const SpeechBubble: React.FC<{
  x: number; y: number; w: number; h: number; lines: string[]; t?: number; tailX?: number; fs?: number;
}> = ({x, y, w, h, lines, t = 1, tailX = -w / 4, fs = 50}) => (
  <g transform={`translate(${x} ${y}) scale(${t})`} opacity={clamp(t * 2)}>
    <path
      d={`M ${tailX - 22} ${h / 2 - 4} L ${tailX - 52} ${h / 2 + 52} L ${tailX + 26} ${h / 2 - 4} Z`}
      fill="#fff"
      stroke={INK}
      strokeWidth={6}
      strokeLinejoin="round"
    />
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={34} fill="#fff" stroke={INK} strokeWidth={6} />
    <rect x={tailX - 20} y={h / 2 - 9} width={44} height={12} fill="#fff" />
    {lines.map((l, i) => (
      <text
        key={i}
        x={0}
        y={(i - (lines.length - 1) / 2) * (fs * 1.1)}
        textAnchor="middle"
        dominantBaseline="central"
        fontFamily={fontFamily}
        fontWeight={900}
        fontSize={fs}
        fill={INK}
      >
        {l}
      </text>
    ))}
  </g>
);

export const ThoughtBubble: React.FC<{cx: number; cy: number; rx: number; ry: number; tail: {x: number; y: number}[]; t?: number}> = ({
  cx, cy, rx, ry, tail, t = 1,
}) => {
  const blobs = [
    [0, 0, 1, 1], [-0.62, -0.1, 0.5, 0.62], [0.62, -0.1, 0.5, 0.62], [-0.3, -0.62, 0.5, 0.5],
    [0.3, -0.62, 0.5, 0.5], [-0.35, 0.58, 0.5, 0.5], [0.35, 0.58, 0.5, 0.5],
  ];
  return (
    <g transform={`translate(${cx} ${cy}) scale(${t}) translate(${-cx} ${-cy})`} opacity={clamp(t * 2)}>
      {[true, false].map((outline) => (
        <g key={String(outline)} fill={outline ? INK : '#EAF2FF'} stroke={outline ? INK : 'none'} strokeWidth={outline ? 14 : 0}>
          {blobs.map(([bx, by, bw, bh], i) => (
            <ellipse key={i} cx={cx + bx * rx} cy={cy + by * ry} rx={rx * 0.55 * bw + 28} ry={ry * 0.55 * bh + 28} />
          ))}
          {tail.map((p, i) => (
            <circle key={`t${i}`} cx={p.x} cy={p.y} r={14 + i * 8} />
          ))}
        </g>
      ))}
    </g>
  );
};

export const Bulb: React.FC<{x: number; y: number; on?: number}> = ({x, y, on = 1}) => (
  <g transform={`translate(${x} ${y})`}>
    <circle r={70} fill="#FFE27A" opacity={0.35 * on} />
    <circle r={34} fill={on > 0.5 ? '#FFE27A' : '#C9B66B'} stroke={INK} strokeWidth={5} />
    <rect x={-15} y={30} width={30} height={22} rx={6} fill="#bbb" stroke={INK} strokeWidth={5} />
    {Array.from({length: 7}, (_, i) => {
      const a = (-90 + (i - 3) * 38) * (Math.PI / 180);
      return (
        <line key={i} x1={Math.cos(a) * 52} y1={Math.sin(a) * 52} x2={Math.cos(a) * 74} y2={Math.sin(a) * 74} stroke="#FFE27A" strokeWidth={6} strokeLinecap="round" opacity={on} />
      );
    })}
  </g>
);

export const Magnifier: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <line x1={42} y1={42} x2={110} y2={110} stroke={INK} strokeWidth={22} strokeLinecap="round" />
    <line x1={42} y1={42} x2={110} y2={110} stroke="#8C5A2B" strokeWidth={12} strokeLinecap="round" />
    <circle r={62} fill="#BFE8FF" opacity={0.28} />
    <circle r={62} fill="none" stroke={INK} strokeWidth={14} />
    <circle r={62} fill="none" stroke="#E8EDF5" strokeWidth={6} />
  </g>
);

/** Cash register. drawer: 0 (closed) … 1 (open). */
export const Register: React.FC<{x: number; y: number; s?: number; drawer?: number; flash?: number}> = ({
  x, y, s = 1, drawer = 0, flash = 0,
}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-95} y={-26 + drawer * 14} width={190} height={30} rx={8} fill="#6B6F80" stroke={INK} strokeWidth={5} />
    <rect x={-95} y={-130} width={190} height={104} rx={14} fill="#8E93A8" stroke={INK} strokeWidth={5} />
    <rect x={-70} y={-205} width={140} height={78} rx={10} fill="#2A2F45" stroke={INK} strokeWidth={5} />
    <rect x={-60} y={-195} width={120} height={58} rx={6} fill={flash > 0.5 ? '#9CFFB0' : '#5CD67C'} />
    <text x={0} y={-166} textAnchor="middle" dominantBaseline="central" fontFamily={fontFamily} fontWeight={900} fontSize={44} fill="#0E4D22">$$$</text>
    {Array.from({length: 8}, (_, i) => (
      <rect key={i} x={-76 + (i % 4) * 40} y={-114 + Math.floor(i / 4) * 40} width={30} height={28} rx={6} fill="#D8DCEA" stroke={INK} strokeWidth={3} />
    ))}
  </g>
);

export const CinemaSeat: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = '#8E1F3D'}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-120} y={-250} width={74} height={260} rx={30} fill={color} stroke={INK} strokeWidth={6} />
    <rect x={-120} y={-250} width={30} height={260} rx={15} fill="#fff" opacity={0.1} />
    <rect x={-90} y={-26} width={230} height={42} rx={20} fill={color} stroke={INK} strokeWidth={6} />
    <rect x={-100} y={-60} width={150} height={26} rx={12} fill="#A92A4D" stroke={INK} strokeWidth={6} opacity={0} />
    <rect x={-70} y={10} width={30} height={64} rx={8} fill="#2A1736" stroke={INK} strokeWidth={5} />
  </g>
);

export const Dust: React.FC<{frame: number; n?: number; seed?: number; color?: string; opacity?: number; speed?: number}> = ({
  frame, n = 26, seed = 5, color = '#FFE9B8', opacity = 0.35, speed = 0.7,
}) => {
  let t = seed;
  const r = () => {
    t = (t * 9301 + 49297) % 233280;
    return t / 233280;
  };
  return (
    <g>
      {Array.from({length: n}, (_, i) => {
        const x0 = r() * 1080;
        const y0 = r() * 1920;
        const rad = 2 + r() * 4;
        const sp = speed * (0.5 + r());
        const y = (((y0 - frame * sp) % 1920) + 1920) % 1920;
        const x = x0 + Math.sin(frame / 30 + i) * 14;
        return <circle key={i} cx={x} cy={y} r={rad} fill={color} opacity={opacity * (0.4 + r() * 0.6)} />;
      })}
    </g>
  );
};
