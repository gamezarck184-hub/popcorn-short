import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS} from '../config';
import {fontFamily} from '../fonts';
import {E, prog, springAt} from '../lib/anim';

/** English on-screen title. **word** is highlighted. */
export const OnScreenText: React.FC<{text: string; delay?: number; top?: number; size?: number}> = ({
  text, delay = 6, top = 235, size = 82,
}) => {
  const f = useCurrentFrame();
  const s = springAt(f, delay, 13, 150);
  const o = prog(f, delay, delay + 8, E.out);
  const parts = text.split(/(\*\*[^*]+\*\*)/g).filter(Boolean);
  return (
    <div
      style={{
        position: 'absolute',
        left: 60,
        right: 60,
        top,
        textAlign: 'center',
        transform: `translateY(${(1 - s) * -50}px) scale(${0.85 + 0.15 * s})`,
        opacity: o,
        fontFamily,
        fontWeight: 900,
        fontSize: size,
        lineHeight: 1.05,
        letterSpacing: 1,
        color: '#fff',
        textTransform: 'uppercase',
        paintOrder: 'stroke fill',
        WebkitTextStroke: '10px rgba(10,6,24,0.92)',
        textShadow: '0 8px 0 rgba(0,0,0,0.35)',
      }}
    >
      {parts.map((p, i) =>
        p.startsWith('**') ? (
          <span key={i} style={{color: COLORS.gold}}>
            {p.slice(2, -2)}
          </span>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </div>
  );
};
