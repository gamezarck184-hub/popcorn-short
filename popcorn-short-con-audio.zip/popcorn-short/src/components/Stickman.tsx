import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS} from '../config';
import {DIM, IDLE, Pose, getRig} from '../lib/pose';

const INK = COLORS.ink;

export type Expression = 'neutral' | 'happy' | 'surprised' | 'thinking' | 'smug' | 'excited' | 'wink';
export type Outfit = {main: string; dark: string; light: string};
export const GREEN: Outfit = {main: COLORS.green, dark: COLORS.greenDark, light: COLORS.greenLight};
export const RED: Outfit = {main: '#D9363E', dark: '#9E1F27', light: '#FF7B7B'};

type Pt = {x: number; y: number};

const Limb: React.FC<{pts: Pt[]; w: number; color: string; outline?: string}> = ({pts, w, color, outline}) => {
  const d = pts.map((p) => `${p.x},${p.y}`).join(' ');
  return (
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      {outline ? <polyline points={d} stroke={outline} strokeWidth={w + 8} /> : null}
      <polyline points={d} stroke={color} strokeWidth={w} />
    </g>
  );
};

const Face: React.FC<{expression: Expression; look: number; blink: number}> = ({expression, look, blink}) => {
  const lx = look * 3;
  let eyeScale = 1;
  let brows: [number, number, number, number] = [0, 0, 0, 0];
  let mouth: React.ReactNode = (
    <path d="M 10 22 Q 23 26 36 22" stroke={INK} strokeWidth={4.5} fill="none" strokeLinecap="round" />
  );
  switch (expression) {
    case 'happy':
      brows = [-3, -4, -4, -3];
      mouth = <path d="M 8 16 Q 23 38 38 16" stroke={INK} strokeWidth={4.5} fill="none" strokeLinecap="round" />;
      break;
    case 'surprised':
      brows = [-9, -10, -10, -9];
      eyeScale = 1.25;
      mouth = <ellipse cx={23} cy={27} rx={6.5} ry={9} fill={INK} />;
      break;
    case 'thinking':
      brows = [-7, -3, 2, 3];
      mouth = <path d="M 12 26 L 34 21" stroke={INK} strokeWidth={4.5} fill="none" strokeLinecap="round" />;
      break;
    case 'smug':
      brows = [2, 4, -3, -6];
      mouth = <path d="M 10 25 Q 26 30 38 16" stroke={INK} strokeWidth={4.5} fill="none" strokeLinecap="round" />;
      break;
    case 'excited':
      brows = [-8, -9, -9, -8];
      eyeScale = 1.2;
      mouth = <path d="M 7 15 Q 23 44 39 15 Z" fill={INK} stroke={INK} strokeWidth={3} strokeLinejoin="round" />;
      break;
    case 'wink':
      brows = [-3, -3, -3, -3];
      mouth = <path d="M 8 17 Q 23 36 38 17" stroke={INK} strokeWidth={4.5} fill="none" strokeLinecap="round" />;
      break;
    default:
      break;
  }
  const eyeRy = 6.5 * eyeScale * blink;
  const eyeRx = 5.5 * eyeScale;
  return (
    <g>
      <ellipse cx={13 + lx} cy={-4} rx={eyeRx} ry={eyeRy} fill={INK} />
      {expression === 'wink' ? (
        <path d="M 26 -4 Q 33 -9 40 -4" stroke={INK} strokeWidth={4.5} fill="none" strokeLinecap="round" />
      ) : (
        <ellipse cx={33 + lx * 0.8} cy={-4} rx={eyeRx} ry={eyeRy} fill={INK} />
      )}
      {expression === 'excited' ? (
        <>
          <circle cx={11 + lx} cy={-7} r={2.2} fill="#fff" />
          <circle cx={31 + lx * 0.8} cy={-7} r={2.2} fill="#fff" />
        </>
      ) : null}
      <path d={`M 4 ${-19 + brows[0]} L 21 ${-19 + brows[1]}`} stroke={INK} strokeWidth={4.5} strokeLinecap="round" />
      <path d={`M 25 ${-19 + brows[2]} L 42 ${-19 + brows[3]}`} stroke={INK} strokeWidth={4.5} strokeLinecap="round" />
      {mouth}
    </g>
  );
};

export type StickmanProps = {
  /** x of the hips (center). */
  x: number;
  /** y of the hips. Feet rest at y + DIM.legLen * scale when legs are straight. */
  y: number;
  scale?: number;
  facing?: 1 | -1;
  pose?: Pose;
  expression?: Expression;
  /** -1 … 1, where the pupils look. */
  look?: number;
  shadow?: boolean;
  outfit?: Outfit;
  opacity?: number;
  breathe?: boolean;
};

/**
 * The one and only stickman: white round head, black body and limbs,
 * hoodie over torso + arms. Fixed proportions (see DIM), only angles change.
 */
export const Stickman: React.FC<StickmanProps> = ({
  x,
  y,
  scale = 1.25,
  facing = 1,
  pose = IDLE,
  expression = 'neutral',
  look = 0.6,
  shadow = true,
  outfit = GREEN,
  opacity = 1,
  breathe = true,
}) => {
  const frame = useCurrentFrame();
  const br = breathe ? Math.sin(frame / 13) : 0;
  const p: Pose = {
    ...pose,
    lean: pose.lean + br * 0.8,
    bob: pose.bob + br * 1.2,
  };
  const rig = getRig(p);
  const blink = (frame + 17) % 110 < 4 ? 0.12 : 1;
  const halo = 'rgba(255,255,255,0.30)';
  const T = DIM.torso;

  return (
    <g transform={`translate(${x} ${y}) scale(${scale * facing} ${scale})`} opacity={opacity}>
      {shadow ? <ellipse cx={14} cy={DIM.legLen + 6} rx={78} ry={13} fill="#000" opacity={0.32} /> : null}
      <g transform={`translate(0 ${p.bob})`}>
        {/* far arm */}
        <Limb pts={[rig.shoulder, rig.armBack.mid, rig.armBack.end]} w={20} color={outfit.dark} outline={INK} />
        <circle cx={rig.armBack.end.x} cy={rig.armBack.end.y} r={11} fill={INK} />

        {/* legs */}
        <Limb pts={[{x: -7, y: 0}, rig.legBack.mid, rig.legBack.end]} w={15} color={INK} outline={halo} />
        <Limb
          pts={[rig.legBack.end, {x: rig.legBack.end.x + 24, y: rig.legBack.end.y + 3}]}
          w={15}
          color={INK}
          outline={halo}
        />
        <Limb pts={[{x: 7, y: 0}, rig.legFront.mid, rig.legFront.end]} w={15} color={INK} outline={halo} />
        <Limb
          pts={[rig.legFront.end, {x: rig.legFront.end.x + 24, y: rig.legFront.end.y + 3}]}
          w={15}
          color={INK}
          outline={halo}
        />

        {/* hoodie torso */}
        <g transform={`rotate(${p.lean})`}>
          <rect x={-30} y={-T - 4} width={60} height={T + 16} rx={24} fill={outfit.main} stroke={INK} strokeWidth={5} />
          <rect x={14} y={-T + 8} width={9} height={T - 30} rx={4.5} fill={outfit.light} opacity={0.4} />
          <rect x={-27} y={-8} width={54} height={14} rx={7} fill={outfit.dark} />
          <path d="M -20 -56 L 20 -56 L 25 -28 Q 0 -22 -25 -28 Z" fill={outfit.dark} opacity={0.55} />
          <ellipse cx={0} cy={-T + 2} rx={36} ry={20} fill={outfit.dark} stroke={INK} strokeWidth={5} />
          <path d={`M -8 ${-T + 12} L -9 ${-T + 40}`} stroke="#fff" strokeWidth={3.5} strokeLinecap="round" />
          <path d={`M 9 ${-T + 12} L 10 ${-T + 40}`} stroke="#fff" strokeWidth={3.5} strokeLinecap="round" />
        </g>

        {/* head */}
        <g transform={`translate(${rig.head.x} ${rig.head.y}) rotate(${p.lean + p.headTilt})`}>
          <circle r={DIM.headR} fill="#fff" stroke={INK} strokeWidth={6} />
          <Face expression={expression} look={look} blink={blink} />
        </g>

        {/* near arm */}
        <Limb pts={[rig.shoulder, rig.armFront.mid, rig.armFront.end]} w={20} color={outfit.main} outline={INK} />
        <circle cx={rig.armFront.end.x} cy={rig.armFront.end.y} r={11} fill={INK} />
      </g>
    </g>
  );
};
