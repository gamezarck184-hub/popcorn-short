import React from 'react';
import {useCurrentFrame} from 'remotion';
import {HEIGHT, WIDTH} from '../config';
import {E, lerp, prog} from '../lib/anim';

export type Cam = {s: number; fx: number; fy: number};

/** Virtual camera: scale `s` around focus point (fx, fy). Interpolates from → to. */
export const Camera: React.FC<{from: Cam; to: Cam; duration: number; children: React.ReactNode}> = ({
  from, to, duration, children,
}) => {
  const f = useCurrentFrame();
  const t = prog(f, 0, duration, E.inOut);
  const s = lerp(from.s, to.s, t);
  const halfW = WIDTH / 2 / s;
  const halfH = HEIGHT / 2 / s;
  const fx = Math.min(WIDTH - halfW, Math.max(halfW, lerp(from.fx, to.fx, t)));
  const fy = Math.min(HEIGHT - halfH, Math.max(halfH, lerp(from.fy, to.fy, t)));
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: WIDTH,
        height: HEIGHT,
        transformOrigin: '0 0',
        transform: `translate(${WIDTH / 2 - fx * s}px, ${HEIGHT / 2 - fy * s}px) scale(${s})`,
      }}
    >
      {children}
    </div>
  );
};

export const SceneSvg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', left: 0, top: 0}}>
    {children}
  </svg>
);
