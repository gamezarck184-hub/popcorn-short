import React from 'react';
import {useCurrentFrame} from 'remotion';
import {fontFamily} from '../fonts';
import {E, prog} from '../lib/anim';
import {SCENES, sec} from '../script';

/** Spanish subtitles synced to the narration timing in script.ts. */
export const Subtitles: React.FC = () => {
  const f = useCurrentFrame();
  const lines = SCENES.flatMap((s) => s.lines);
  const active = lines.find((l) => f >= sec(l.from) && f < sec(l.to));
  if (!active) return null;
  const from = sec(active.from);
  const to = sec(active.to);
  const inT = prog(f, from, from + 5, E.out);
  const outT = prog(f, to - 4, to, E.in);
  const o = inT * (1 - outT);
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: 1465,
        display: 'flex',
        justifyContent: 'center',
        opacity: o,
        transform: `translateY(${(1 - inT) * 18}px)`,
      }}
    >
      <div
        style={{
          maxWidth: 940,
          padding: '14px 30px',
          borderRadius: 26,
          background: 'rgba(8,6,20,0.62)',
          fontFamily,
          fontWeight: 800,
          fontSize: 52,
          lineHeight: 1.18,
          textAlign: 'center',
          color: '#fff',
          whiteSpace: 'pre-wrap',
          textShadow: '0 3px 8px rgba(0,0,0,0.7)',
        }}
      >
        {active.text}
      </div>
    </div>
  );
};

export const Vignette: React.FC = () => (
  <div
    style={{
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none',
      background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.45) 100%)',
    }}
  />
);
