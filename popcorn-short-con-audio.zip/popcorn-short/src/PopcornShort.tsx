import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {HAS_NARRATION, NARRATION_FILE, OVERLAP} from './config';
import {SCENES, sec} from './script';
import {SceneTransition} from './components/SceneTransition';
import {Subtitles, Vignette} from './components/Subtitles';
import {SceneProps} from './scenes/common';
import {Scene01Lobby} from './scenes/Scene01Lobby';
import {Scene02Menu} from './scenes/Scene02Menu';
import {Scene03Small} from './scenes/Scene03Small';
import {Scene04Medium} from './scenes/Scene04Medium';
import {Scene05Compare} from './scenes/Scene05Compare';
import {Scene06Deal} from './scenes/Scene06Deal';
import {Scene07Mind} from './scenes/Scene07Mind';
import {Scene08Choice} from './scenes/Scene08Choice';
import {Scene09Cinema} from './scenes/Scene09Cinema';
import {Scene10Closing} from './scenes/Scene10Closing';
import './fonts';

const COMPONENTS: React.FC<SceneProps>[] = [
  Scene01Lobby, Scene02Menu, Scene03Small, Scene04Medium, Scene05Compare,
  Scene06Deal, Scene07Mind, Scene08Choice, Scene09Cinema, Scene10Closing,
];

export const PopcornShort: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    {SCENES.map((s, i) => {
      const start = sec(s.start);
      const len = sec(s.end) - start;
      const isLast = i === SCENES.length - 1;
      const C = COMPONENTS[i];
      return (
        <Sequence key={s.id} from={start} durationInFrames={len + (isLast ? 0 : OVERLAP)} name={s.id}>
          <SceneTransition index={i}>
            <C title={s.title} duration={len} />
          </SceneTransition>
        </Sequence>
      );
    })}
    <Vignette />
    <Subtitles />
    {HAS_NARRATION ? <Audio src={staticFile(NARRATION_FILE)} /> : null}
  </AbsoluteFill>
);
