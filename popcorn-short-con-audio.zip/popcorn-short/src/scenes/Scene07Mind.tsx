import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS, GROUND} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {MindBg} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {PopcornBox} from '../components/PopcornBox';
import {Sparkle, ThoughtBubble} from '../components/Props';
import {Stickman} from '../components/Stickman';
import {fontFamily} from '../fonts';
import {E, prog, springAt} from '../lib/anim';
import {DIM, IDLE, THINK, blend, getRig, toWorld} from '../lib/pose';
import {SceneProps} from './common';

const PIVOT = {x: 640, y: 590};
const HALF = 150;
const HANG = 120;

const Pill: React.FC<{x: number; y: number; t: number; lines: string[]; color: string; w: number}> = ({x, y, t, lines, color, w}) => (
  <g transform={`translate(${x} ${y}) scale(${t})`} opacity={Math.min(1, t * 2)}>
    <rect x={-w / 2} y={-22 - (lines.length - 1) * 17} width={w} height={44 + (lines.length - 1) * 34} rx={24} fill={color} stroke="#0B0B10" strokeWidth={5} />
    {lines.map((l, i) => (
      <text key={i} y={(i - (lines.length - 1) / 2) * 34} textAnchor="middle" dominantBaseline="central" fontFamily={fontFamily} fontWeight={900} fontSize={27} fill="#fff">
        {l}
      </text>
    ))}
  </g>
);

export const Scene07Mind: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  const sc = 1.2;
  const hip = GROUND - DIM.legLen * sc;
  const x = 330;
  const pose = blend(IDLE, THINK, prog(f, 0, 18));
  const rig = getRig(pose);
  const head = toWorld(rig.head, {x, y: hip, scale: sc, facing: 1, bob: 0});

  const bubble = springAt(f, 6, 12, 140);
  const scaleIn = springAt(f, 26, 14, 150);
  const tiltT = springAt(f, 80, 9, 70);
  const tilt = 13 * tiltT + Math.sin(f / 9) * 0.8 * prog(f, 110, 130);
  const tr = (tilt * Math.PI) / 180;
  const left = {x: PIVOT.x - HALF * Math.cos(tr), y: PIVOT.y - HALF * Math.sin(tr)};
  const right = {x: PIVOT.x + HALF * Math.cos(tr), y: PIVOT.y + HALF * Math.sin(tr)};
  const drop = (d: number) => prog(f, d, d + 18, E.outBounce);
  const mY = left.y + HANG - (1 - drop(34)) * 260;
  const lY = right.y + HANG - (1 - drop(42)) * 260;
  const tagM = springAt(f, 62, 11, 170);
  const tagL = springAt(f, 112, 11, 170);

  return (
    <>
      <Camera from={{s: 1.0, fx: 540, fy: 960}} to={{s: 1.06, fx: 560, fy: 990}} duration={duration}>
        <SceneSvg>
          <MindBg frame={f} />
          <ThoughtBubble
            cx={640}
            cy={710}
            rx={330}
            ry={230}
            tail={[{x: 470, y: 930}, {x: 425, y: 960}, {x: 392, y: 988}]}
            t={bubble}
          />
          <g opacity={scaleIn}>
            {/* balance scale */}
            <path d={`M ${PIVOT.x} ${PIVOT.y} L ${PIVOT.x} 850`} stroke="#0B0B10" strokeWidth={22} strokeLinecap="round" />
            <path d={`M ${PIVOT.x} ${PIVOT.y} L ${PIVOT.x} 850`} stroke="#7C86A8" strokeWidth={11} strokeLinecap="round" />
            <path d={`M ${PIVOT.x - 90} 856 L ${PIVOT.x + 90} 856`} stroke="#0B0B10" strokeWidth={26} strokeLinecap="round" />
            <path d={`M ${PIVOT.x - 90} 856 L ${PIVOT.x + 90} 856`} stroke="#7C86A8" strokeWidth={14} strokeLinecap="round" />
            {[left, right].map((p, i) => (
              <g key={i}>
                <path d={`M ${p.x} ${p.y} L ${p.x - 55} ${p.y + HANG} M ${p.x} ${p.y} L ${p.x + 55} ${p.y + HANG}`} stroke="#0B0B10" strokeWidth={4} />
                <ellipse cx={p.x} cy={p.y + HANG + 6} rx={72} ry={13} fill="#C9D2F2" stroke="#0B0B10" strokeWidth={5} />
              </g>
            ))}
            <line x1={left.x} y1={left.y} x2={right.x} y2={right.y} stroke="#0B0B10" strokeWidth={22} strokeLinecap="round" />
            <line x1={left.x} y1={left.y} x2={right.x} y2={right.y} stroke="#FFD35A" strokeWidth={11} strokeLinecap="round" />
            <circle cx={PIVOT.x} cy={PIVOT.y} r={16} fill="#fff" stroke="#0B0B10" strokeWidth={6} />
          </g>
          <PopcornBox size="M" x={left.x} y={mY} scale={0.3} opacity={drop(34) > 0 ? 1 : 0} />
          <PopcornBox size="L" x={right.x} y={lY} scale={0.33} opacity={drop(42) > 0 ? 1 : 0} glow={f > 100} />
          <Pill x={left.x} y={mY + 48} t={tagM} lines={['REFERENCE']} color="#3556C8" w={250} />
          <Pill x={right.x + 40} y={lY - 150} t={tagL} lines={['FEELS LIKE', 'A DEAL']} color={COLORS.coral} w={210} />
          {[{x: 800, y: 560, d: 120}, {x: 905, y: 700, d: 130}, {x: 760, y: 820, d: 140}].map((s, i) => (
            <Sparkle key={i} x={s.x} y={s.y} s={0.6 * prog(f, s.d, s.d + 12) * (0.6 + 0.4 * Math.sin(f / 6 + i))} rot={f * 2} />
          ))}
          <Stickman x={x} y={hip} scale={sc} pose={pose} expression={f < 100 ? 'thinking' : 'smug'} look={0.7} />
          {/* thought sweat-free "?" above head while comparing */}
          <text x={head.x - 60} y={head.y - 80} fontFamily={fontFamily} fontWeight={900} fontSize={70} fill="#BBD0FF" opacity={f < 80 ? 0.9 : 0} transform={`rotate(-12 ${head.x - 60} ${head.y - 80})`}>
            ?
          </text>
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={4} />
    </>
  );
};
