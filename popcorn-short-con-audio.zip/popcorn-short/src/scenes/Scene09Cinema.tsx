import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS, COUNTER_TOP} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {CinemaBg, Counter} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {Coin, Register, Sparkle} from '../components/Props';
import {RED, Stickman} from '../components/Stickman';
import {fontFamily} from '../fonts';
import {E, lerp, prog} from '../lib/anim';
import {IDLE, TOSS, blend, getRig, toWorld} from '../lib/pose';
import {HERO_HIP, HERO_SCALE, SceneProps} from './common';

const CUSTOMER_X = 150;
const REG = {x: 760, y: COUNTER_TOP - 4};
const COIN_FIRST = 10;
const COIN_GAP = 9;
const COIN_FLIGHT = 24;
const COINS = 8;

export const Scene09Cinema: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  const pose = blend(IDLE, TOSS, prog(f, 0, 12));
  const hand = toWorld(getRig(TOSS).armFront.end, {x: CUSTOMER_X, y: HERO_HIP, scale: HERO_SCALE, facing: 1});
  const dest = {x: REG.x, y: REG.y - 190};

  // register reacts to each coin that arrives
  let pulse = 0;
  for (let i = 0; i < COINS; i++) {
    const arrive = COIN_FIRST + i * COIN_GAP + COIN_FLIGHT;
    if (f >= arrive && f < arrive + 8) pulse = Math.max(pulse, 1 - (f - arrive) / 8);
  }
  const chart = [70, 130, 205];
  const arrow = prog(f, 62, 100, E.out);
  const cashierPose = blend(IDLE, {...IDLE, armFront: [150, 15], armBack: [140, 20]}, prog(f, 50, 66));

  return (
    <>
      <Camera from={{s: 1.0, fx: 560, fy: 1000}} to={{s: 1.07, fx: 600, fy: 1000}} duration={duration}>
        <SceneSvg>
          <CinemaBg variant="snack" frame={f} />
          {/* growing bars behind the register: an icon, not data */}
          <g opacity={prog(f, 50, 66)}>
            {chart.map((h, i) => {
              const t = prog(f, 56 + i * 8, 80 + i * 8, E.outBack);
              return (
                <rect key={i} x={640 + i * 100} y={930 - h * t} width={70} height={h * t} rx={12} fill={COLORS.greenLight} stroke="#0B0B10" strokeWidth={6} />
              );
            })}
            <path
              d="M 625 830 L 740 760 L 830 790 L 975 640"
              fill="none"
              stroke="#fff"
              strokeWidth={14}
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeDasharray="520"
              strokeDashoffset={520 * (1 - arrow)}
            />
            <g opacity={arrow > 0.95 ? 1 : 0}>
              <polygon points="975,640 930,650 962,684" fill="#fff" stroke="#fff" strokeWidth={8} strokeLinejoin="round" />
            </g>
          </g>
          <Stickman x={980} y={HERO_HIP} facing={-1} outfit={RED} pose={cashierPose} expression="excited" look={0.6} />
          <Counter frame={f} />
          <Register x={REG.x} y={REG.y} s={0.95} drawer={pulse} flash={pulse} />
          {Array.from({length: COINS}, (_, i) => {
            const start = COIN_FIRST + i * COIN_GAP;
            const t = (f - start) / COIN_FLIGHT;
            if (t < 0 || t > 1) return null;
            const e = E.inOut(t);
            const cx = lerp(hand.x, dest.x, e);
            const cy = lerp(hand.y, dest.y, e) - Math.sin(t * Math.PI) * 210;
            return <Coin key={i} x={cx} y={cy} r={26} spin={t * Math.PI * 5} />;
          })}
          {Array.from({length: COINS}, (_, i) => {
            const arrive = COIN_FIRST + i * COIN_GAP + COIN_FLIGHT;
            const t = (f - arrive) / 26;
            if (t < 0 || t > 1) return null;
            return (
              <text
                key={i}
                x={REG.x - 60 + (i % 3) * 60}
                y={REG.y - 230 - t * 150}
                textAnchor="middle"
                fontFamily={fontFamily}
                fontWeight={900}
                fontSize={52}
                fill={COLORS.gold}
                stroke="#0B0B10"
                strokeWidth={5}
                paintOrder="stroke"
                opacity={1 - t}
              >
                $
              </text>
            );
          })}
          {pulse > 0 ? <Sparkle x={REG.x + 70} y={REG.y - 220} s={0.9 * pulse} rot={f * 8} /> : null}
          <Stickman x={CUSTOMER_X} y={HERO_HIP} pose={pose} expression="happy" look={1} />
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={4} />
    </>
  );
};
