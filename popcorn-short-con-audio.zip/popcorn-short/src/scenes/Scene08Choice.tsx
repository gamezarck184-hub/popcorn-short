import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COUNTER_TOP} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {CinemaBg, Counter} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {PopcornBox} from '../components/PopcornBox';
import {PriceTag, Sparkle, SpeechBubble} from '../components/Props';
import {RED, Stickman} from '../components/Stickman';
import {E, lerp, prog, springAt} from '../lib/anim';
import {HOLD, IDLE, POINT, blend, getRig, toWorld} from '../lib/pose';
import {HERO_HIP, HERO_SCALE, SceneProps} from './common';
import {MENU} from './Scene02Menu';

const CUSTOMER_X = 150;

export const Scene08Choice: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  const bubble = springAt(f, 8, 11, 170);
  const fade = 0.3 + 0.7 * (1 - prog(f, 14, 30));
  const jump = f > 100 ? -Math.abs(Math.sin((f - 100) / 7)) * 22 * (1 - prog(f, 100, 150)) : 0;

  // customer pose
  let pose = blend(IDLE, POINT, prog(f, 0, 14));
  pose = blend(pose, HOLD, prog(f, 64, 84));
  pose = {...pose, bob: pose.bob + jump};
  const expression = f < 64 ? 'neutral' : 'happy';

  // where the hands end up when holding the box
  const hold = getRig(HOLD);
  const mid = {
    x: (hold.armFront.end.x + hold.armBack.end.x) / 2,
    y: (hold.armFront.end.y + hold.armBack.end.y) / 2,
  };
  const target = toWorld(mid, {x: CUSTOMER_X, y: HERO_HIP, scale: HERO_SCALE, facing: 1});
  const tx = target.x + 6;
  const ty = target.y + 46 + jump * HERO_SCALE;

  // box path: counter → slides toward customer → into hands
  const slide = prog(f, 34, 62, E.inOut);
  const lift = prog(f, 66, 92, E.inOut);
  const bx = lerp(lerp(900, 470, slide), tx, lift);
  const by = lerp(COUNTER_TOP - 2, ty, lift);
  const bs = lerp(1, 0.5, lift);

  const cashierPose = blend(IDLE, {...POINT, lean: 4, armFront: [80, 8]}, prog(f, 28, 44));
  const cashierBack = blend(cashierPose, IDLE, prog(f, 70, 90));

  return (
    <>
      <Camera from={{s: 1.0, fx: 600, fy: 1000}} to={{s: 1.1, fx: 520, fy: 1010}} duration={duration}>
        <SceneSvg>
          <CinemaBg variant="snack" frame={f} />
          <Stickman x={960} y={HERO_HIP} facing={-1} outfit={RED} pose={cashierBack} expression="happy" look={0.8} />
          <Counter frame={f} />
          {MENU.filter((m) => m.size !== 'L').map((m) => (
            <g key={m.size} opacity={fade}>
              <PopcornBox size={m.size} x={m.x} y={COUNTER_TOP - 2} />
            </g>
          ))}
          <PopcornBox size="L" x={bx} y={by} scale={bs} glow={f < 66} />
          {f < 34 ? <PriceTag x={900} y={COUNTER_TOP - 520} text="$8" t={1} tilt={-5} /> : null}
          <Stickman x={CUSTOMER_X} y={HERO_HIP} pose={pose} expression={expression} look={0.9} />
          <SpeechBubble x={520} y={820} w={640} h={130} lines={['LARGE, PLEASE!']} t={bubble * (1 - prog(f, 60, 72))} tailX={-270} />
          {[{x: 330, y: 900, d: 96}, {x: 140, y: 880, d: 102}, {x: 360, y: 1030, d: 108}].map((s, i) => (
            <Sparkle key={i} x={s.x} y={s.y} s={0.75 * prog(f, s.d, s.d + 12) * (0.6 + 0.4 * Math.sin(f / 5 + i))} rot={f * 3} />
          ))}
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={4} />
    </>
  );
};
