import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS, COUNTER_TOP} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {CinemaBg, Counter} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {BOX, PopcornBox} from '../components/PopcornBox';
import {PriceTag, Rays, Sparkle, Starburst} from '../components/Props';
import {Stickman} from '../components/Stickman';
import {fontFamily} from '../fonts';
import {E, prog, springAt} from '../lib/anim';
import {HOLD, SURPRISED, blend} from '../lib/pose';
import {HERO_HIP, SceneProps} from './common';

export const Scene06Deal: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  const lGrow = 1 + 0.15 * prog(f, 8, 40, E.outBack) + 0.025 * Math.sin(f / 5);
  const burst = springAt(f, 40, 9, 150);
  const rub = Math.sin(f / 3) * 7;
  const pose = blend(SURPRISED, {...HOLD, armFront: [56 + rub, 72], armBack: [60 - rub, 66]}, prog(f, 0, 18));
  const arrow = prog(f, 22, 46, E.out);
  const label = springAt(f, 44, 12, 170);
  const mTop = COUNTER_TOP - BOX.M.h - BOX.M.mound - 120;
  const lTop = COUNTER_TOP - (BOX.L.h + BOX.L.mound) * 1.15 - 120;

  return (
    <>
      <Camera from={{s: 1.0, fx: 540, fy: 1000}} to={{s: 1.08, fx: 560, fy: 1010}} duration={duration}>
        <SceneSvg>
          <CinemaBg variant="snack" frame={f} />
          <Counter frame={f} />
          <Rays x={810} y={COUNTER_TOP - 220} r={640} rot={-f * 0.7} opacity={0.1 * prog(f, 0, 20)} />
          <PopcornBox size="M" x={480} y={COUNTER_TOP - 2} />
          <PriceTag x={480} y={mTop} text="$7" tilt={4} />
          <PopcornBox size="L" x={810} y={COUNTER_TOP - 2} scale={lGrow} glow />
          <PriceTag x={810} y={lTop} text="$8" tilt={-5} />
          <path
            d={`M 500 ${mTop - 70} Q 640 ${lTop - 70} 790 ${lTop - 80}`}
            fill="none"
            stroke={COLORS.greenLight}
            strokeWidth={9}
            strokeLinecap="round"
            strokeDasharray="420"
            strokeDashoffset={420 * (1 - arrow)}
          />
          <g transform={`translate(640 ${(mTop + lTop) / 2 - 90}) scale(${label})`} opacity={Math.min(1, label * 2)}>
            <rect x={-70} y={-28} width={140} height={56} rx={28} fill={COLORS.greenDark} stroke="#0B0B10" strokeWidth={5} />
            <text textAnchor="middle" dominantBaseline="central" fontFamily={fontFamily} fontWeight={900} fontSize={34} fill="#fff">+$1</text>
          </g>
          <Starburst x={905} y={500} r={95} fill={COLORS.coral} text="DEAL?" fontSize={42} rot={f * 1.5} scale={burst} />
          {[
            {x: 650, y: 880, s: 0.7, d: 20},
            {x: 985, y: 900, s: 0.8, d: 28},
            {x: 700, y: 760, s: 0.5, d: 36},
            {x: 930, y: 1040, s: 0.6, d: 44},
          ].map((sp, i) => {
            const t = 0.55 + 0.45 * Math.sin((f + sp.d * 3) / 6);
            return <Sparkle key={i} x={sp.x} y={sp.y} s={sp.s * t * prog(f, sp.d, sp.d + 14)} rot={f * 2 + i * 25} />;
          })}
          <Stickman x={110} y={HERO_HIP} pose={pose} expression="excited" look={1} />
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={4} />
    </>
  );
};
