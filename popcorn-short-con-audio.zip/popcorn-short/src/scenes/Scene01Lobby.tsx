import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COUNTER_TOP} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {CinemaBg, Counter} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {PopcornBox, Kernel} from '../components/PopcornBox';
import {Rays} from '../components/Props';
import {Stickman} from '../components/Stickman';
import {E, lerp, prog, springAt} from '../lib/anim';
import {POINT, SURPRISED, blend, getRig, toWorld, walkPose} from '../lib/pose';
import {HERO_HIP, HERO_SCALE, SceneProps} from './common';
import {fontFamily} from '../fonts';

const BOX_X = 835;

export const Scene01Lobby: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  const walkT = prog(f, 0, 70, E.out);
  const x = lerp(-130, 250, walkT);
  let pose = walkPose(walkT * 3.4);
  pose = blend(pose, SURPRISED, prog(f, 56, 72));
  pose = blend(pose, POINT, prog(f, 92, 108));
  const expression = f < 68 ? 'neutral' : f < 96 ? 'surprised' : 'excited';

  const rig = getRig(pose);
  const head = toWorld(rig.head, {x, y: HERO_HIP, scale: HERO_SCALE, facing: 1, bob: pose.bob});
  const ex = springAt(f, 72, 9, 190);

  const pulse = f > 18 ? 1 + 0.035 * Math.sin(f / 4) : 1;
  const boxIn = springAt(f, 6, 11, 130);

  return (
    <>
      <Camera from={{s: 1, fx: 540, fy: 960}} to={{s: 1.09, fx: 640, fy: 1090}} duration={duration}>
        <SceneSvg>
          <CinemaBg variant="lobby" frame={f} />
          <Counter x0={600} frame={f} />
          <Rays x={BOX_X} y={COUNTER_TOP - 170} r={620} rot={f * 0.6} opacity={0.2 * boxIn} />
          <PopcornBox size="L" x={BOX_X} y={COUNTER_TOP - 2} scale={boxIn * pulse} glow heap={1} />
          {f > 28
            ? Array.from({length: 7}, (_, i) => {
                const period = 46;
                const t = ((f - 28 + i * 7) % period) / period;
                const ang = -Math.PI / 2 + (i - 3) * 0.28;
                const sp = 330 + (i % 3) * 60;
                const px = BOX_X + Math.cos(ang) * sp * t + (i - 3) * 6;
                const py = COUNTER_TOP - 330 + Math.sin(ang) * sp * t + 900 * t * t * 0.55;
                return <Kernel key={i} cx={px} cy={py} r={14} rot={t * 360 + i * 40} />;
              })
            : null}
          <Stickman x={x} y={HERO_HIP} pose={pose} expression={expression} look={0.9} />
          {f >= 72 ? (
            <g transform={`translate(${head.x + 10} ${head.y - 120}) scale(${ex})`}>
              <circle r={44} fill="#FFE27A" stroke="#0B0B10" strokeWidth={6} />
              <text textAnchor="middle" dominantBaseline="central" y={3} fontFamily={fontFamily} fontWeight={900} fontSize={66} fill="#0B0B10">
                !
              </text>
            </g>
          ) : null}
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={10} />
    </>
  );
};
