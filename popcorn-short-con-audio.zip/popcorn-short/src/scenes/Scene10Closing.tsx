import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS, GROUND} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {TheaterBg} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {PopcornBox, Kernel} from '../components/PopcornBox';
import {Bulb, CinemaSeat, Magnifier, Sparkle} from '../components/Props';
import {Stickman} from '../components/Stickman';
import {E, lerp, prog, springAt} from '../lib/anim';
import {DIM, SIT, blend, getRig, toWorld} from '../lib/pose';
import {SceneProps} from './common';

const SC = 1.2;
const HIP_X = 300;
const HIP_Y = GROUND - DIM.shin * SC;

export const Scene10Closing: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  // eating loop
  const t = (1 - Math.cos(f / 6.5)) / 2;
  const eat = blend(SIT, {...SIT, armFront: [70, 105]}, t);
  const reach = blend(SIT, {...SIT, armFront: [34, 24]}, 1 - t);
  const pose = blend(reach, eat, t);
  const head = toWorld(getRig(pose).head, {x: HIP_X, y: HIP_Y, scale: SC, facing: 1, bob: pose.bob});

  const boxes = [
    {s: 'S' as const, x: 310, d: 6},
    {s: 'M' as const, x: 540, d: 14},
    {s: 'L' as const, x: 780, d: 22},
  ];
  const lens = f < 62 ? lerp(300, 780, E.inOut(prog(f, 28, 62, E.linear))) : lerp(780, 540, E.inOut(prog(f, 62, 78, E.linear)));
  const bulb = springAt(f, 54, 9, 160);
  const out = prog(f, duration - 10, duration, E.in);

  return (
    <>
      <Camera from={{s: 1.0, fx: 540, fy: 960}} to={{s: 1.06, fx: 520, fy: 1000}} duration={duration}>
        <SceneSvg>
          <TheaterBg frame={f} />
          {boxes.map((b) => {
            const sp = springAt(f, b.d, 10, 170);
            return (
              <PopcornBox key={b.s} size={b.s} x={b.x} y={930} scale={0.78 * sp} glow={b.s === 'M' && f > 70} opacity={Math.min(1, sp * 2)} />
            );
          })}
          <g transform={`translate(${lens - 20} ${700})`} opacity={prog(f, 26, 34)}>
            <Magnifier x={0} y={0} s={1.1} />
          </g>
          <CinemaSeat x={HIP_X + 40} y={HIP_Y + 40} s={SC} />
          <PopcornBox size="L" x={HIP_X + 105} y={HIP_Y - 10} scale={0.3} />
          <Stickman x={HIP_X} y={HIP_Y} scale={SC} pose={pose} expression={f > 54 ? 'excited' : 'happy'} look={0.9} />
          {f % 12 < 6 ? <Kernel cx={head.x + 72} cy={head.y + 8} r={8} rot={f * 20} /> : null}
          <g transform={`translate(${head.x + 4} ${head.y - 128}) scale(${bulb})`} opacity={Math.min(1, bulb * 2)}>
            <Bulb x={0} y={0} />
          </g>
          {[{x: 130, y: 1000, d: 60}, {x: 600, y: 1010, d: 66}].map((s, i) => (
            <Sparkle key={i} x={s.x} y={s.y} s={0.7 * prog(f, s.d, s.d + 12) * (0.6 + 0.4 * Math.sin(f / 5 + i))} rot={f * 3} color={COLORS.butter} />
          ))}
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={4} />
      <div style={{position: 'absolute', inset: 0, background: '#000', opacity: out}} />
    </>
  );
};
