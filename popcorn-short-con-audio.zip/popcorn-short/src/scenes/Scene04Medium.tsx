import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS, COUNTER_TOP} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {CinemaBg, Counter} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {BOX, PopcornBox} from '../components/PopcornBox';
import {PriceTag, Sparkle} from '../components/Props';
import {Stickman} from '../components/Stickman';
import {E, prog, springAt} from '../lib/anim';
import {POINT, SHRUG, SURPRISED, blend} from '../lib/pose';
import {fontFamily} from '../fonts';
import {HERO_HIP, SceneProps} from './common';
import {MENU} from './Scene02Menu';

export const Scene04Medium: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  const mIn = prog(f, 6, 22, E.out);
  const hop = Math.sin(prog(f, 6, 24, E.linear) * Math.PI) * 60;
  const lIn = prog(f, 64, 78, E.out);
  const sDim = 0.28;
  let pose = blend(SHRUG, SURPRISED, prog(f, 0, 14));
  pose = blend(pose, POINT, prog(f, 70, 90));
  const expression = f < 70 ? 'surprised' : 'smug';
  const arrow = prog(f, 98, 120, E.out);
  const label = springAt(f, 112, 12, 170);

  return (
    <>
      <Camera from={{s: 1.18, fx: 480, fy: 1060}} to={{s: 1.08, fx: 580, fy: 1020}} duration={duration}>
        <SceneSvg>
          <CinemaBg variant="snack" frame={f} />
          <Counter frame={f} />
          {MENU.map((m) => {
            const top = COUNTER_TOP - BOX[m.size].h - BOX[m.size].mound - 120;
            const op = m.size === 'S' ? sDim : m.size === 'M' ? 0.28 + 0.72 * mIn : 0.28 + 0.72 * lIn;
            const yOff = m.size === 'M' ? -hop : 0;
            const sc = m.size === 'M' ? 1 + 0.06 * mIn + 0.02 * Math.sin(f / 5) : 1;
            return (
              <g key={m.size} opacity={op}>
                <PopcornBox size={m.size} x={m.x} y={COUNTER_TOP - 2 + yOff} scale={sc} glow={m.size === 'M' && f > 8} />
                <PriceTag x={m.x} y={top + yOff} text={m.price} t={1} tilt={m.size === 'M' ? 4 : -5} />
              </g>
            );
          })}
          {[
            {x: 520, y: 900, s: 0.8, d: 14},
            {x: 760, y: 930, s: 0.6, d: 20},
            {x: 560, y: 1010, s: 0.5, d: 26},
            {x: 735, y: 1040, s: 0.7, d: 30},
          ].map((sp, i) => {
            const t = prog(f, sp.d, sp.d + 20, E.out) * (1 - prog(f, sp.d + 30, sp.d + 50, E.in));
            return <Sparkle key={i} x={sp.x} y={sp.y} s={sp.s * t} rot={f * 3 + i * 30} />;
          })}
          {/* +$1 arc between the M and L tags */}
          <path
            d="M 650 745 Q 770 640 880 640"
            fill="none"
            stroke={COLORS.greenLight}
            strokeWidth={9}
            strokeLinecap="round"
            strokeDasharray="420"
            strokeDashoffset={420 * (1 - arrow)}
          />
          <g transform={`translate(770 606) scale(${label})`} opacity={Math.min(1, label * 2)}>
            <rect x={-92} y={-30} width={184} height={60} rx={30} fill={COLORS.greenDark} stroke="#0B0B10" strokeWidth={5} />
            <text textAnchor="middle" dominantBaseline="central" fontFamily={fontFamily} fontWeight={900} fontSize={36} fill="#fff">
              ONLY +$1
            </text>
          </g>
          <Stickman x={110} y={HERO_HIP} pose={pose} expression={expression} look={0.9} />
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={4} />
    </>
  );
};
