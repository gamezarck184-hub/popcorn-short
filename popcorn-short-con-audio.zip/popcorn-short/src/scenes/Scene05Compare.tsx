import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS, GROUND} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {CinemaBg, Counter} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {PopcornBox} from '../components/PopcornBox';
import {Stickman} from '../components/Stickman';
import {fontFamily} from '../fonts';
import {E, prog, springAt} from '../lib/anim';
import {POINT_UP, THINK, blend} from '../lib/pose';
import {DIM} from '../lib/pose';
import {SIZE_COLOR, SceneProps} from './common';

const BASE = 960;
const MAXH = 340;
const BAR_W = 110;
const PRICE = [
  {k: 'S' as const, v: 4, x: 140},
  {k: 'M' as const, v: 7, x: 290},
  {k: 'L' as const, v: 8, x: 440},
];
const AMOUNT = [
  {k: 'S' as const, v: 0.3, x: 630},
  {k: 'M' as const, v: 0.55, x: 780},
  {k: 'L' as const, v: 1, x: 930},
];

const Bar: React.FC<{x: number; h: number; color: string}> = ({x, h, color}) => (
  <g>
    <rect x={x - BAR_W / 2} y={BASE - h} width={BAR_W} height={h} rx={14} fill={color} stroke="#0B0B10" strokeWidth={6} />
    <rect x={x - BAR_W / 2 + 12} y={BASE - h + 10} width={14} height={Math.max(0, h - 24)} rx={7} fill="#fff" opacity={0.3} />
  </g>
);

export const Scene05Compare: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  const panel = springAt(f, 0, 14, 140);
  const heroScale = 1.0;
  const hip = GROUND - DIM.legLen * heroScale;
  const pose = blend(THINK, POINT_UP, prog(f, 10, 30));
  const dash = prog(f, 130, 150, E.out);
  const lab1 = springAt(f, 150, 11, 170);
  const lab2 = springAt(f, 168, 11, 170);
  const mPrice = BASE - (7 / 8) * MAXH;
  const lPrice = BASE - MAXH;
  const mAmt = BASE - 0.55 * MAXH;

  return (
    <>
      <Camera from={{s: 1, fx: 540, fy: 960}} to={{s: 1.035, fx: 540, fy: 990}} duration={duration}>
        <SceneSvg>
          <CinemaBg variant="snack" frame={f} />
          <Counter frame={f} />
          <rect width={1080} height={1920} fill="#0A0618" opacity={0.62} />
          <g transform={`translate(540 740) scale(${panel}) translate(-540 -740)`} opacity={Math.min(1, panel * 2)}>
            <rect x={50} y={440} width={980} height={600} rx={36} fill="rgba(14,12,40,0.92)" stroke="#fff" strokeOpacity={0.25} strokeWidth={4} />
            <line x1={540} y1={470} x2={540} y2={1010} stroke="#fff" strokeOpacity={0.15} strokeWidth={3} strokeDasharray="10 12" />
            <text x={290} y={500} textAnchor="middle" fontFamily={fontFamily} fontWeight={900} fontSize={44} fill="#fff">PRICE</text>
            <text x={780} y={500} textAnchor="middle" fontFamily={fontFamily} fontWeight={900} fontSize={44} fill="#fff">AMOUNT</text>
            <line x1={80} y1={BASE} x2={1000} y2={BASE} stroke="#fff" strokeOpacity={0.5} strokeWidth={5} strokeLinecap="round" />

            {PRICE.map((b, i) => {
              const t = prog(f, 16 + i * 9, 40 + i * 9, E.outBack);
              const h = (b.v / 8) * MAXH * t;
              return (
                <g key={b.k}>
                  <Bar x={b.x} h={h} color={SIZE_COLOR[b.k]} />
                  <text x={b.x} y={BASE - h - 18} textAnchor="middle" fontFamily={fontFamily} fontWeight={900} fontSize={46} fill="#fff" opacity={t > 0.6 ? 1 : 0}>
                    ${b.v}
                  </text>
                </g>
              );
            })}
            {AMOUNT.map((b, i) => {
              const t = prog(f, 70 + i * 12, 100 + i * 12, E.outBack);
              const h = b.v * MAXH * t;
              return <Bar key={b.k} x={b.x} h={h} color={SIZE_COLOR[b.k]} />;
            })}

            {/* mini boxes under the bars */}
            {[...PRICE, ...AMOUNT].map((b, i) => (
              <PopcornBox key={i} size={b.k} x={b.x} y={1022} scale={0.2} heap={0.8} />
            ))}

            {/* M vs L comparison guides */}
            <g opacity={dash}>
              <line x1={400} y1={mPrice} x2={500} y2={mPrice} stroke="#fff" strokeWidth={4} strokeDasharray="8 8" />
              <line x1={400} y1={lPrice} x2={500} y2={lPrice} stroke="#fff" strokeWidth={4} strokeDasharray="8 8" />
              <line x1={745} y1={mAmt} x2={1000} y2={mAmt} stroke="#fff" strokeWidth={4} strokeDasharray="8 8" />
            </g>
            <g transform={`translate(440 ${(mPrice + lPrice) / 2 + 105}) scale(${lab1})`} opacity={Math.min(1, lab1 * 2)}>
              <rect x={-70} y={-28} width={140} height={56} rx={28} fill={COLORS.greenDark} stroke="#0B0B10" strokeWidth={5} />
              <text textAnchor="middle" dominantBaseline="central" fontFamily={fontFamily} fontWeight={900} fontSize={34} fill="#fff">+$1</text>
            </g>
            <g transform={`translate(930 ${(mAmt + lPrice) / 2 + 40}) scale(${lab2})`} opacity={Math.min(1, lab2 * 2)}>
              <rect x={-100} y={-28} width={200} height={56} rx={28} fill={COLORS.greenDark} stroke="#0B0B10" strokeWidth={5} />
              <text textAnchor="middle" dominantBaseline="central" fontFamily={fontFamily} fontWeight={900} fontSize={30} fill="#fff">BIG JUMP</text>
            </g>
            <text x={540} y={1066} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={26} fill="#fff" opacity={0.6} letterSpacing={3}>
              ILLUSTRATIVE EXAMPLE
            </text>
          </g>
          <Stickman x={900} y={hip} scale={heroScale} facing={-1} pose={pose} expression={f < 120 ? 'thinking' : 'smug'} look={0.9} />
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={4} size={78} top={150} />
    </>
  );
};
