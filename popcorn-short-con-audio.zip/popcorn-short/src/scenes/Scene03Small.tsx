import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS, COUNTER_TOP} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {CinemaBg, Counter} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {BOX, PopcornBox} from '../components/PopcornBox';
import {Coin, PriceTag} from '../components/Props';
import {Stickman} from '../components/Stickman';
import {E, prog, springAt} from '../lib/anim';
import {POINT, SHRUG, THINK, blend} from '../lib/pose';
import {HERO_HIP, SceneProps} from './common';
import {MENU} from './Scene02Menu';

export const Scene03Small: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  const dim = 1 - 0.72 * prog(f, 6, 26);
  let pose = blend(POINT, THINK, prog(f, 0, 14));
  pose = blend(pose, SHRUG, prog(f, 84, 104));
  const expression = f < 84 ? 'thinking' : 'smug';
  const bounce = f > 20 ? 1 + 0.03 * Math.sin(f / 5) : 1;
  const coinsT = [0, 1, 2, 3].map((i) => springAt(f, 34 + i * 9, 10, 190));

  return (
    <>
      <Camera from={{s: 1.05, fx: 560, fy: 1010}} to={{s: 1.26, fx: 430, fy: 1060}} duration={duration}>
        <SceneSvg>
          <CinemaBg variant="snack" frame={f} />
          <Counter frame={f} />
          {MENU.map((m) => {
            const isS = m.size === 'S';
            const top = COUNTER_TOP - BOX[m.size].h - BOX[m.size].mound - 120;
            return (
              <g key={m.size} opacity={isS ? 1 : dim}>
                <PopcornBox size={m.size} x={m.x} y={COUNTER_TOP - 2} scale={isS ? bounce : 1} glow={isS && f > 12} />
                <PriceTag x={m.x} y={top} text={m.price} t={1} tilt={m.size === 'M' ? 4 : -5} />
              </g>
            );
          })}
          {coinsT.map((t, i) => (
            <Coin key={i} x={505} y={COUNTER_TOP - 22 - i * 20} r={30} spin={0} opacity={Math.min(1, t * 2)} />
          ))}
          <Stickman x={110} y={HERO_HIP} pose={pose} expression={expression} look={0.9} />
          <g transform={`translate(505 ${COUNTER_TOP - 150}) scale(${coinsT[3]})`} opacity={coinsT[3]}>
            <path d="M 0 -50 L 0 0 M -26 -22 L 0 8 L 26 -22" stroke={COLORS.greenLight} strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" fill="none" transform="translate(0 -20)" />
          </g>
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={4} />
    </>
  );
};
