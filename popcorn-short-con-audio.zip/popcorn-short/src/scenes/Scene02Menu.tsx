import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS, COUNTER_TOP} from '../config';
import {Camera, SceneSvg} from '../components/Camera';
import {CinemaBg, Counter} from '../components/Backgrounds';
import {OnScreenText} from '../components/OnScreenText';
import {BOX, PopcornBox} from '../components/PopcornBox';
import {PriceTag} from '../components/Props';
import {Stickman} from '../components/Stickman';
import {E, prog, springAt} from '../lib/anim';
import {IDLE, POINT, THINK, blend} from '../lib/pose';
import {HERO_HIP, SceneProps} from './common';
import {fontFamily} from '../fonts';

export const MENU = [
  {size: 'S' as const, x: 380, price: '$4', delay: 14},
  {size: 'M' as const, x: 635, price: '$7', delay: 36},
  {size: 'L' as const, x: 900, price: '$8', delay: 58},
];

export const Scene02Menu: React.FC<SceneProps> = ({title, duration}) => {
  const f = useCurrentFrame();
  const sweep = Math.sin(f / 16) * 6;
  let pose = blend(IDLE, THINK, prog(f, 0, 20));
  pose = blend(pose, {...POINT, armFront: [78 + sweep, 6]}, prog(f, 30, 50));
  const expression = f < 40 ? 'thinking' : 'happy';
  const chip = springAt(f, 90, 14, 150);

  return (
    <>
      <Camera from={{s: 1, fx: 540, fy: 1000}} to={{s: 1.05, fx: 560, fy: 1010}} duration={duration}>
        <SceneSvg>
          <CinemaBg variant="snack" frame={f} />
          <Counter frame={f} />
          {MENU.map((m) => {
            const drop = prog(f, m.delay, m.delay + 20, E.outBounce);
            const y = COUNTER_TOP - 2 - (1 - drop) * 620;
            const tagT = springAt(f, m.delay + 22, 11, 170);
            const top = COUNTER_TOP - BOX[m.size].h - BOX[m.size].mound - 120;
            return (
              <g key={m.size}>
                <PopcornBox size={m.size} x={m.x} y={y} opacity={drop > 0 ? 1 : 0} />
                <PriceTag x={m.x} y={top} text={m.price} t={tagT} tilt={m.size === 'M' ? 4 : -5} />
              </g>
            );
          })}
          <Stickman x={110} y={HERO_HIP} pose={pose} expression={expression} look={0.9} />
          <g transform={`translate(540 ${480}) scale(${chip})`} opacity={Math.min(1, chip * 2)}>
            <rect x={-150} y={-30} width={300} height={60} rx={30} fill="rgba(10,6,24,0.75)" stroke={COLORS.gold} strokeWidth={3} />
            <text textAnchor="middle" dominantBaseline="central" fontFamily={fontFamily} fontWeight={800} fontSize={28} fill={COLORS.gold} letterSpacing={2}>
              EXAMPLE PRICES
            </text>
          </g>
        </SceneSvg>
      </Camera>
      <OnScreenText text={title} delay={4} />
    </>
  );
};
