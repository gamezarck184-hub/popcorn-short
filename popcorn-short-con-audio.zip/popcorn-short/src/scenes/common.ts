import {COLORS, GROUND} from '../config';
import {DIM} from '../lib/pose';

export type SceneProps = {title: string; duration: number};

/** Standard hero size + hip height so feet land on the floor. */
export const HERO_SCALE = 1.25;
export const HERO_HIP = GROUND - DIM.legLen * HERO_SCALE;

export const SIZE_COLOR = {S: COLORS.blue, M: COLORS.yellow, L: COLORS.coral};
