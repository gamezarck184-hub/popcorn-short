export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const DURATION_SEC = 52;
export const TOTAL_FRAMES = DURATION_SEC * FPS; // 1560

/** Frames of crossfade/wipe between scenes (the next scene starts this much early). */
export const OVERLAP = 14;

/** Y of the floor where the stickman's feet rest. */
export const GROUND = 1400;
/** Y of the concession counter top surface. */
export const COUNTER_TOP = 1215;

/**
 * Put your narration file in /public (for example public/narration.mp3),
 * then set HAS_NARRATION = true and it will be mixed in automatically.
 */
export const HAS_NARRATION = true;
export const NARRATION_FILE = 'narration.mp3';

export const COLORS = {
  ink: '#0B0B10',
  white: '#FFFFFF',
  green: '#2FB457',
  greenDark: '#1C7C3A',
  greenLight: '#6BE08F',
  red: '#E23B4A',
  redDark: '#A82230',
  cream: '#FFF3D4',
  butter: '#FFD35A',
  gold: '#FFC83D',
  navy: '#1B2A57',
  blue: '#5BC0EB',
  coral: '#FF5D73',
  yellow: '#F9C846',
};
