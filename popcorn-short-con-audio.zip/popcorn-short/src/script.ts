import {FPS} from './config';

export const sec = (s: number) => Math.round(s * FPS);

/** from / to are in SECONDS (global timeline). Edit these to match your own narration. */
export type Line = {from: number; to: number; text: string};
export type SceneDef = {
  id: string;
  start: number; // seconds
  end: number; // seconds
  /** On-screen title (ENGLISH). **word** = highlighted. */
  title: string;
  /** Subtitles (SPANISH). */
  lines: Line[];
};

export const SCENES: SceneDef[] = [
  {
    id: '01-lobby',
    start: 0,
    end: 5,
    title: 'THE MOVIE **POPCORN** TRICK',
    lines: [
      {from: 0.3, to: 2.6, text: 'Entras al cine y, de pronto,'},
      {from: 2.6, to: 5.0, text: 'una caja de palomitas te llama la atención.'},
    ],
  },
  {
    id: '02-menu',
    start: 5,
    end: 10,
    title: '**3 SIZES**, 3 PRICES',
    lines: [
      {from: 5.2, to: 7.6, text: 'Te acercas al mostrador y ves el menú:'},
      {from: 7.6, to: 10.0, text: 'tres tamaños, cada uno con su precio.'},
    ],
  },
  {
    id: '03-small',
    start: 10,
    end: 15,
    title: 'SMALL = THE **CHEAP** OPTION',
    lines: [
      {from: 10.2, to: 12.6, text: 'El pequeño es la opción económica:'},
      {from: 12.6, to: 15.0, text: 'poca cantidad, pero precio bajo.'},
    ],
  },
  {
    id: '04-medium',
    start: 15,
    end: 20,
    title: 'MEET THE **MEDIUM**',
    lines: [
      {from: 15.2, to: 17.6, text: 'Ahora mira el mediano: en este ejemplo,'},
      {from: 17.6, to: 20.0, text: 'cuesta casi lo mismo que el grande.'},
    ],
  },
  {
    id: '05-compare',
    start: 20,
    end: 27,
    title: 'PRICE **VS.** AMOUNT',
    lines: [
      {from: 20.2, to: 23.0, text: 'Compara precio y cantidad: el mediano'},
      {from: 23.0, to: 25.2, text: 'cuesta solo un poco menos que el grande,'},
      {from: 25.2, to: 27.0, text: 'pero trae bastante menos palomitas.'},
    ],
  },
  {
    id: '06-deal',
    start: 27,
    end: 33,
    title: 'THE LARGE LOOKS LIKE A **DEAL**',
    lines: [
      {from: 27.2, to: 30.0, text: 'Entonces el grande parece una ganga:'},
      {from: 30.0, to: 33.0, text: 'por un poco más, te llevas mucho más.'},
    ],
  },
  {
    id: '07-mind',
    start: 33,
    end: 40,
    title: 'THE **DECOY** EFFECT',
    lines: [
      {from: 33.2, to: 36.0, text: 'Tu cerebro rara vez evalúa un precio solo.'},
      {from: 36.0, to: 38.2, text: 'Lo compara con lo que tiene al lado,'},
      {from: 38.2, to: 40.0, text: 'y el mediano funciona como referencia.'},
    ],
  },
  {
    id: '08-choice',
    start: 40,
    end: 45,
    title: 'THE **LARGE** WINS',
    lines: [
      {from: 40.2, to: 42.6, text: 'Así que pides el grande,'},
      {from: 42.6, to: 45.0, text: 'convencido de que hiciste un gran trato.'},
    ],
  },
  {
    id: '09-cinema',
    start: 45,
    end: 49,
    title: 'MORE SALES FOR THE **CINEMA**',
    lines: [
      {from: 45.2, to: 47.0, text: 'Y el cine gana: vende el tamaño'},
      {from: 47.0, to: 49.0, text: 'más grande, y tú sales contento.'},
    ],
  },
  {
    id: '10-closing',
    start: 49,
    end: 52,
    title: 'COMPARE BEFORE YOU **CHOOSE**',
    lines: [
      {from: 49.2, to: 50.6, text: 'La próxima vez,'},
      {from: 50.6, to: 52.0, text: 'compara antes de elegir.'},
    ],
  },
];
