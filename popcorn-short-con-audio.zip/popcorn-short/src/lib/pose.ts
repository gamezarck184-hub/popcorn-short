import {lerp} from './anim';

export type Pair = [number, number];
/**
 * Angles are in degrees measured from "straight down", positive = swings FORWARD
 * (toward the direction the character faces).
 * Arms: [upper, bend]  → forearm angle = upper + bend (elbow flexes up/forward).
 * Legs: [upper, bend]  → shin angle   = upper - bend (knee flexes backward).
 * Segment lengths never change, so the figure can't stretch or deform.
 */
export type Pose = {
  lean: number;
  headTilt: number;
  bob: number;
  armBack: Pair;
  armFront: Pair;
  legBack: Pair;
  legFront: Pair;
};

export const DIM = {
  torso: 118,
  headR: 44,
  neck: 10,
  upperArm: 60,
  foreArm: 56,
  thigh: 78,
  shin: 76,
  legLen: 154,
  shoulderT: 0.9,
};

export const IDLE: Pose = {
  lean: 2, headTilt: 0, bob: 0,
  armBack: [10, 12], armFront: [-8, 14],
  legBack: [-5, 3], legFront: [5, 3],
};
export const POINT: Pose = {
  lean: 8, headTilt: 0, bob: 0,
  armBack: [6, 14], armFront: [84, 4],
  legBack: [-6, 3], legFront: [7, 3],
};
export const POINT_UP: Pose = {
  lean: 4, headTilt: -4, bob: 0,
  armBack: [8, 14], armFront: [140, 6],
  legBack: [-5, 3], legFront: [5, 3],
};
export const SURPRISED: Pose = {
  lean: -7, headTilt: -5, bob: 0,
  armBack: [28, 45], armFront: [34, 52],
  legBack: [-9, 6], legFront: [8, 4],
};
export const THINK: Pose = {
  lean: 1, headTilt: 6, bob: 0,
  armBack: [28, 100], armFront: [50, 100],
  legBack: [-5, 3], legFront: [5, 3],
};
export const HOLD: Pose = {
  lean: 4, headTilt: 0, bob: 0,
  armBack: [60, 66], armFront: [56, 72],
  legBack: [-5, 3], legFront: [5, 3],
};
export const SHRUG: Pose = {
  lean: 0, headTilt: 9, bob: 0,
  armBack: [34, 78], armFront: [42, 72],
  legBack: [-5, 3], legFront: [5, 3],
};
export const CELEBRATE: Pose = {
  lean: -2, headTilt: -4, bob: 0,
  armBack: [152, 18], armFront: [162, 12],
  legBack: [-12, 10], legFront: [12, 10],
};
export const TOSS: Pose = {
  lean: 6, headTilt: 0, bob: 0,
  armBack: [-10, 14], armFront: [96, 26],
  legBack: [-6, 3], legFront: [6, 3],
};
export const SIT: Pose = {
  lean: 0, headTilt: 0, bob: 0,
  armBack: [10, 40], armFront: [40, 40],
  legBack: [84, 88], legFront: [90, 92],
};

const mixPair = (a: Pair, b: Pair, t: number): Pair => [lerp(a[0], b[0], t), lerp(a[1], b[1], t)];

export const blend = (a: Pose, b: Pose, t: number): Pose => ({
  lean: lerp(a.lean, b.lean, t),
  headTilt: lerp(a.headTilt, b.headTilt, t),
  bob: lerp(a.bob, b.bob, t),
  armBack: mixPair(a.armBack, b.armBack, t),
  armFront: mixPair(a.armFront, b.armFront, t),
  legBack: mixPair(a.legBack, b.legBack, t),
  legFront: mixPair(a.legFront, b.legFront, t),
});

/** Walk cycle. `cycles` = number of full strides (2 steps) taken so far. */
export const walkPose = (cycles: number): Pose => {
  const p = cycles * Math.PI * 2;
  const s = Math.sin(p);
  const c = Math.cos(p);
  return {
    lean: 7,
    headTilt: 0,
    bob: Math.abs(s) * 13,
    legFront: [s * 30, Math.max(0, c) * 52 + 6],
    legBack: [-s * 30, Math.max(0, -c) * 52 + 6],
    armFront: [-s * 34, 20 + Math.max(0, -c) * 12],
    armBack: [s * 34, 20 + Math.max(0, c) * 12],
  };
};

type P = {x: number; y: number};
const rad = (d: number) => (d * Math.PI) / 180;

const limb = (ox: number, oy: number, a: number, bend: number, l1: number, l2: number, sign: 1 | -1) => {
  const a1 = rad(a);
  const a2 = rad(a + sign * bend);
  const mid: P = {x: ox + Math.sin(a1) * l1, y: oy + Math.cos(a1) * l1};
  const end: P = {x: mid.x + Math.sin(a2) * l2, y: mid.y + Math.cos(a2) * l2};
  return {mid, end};
};

/** Forward kinematics: every joint, relative to the hip (unscaled, facing right). */
export const getRig = (pose: Pose) => {
  const lean = rad(pose.lean);
  const neck: P = {x: Math.sin(lean) * DIM.torso, y: -Math.cos(lean) * DIM.torso};
  const shoulder: P = {
    x: Math.sin(lean) * DIM.torso * DIM.shoulderT,
    y: -Math.cos(lean) * DIM.torso * DIM.shoulderT,
  };
  const ha = rad(pose.lean + pose.headTilt);
  const head: P = {
    x: neck.x + Math.sin(ha) * (DIM.headR + DIM.neck),
    y: neck.y - Math.cos(ha) * (DIM.headR + DIM.neck),
  };
  const armFront = limb(shoulder.x, shoulder.y, pose.armFront[0], pose.armFront[1], DIM.upperArm, DIM.foreArm, 1);
  const armBack = limb(shoulder.x, shoulder.y, pose.armBack[0], pose.armBack[1], DIM.upperArm, DIM.foreArm, 1);
  const legFront = limb(7, 0, pose.legFront[0], pose.legFront[1], DIM.thigh, DIM.shin, -1);
  const legBack = limb(-7, 0, pose.legBack[0], pose.legBack[1], DIM.thigh, DIM.shin, -1);
  return {neck, shoulder, head, armFront, armBack, legFront, legBack};
};

export const toWorld = (
  p: P,
  o: {x: number; y: number; scale: number; facing: 1 | -1; bob?: number},
): P => ({
  x: o.x + p.x * o.scale * o.facing,
  y: o.y + ((o.bob ?? 0) + p.y) * o.scale,
});
