import {Easing, interpolate, spring} from 'remotion';
import {FPS} from '../config';

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export type Ease = (t: number) => number;
export const E = {
  linear: (t: number) => t,
  out: Easing.out(Easing.cubic),
  in: Easing.in(Easing.cubic),
  inOut: Easing.inOut(Easing.cubic),
  outBack: Easing.out(Easing.back(1.6)),
  outBounce: Easing.out(Easing.bounce),
};

/** 0 → 1 progress between two frames. */
export const prog = (frame: number, from: number, to: number, ease: Ease = E.inOut) =>
  interpolate(frame, [from, to], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: ease,
  });

/** Spring that starts at `delay`; overshoots a little (pop-in). */
export const springAt = (frame: number, delay = 0, damping = 12, stiffness = 160) =>
  spring({
    frame: Math.max(0, frame - delay),
    fps: FPS,
    config: {damping, stiffness, mass: 0.7},
  });

export const seeded = (seed: number) => {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
};
