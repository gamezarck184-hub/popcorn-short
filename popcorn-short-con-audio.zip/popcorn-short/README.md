# Popcorn Short (Remotion)

YouTube Short 1080×1920 · 30 fps · 52 s · stickman animated documentary.
On-screen text: English. Subtitles: Spanish.

## Run
```
npm install
npm run dev        # Remotion Studio (preview)
npm run render     # → out/popcorn-short.mp4
```
Needs Node 18+. First render downloads Remotion's headless Chrome.

## Use your own narration
1. Put your audio in `public/narration.mp3`.
2. In `src/config.ts` set `HAS_NARRATION = true`.
3. Adjust the Spanish text / timings (in seconds) in `src/script.ts`
   so subtitles match your narration. Scene start/end times live there too.

## Structure
- `src/script.ts` – scenes, timings, English titles, Spanish subtitles
- `src/lib/pose.ts` – stickman rig (fixed bone lengths → no deformation), poses, walk cycle
- `src/components/` – Stickman, PopcornBox, Props (coins, tags, bubbles…), Backgrounds, Camera, Subtitles, transitions
- `src/scenes/` – one file per scene (01 lobby … 10 closing)

Prices ($4 / $7 / $8) and bar heights are labelled as illustrative examples; no real data or brands.
