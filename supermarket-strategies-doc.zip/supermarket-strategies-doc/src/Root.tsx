import React from 'react';
import {Composition} from 'remotion';
import {SupermarketStrategiesDoc} from './SupermarketStrategiesDoc';
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from './config';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="SupermarketStrategiesDoc"
      component={SupermarketStrategiesDoc}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};
