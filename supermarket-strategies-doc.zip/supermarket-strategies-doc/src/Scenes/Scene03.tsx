import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SceneConfig} from '../script';
import {Character} from '../components/Character';
import {ShoppingCart} from '../components/ShoppingCart';
import {Shelf} from '../components/Shelf';
import {PriceTag} from '../components/PriceTag';

export const Scene03: React.FC<{scene: SceneConfig}> = () => {
  const frame = useCurrentFrame();

  const walkX = interpolate(frame, [0, 180], [340, 1080], {
    extrapolateRight: 'clamp',
  });
  const cartFill = interpolate(frame, [20, 220], [0.15, 0.95], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const camZoom = 1 + Math.sin(frame * 0.025) * 0.03;
  const boxTilt = Math.sin(frame * 0.14) * 10;

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDeep, overflow: 'hidden'}}>
      <svg
        width="1920"
        height="1080"
        viewBox="0 0 1920 1080"
        style={{
          transform: `scale(${camZoom})`,
          transformOrigin: '960px 540px',
        }}
      >
        <rect width="1920" height="1080" fill="#111B2E" />
        <rect x={0} y={FLOOR_Y} width={1920} height={1080 - FLOOR_Y} fill="#1E293B" />
        <line x1={0} y1={FLOOR_Y} x2={1920} y2={FLOOR_Y} stroke="#475569" strokeWidth={4} />

        <Shelf
          x={520}
          y={FLOOR_Y - 12}
          width={680}
          height={360}
          highlightBand={'eye'}
          showPromoTag={false}
        />
        <Shelf
          x={1380}
          y={FLOOR_Y - 12}
          width={680}
          height={360}
          showPromoTag={true}
        />

        <g transform={`translate(1260, 470) rotate(${boxTilt})`}>
          <rect
            x={-44}
            y={-44}
            width={88}
            height={88}
            rx={10}
            fill={PALETTE.promoAmber}
            stroke="#090D16"
            strokeWidth={3.5}
          />
          <text
            x={0}
            y={8}
            textAnchor="middle"
            fill="#090D16"
            fontFamily={fontFamily}
            fontWeight="900"
            fontSize="18"
          >
            EXTRA
          </text>
        </g>

        {false && (
          <PriceTag
            x={1560}
            y={340}
            label="ENVASE GRANDE"
            priceText="G. 9.000"
            accent="highlight"
          />
        )}

        <Character
          x={walkX}
          y={FLOOR_Y}
          scale={1.08}
          pose={'pointing'}
          walkSpeed={0.2}
          lookX={0.75}
          armAngleDeg={-38 + Math.sin(frame * 0.1) * 7}
        />

        <ShoppingCart
          x={walkX + 125}
          y={FLOOR_Y}
          scale={1.08}
          fillLevel={cartFill}
          wheelRoll={frame * 6}
        />

        <g transform="translate(960, 120)">
          <rect
            x={-460}
            y={-42}
            width={920}
            height={76}
            rx={16}
            fill="rgba(9, 13, 22, 0.78)"
            stroke="rgba(34, 197, 94, 0.45)"
            strokeWidth={2.5}
          />
          <text
            x={0}
            y={6}
            textAnchor="middle"
            fill={PALETTE.white}
            fontFamily={fontFamily}
            fontWeight="800"
            fontSize="30"
          >
            La ubicación influye en la atención
          </text>
        </g>
      </svg>
    </AbsoluteFill>
  );
};
