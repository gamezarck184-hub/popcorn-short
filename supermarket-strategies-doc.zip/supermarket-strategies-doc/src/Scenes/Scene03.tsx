import React from 'react';
import {Sequence, staticFile} from 'remotion';
import {sec} from '../config';
import {TIMELINE} from '../data/timeline';
import {SequenceRenderer} from '../components/SequenceRenderer';

export const Scene03: React.FC = () => {
  const items = TIMELINE.filter((s) => s.block === 3);
  return (
    <>
      {items.map((seq) => {
        const fromF = sec(seq.startSec);
        const durF = Math.max(1, sec(seq.endSec) - fromF);
        return (
          <Sequence key={seq.id} from={fromF} durationInFrames={durF}>
            <SequenceRenderer seq={seq} />
          </Sequence>
        );
      })}
    </>
  );
};
