export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Duraciones reales de las tres narraciones en segundos
export const NARRATION_1_SEC = 85.289796; // 0.000s -> 85.290s
export const NARRATION_2_SEC = 91.376327; // 85.290s -> 176.666s
export const NARRATION_3_SEC = 95.216327; // 176.666s -> 271.882s

export const NARRATION_2_START = NARRATION_1_SEC;
export const NARRATION_3_START = NARRATION_1_SEC + NARRATION_2_SEC;

export const DURATION_SEC = 271.882;
export const TOTAL_FRAMES = Math.round(DURATION_SEC * FPS); // 8156 frames

export const sec = (s: number): number => Math.round(s * FPS);

export const FONT_FAMILY = 'system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
export const FLOOR_Y = 810;

export const PALETTE = {
  bgDeep: '#0B1320',
  wallSlate: '#111C30',
  floorMain: '#1E293B',
  floorLine: '#475569',
  shelfBody: '#273449',
  shelfEdge: '#64748B',
  sweaterGreen: '#1E7A44',
  sweaterGreenDark: '#14532D',
  accentGreen: '#22C55E',
  white: '#F8FAFC',
  ink: '#090D16',
  amber: '#F59E0B',
  red: '#EF4444',
  sky: '#38BDF8',
};
