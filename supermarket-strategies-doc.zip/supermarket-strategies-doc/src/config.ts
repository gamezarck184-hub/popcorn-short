export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Duraciones reales medidas de los tres archivos de narración (44100 Hz):
// narration1.mp3: 85.2898s (0.000s - 85.290s)
// narration2.mp3: 91.3763s (85.290s - 176.666s)
// narration3.mp3: 95.2163s (176.666s - 271.882s)
export const NARRATION_1_SEC = 85.2898;
export const NARRATION_2_SEC = 91.3763;
export const NARRATION_3_SEC = 95.2163;
export const NARRATION_2_START = NARRATION_1_SEC;
export const NARRATION_3_START = NARRATION_1_SEC + NARRATION_2_SEC;
export const TOTAL_AUDIO_SEC = NARRATION_3_START + NARRATION_3_SEC; // 271.8824s

export const DURATION_SEC = 273.2;
export const TOTAL_FRAMES = Math.round(DURATION_SEC * FPS); // 8196 frames

export const OVERLAP = 12;
export const FLOOR_Y = 795;

export const PALETTE = {
  bgDeep: '#0B1320',
  wallCream: '#EEF2F6',
  wallSlate: '#DCE4EE',
  floorTile: '#CFD8E3',
  floorGrout: '#B0BEC5',
  aisleDark: '#1E293B',
  shelfWood: '#334155',
  shelfTrim: '#64748B',
  sweaterGreen: '#1E7A44',
  sweaterGreenDark: '#13522D',
  accentGreen: '#22C55E',
  white: '#F8FAFC',
  ink: '#090D16',
  promoAmber: '#F59E0B',
  promoRed: '#EF4444',
  accentBlue: '#0284C7',
};
