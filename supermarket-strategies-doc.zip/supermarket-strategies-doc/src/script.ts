import {
  FPS,
  NARRATION_1_SEC,
  NARRATION_2_START,
  NARRATION_3_START,
  TOTAL_AUDIO_SEC,
} from './config';

export const sec = (s: number): number => Math.round(s * FPS);

export type CaptionItem = {
  from: number;
  to: number;
  text: string;
  highlights?: string[];
};

export type SceneConfig = {
  id: string;
  title: string;
  featuredText: string;
  startSec: number;
  endSec: number;
  captions: CaptionItem[];
};

export const SCENES: SceneConfig[] = [
  {
    id: 'scene-01',
    title: 'El verdadero motivo de tu compra',
    featuredText: '¿Por qué terminamos comprando más?',
    startSec: 0.0,
    endSec: 32.0,
    captions: [
      {
        from: 0.2,
        to: 5.5,
        text: '¿Alguna vez entraste a un supermercado\npor leche y pan y saliste con mucho más?',
        highlights: ['leche', 'pan'],
      },
      {
        from: 5.6,
        to: 12.5,
        text: 'No es casualidad: los supermercados estudian\ncómo nos movemos y qué miramos.',
        highlights: ['estudian', 'movemos'],
      },
      {
        from: 12.6,
        to: 20.5,
        text: 'Cada detalle influye en tus decisiones,\nsin que te des cuenta.',
        highlights: ['decisiones,', 'cuenta.'],
      },
      {
        from: 20.6,
        to: 31.8,
        text: 'Hoy recorremos un supermercado para ver\npor qué gastamos más de lo planeado.',
        highlights: ['gastamos', 'planeado.'],
      },
    ],
  },
  {
    id: 'scene-02',
    title: 'El recorrido está pensado',
    featuredText: 'Más recorrido = más oportunidades de exposición',
    startSec: 32.0,
    endSec: NARRATION_1_SEC,
    captions: [
      {
        from: 32.2,
        to: 44.0,
        text: 'Productos básicos como leche, huevos y pan\nsuelen estar lejos de la entrada.',
        highlights: ['básicos', 'lejos'],
      },
      {
        from: 44.1,
        to: 58.0,
        text: 'A mayor recorrido, más oportunidades de ver\nproductos que no pensabas comprar.',
        highlights: ['recorrido,', 'oportunidades'],
      },
      {
        from: 58.1,
        to: 72.0,
        text: 'Mientras avanzás, pasás por ofertas,\nsnacks, bebidas y promociones.',
        highlights: ['ofertas,', 'snacks,', 'bebidas'],
      },
      {
        from: 72.1,
        to: 85.0,
        text: 'El diseño del recorrido busca darte\nmás ocasiones de sumar al carrito.',
        highlights: ['diseño', 'carrito.'],
      },
    ],
  },
  {
    id: 'scene-03',
    title: 'Los productos que están a la altura de tus ojos',
    featuredText: 'La ubicación influye en la atención',
    startSec: NARRATION_2_START,
    endSec: 116.5,
    captions: [
      {
        from: NARRATION_2_START + 0.3,
        to: 97.5,
        text: 'La ubicación en las estanterías\nafecta qué productos notás primero.',
        highlights: ['ubicación', 'notás'],
      },
      {
        from: 97.6,
        to: 107.5,
        text: 'Lo que está a la altura de tus ojos\nrecibe mayor visibilidad inicial.',
        highlights: ['altura', 'ojos', 'visibilidad'],
      },
      {
        from: 107.6,
        to: 116.4,
        text: 'Las marcas buscan mejores posiciones\ny las opciones más económicas suelen quedar abajo.',
        highlights: ['posiciones', 'económicas'],
      },
    ],
  },
  {
    id: 'scene-04',
    title: 'Las promociones que aparecen en medio del camino',
    featuredText: 'Volver a captar tu atención',
    startSec: 116.5,
    endSec: 145.5,
    captions: [
      {
        from: 116.6,
        to: 129.0,
        text: 'Las exhibiciones en medio del pasillo\nbuscan captar tu atención de nuevo.',
        highlights: ['exhibiciones', 'atención'],
      },
      {
        from: 129.1,
        to: 145.4,
        text: 'Aparecen fuera de su góndola habitual\npara generar compras no previstas.',
        highlights: ['compras', 'previstas.'],
      },
    ],
  },
  {
    id: 'scene-05',
    title: 'La última tentación: la caja',
    featuredText: 'Compras impulsivas',
    startSec: 145.5,
    endSec: NARRATION_3_START,
    captions: [
      {
        from: 145.6,
        to: 159.5,
        text: 'En la fila de cajas encontrás dulces,\nchicles y bebidas fáciles de tomar.',
        highlights: ['cajas', 'fáciles'],
      },
      {
        from: 159.6,
        to: NARRATION_3_START - 0.2,
        text: 'La espera y la cercanía favorecen\ncompras pequeñas de impulso.',
        highlights: ['espera', 'impulso.'],
      },
    ],
  },
  {
    id: 'scene-06',
    title: 'Los precios que parecen mejores de lo que son',
    featuredText: 'Comparar también influye en tu elección',
    startSec: NARRATION_3_START,
    endSec: 204.5,
    captions: [
      {
        from: NARRATION_3_START + 0.3,
        to: 189.0,
        text: 'Comparar precios o tamaños puede llevarte\na elegir un envase más caro de lo previsto.',
        highlights: ['Comparar', 'tamaños'],
      },
      {
        from: 189.1,
        to: 204.4,
        text: 'Antes de sumar una oferta o unidad extra,\npreguntate si realmente la necesitabas.',
        highlights: ['oferta', 'necesitabas.'],
      },
    ],
  },
  {
    id: 'scene-07',
    title: 'El ambiente también influye',
    featuredText: 'La experiencia también influye',
    startSec: 204.5,
    endSec: 229.5,
    captions: [
      {
        from: 204.6,
        to: 217.5,
        text: 'Iluminación, música, temperatura y aromas\nhacen más agradable el recorrido.',
        highlights: ['Iluminación,', 'música,', 'aromas'],
      },
      {
        from: 217.6,
        to: 229.4,
        text: 'Si te quedás más tiempo y con calma,\nsurgen más oportunidades de compra.',
        highlights: ['tiempo', 'oportunidades'],
      },
    ],
  },
  {
    id: 'scene-08',
    title: 'El carrito y las compras que no estaban en la lista',
    featuredText: 'Lo planeado vs. lo comprado',
    startSec: 229.5,
    endSec: 245.5,
    captions: [
      {
        from: 229.6,
        to: 238.0,
        text: 'Sin una lista clara, los productos extras\nse acumulan casi sin notarlo.',
        highlights: ['lista', 'extras'],
      },
      {
        from: 238.1,
        to: 245.4,
        text: 'Comparar lo planeado con lo comprado\nmuestra la diferencia real.',
        highlights: ['planeado', 'comprado'],
      },
    ],
  },
  {
    id: 'scene-09',
    title: 'Cómo evitar caer en estas estrategias',
    featuredText: 'Comprá con intención, no por impulso',
    startSec: 245.5,
    endSec: TOTAL_AUDIO_SEC + 1.3,
    captions: [
      {
        from: 245.6,
        to: 257.0,
        text: 'Llevá una lista, evitá comprar con hambre\ny compará el precio por cantidad.',
        highlights: ['lista,', 'cantidad.'],
      },
      {
        from: 257.1,
        to: 265.5,
        text: 'Revisá tu carrito antes de pagar\ny recordá que una oferta no siempre es ahorro.',
        highlights: ['Revisá', 'carrito', 'ahorro.'],
      },
      {
        from: 265.6,
        to: 272.2,
        text: 'Alguien pensó tu recorrido: elegí\ncon intención, no por impulso.',
        highlights: ['intención,', 'impulso.'],
      },
    ],
  },
];
