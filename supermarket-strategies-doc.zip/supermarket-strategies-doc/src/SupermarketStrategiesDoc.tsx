import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {
  DURATION_SEC,
  NARRATION_1_SEC,
  NARRATION_2_SEC,
  NARRATION_2_START,
  NARRATION_3_SEC,
  NARRATION_3_START,
  PALETTE,
  sec,
} from './config';
import {TIMELINE} from './data/timeline';
import {SequenceRenderer} from './components/SequenceRenderer';
import {Captions} from './components/Captions';

export const SupermarketStrategiesDoc: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDeep}}>
      {/* 1. Tres pistas de narración en orden continuo exacto sin cortes ni silencios */}
      <Sequence from={0} durationInFrames={sec(NARRATION_1_SEC) + 1}>
        <Audio src={staticFile('audio/narration1.mp3')} volume={1} />
      </Sequence>
      <Sequence from={sec(NARRATION_2_START)} durationInFrames={sec(NARRATION_2_SEC) + 1}>
        <Audio src={staticFile('audio/narration2.mp3')} volume={1} />
      </Sequence>
      <Sequence from={sec(NARRATION_3_START)} durationInFrames={sec(NARRATION_3_SEC) + 1}>
        <Audio src={staticFile('audio/narration3.mp3')} volume={1} />
      </Sequence>

      {/* 2. Música instrumental continua a bajo volumen durante todo el documental */}
      <Sequence from={0} durationInFrames={sec(DURATION_SEC)}>
        <Audio src={staticFile('audio/music.wav')} volume={0.28} />
      </Sequence>

      {/* 3. 38 secuencias visuales sincronizadas frase por frase con la voz */}
      {TIMELINE.map((seq) => {
        const fromF = sec(seq.startSec);
        const toF = sec(seq.endSec);
        const durF = Math.max(1, toF - fromF);
        return (
          <Sequence key={seq.id} from={fromF} durationInFrames={durF} name={seq.id}>
            <SequenceRenderer seq={seq} />
          </Sequence>
        );
      })}

      {/* 4. Efectos de sonido (SFX) suaves sincronizados con transiciones y acciones */}
      {TIMELINE.map((seq, idx) => {
        const startF = sec(seq.startSec);
        const midF = startF + Math.max(4, Math.round((sec(seq.endSec) - startF) * 0.45));
        const isChime =
          seq.mode === 'eye_level_shelf_focus' ||
          seq.mode === 'middle_aisle_promo_island' ||
          seq.mode === 'checkout_zone_intro' ||
          seq.mode === 'charm_pricing_9999_vs_10000' ||
          seq.mode === 'offer_is_not_always_saving';
        const isPop =
          seq.mode === 'list_milk_bread_vs_full_bag' ||
          seq.mode === 'walking_past_offers_snacks' ||
          seq.mode === 'checkout_candies_gum_drinks' ||
          seq.mode === 'bored_waiting_impulse_grab' ||
          seq.mode === 'choosing_larger_size';

        return (
          <React.Fragment key={`sfx-${seq.id}`}>
            {idx > 0 && (
              <Sequence from={startF} durationInFrames={10}>
                <Audio src={staticFile('audio/sfx/whoosh.wav')} volume={0.18} />
              </Sequence>
            )}
            {isChime && (
              <Sequence from={startF + 2} durationInFrames={15}>
                <Audio src={staticFile('audio/sfx/chime.wav')} volume={0.22} />
              </Sequence>
            )}
            {isPop && (
              <Sequence from={midF} durationInFrames={8}>
                <Audio src={staticFile('audio/sfx/pop.wav')} volume={0.25} />
              </Sequence>
            )}
          </React.Fragment>
        );
      })}

      {/* 5. Subtítulos continuos en español */}
      <Captions />
    </AbsoluteFill>
  );
};
