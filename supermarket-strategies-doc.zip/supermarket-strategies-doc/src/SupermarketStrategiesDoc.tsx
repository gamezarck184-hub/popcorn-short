import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {
  NARRATION_1_SEC,
  NARRATION_2_START,
  NARRATION_3_START,
  OVERLAP,
  PALETTE,
} from './config';
import {SCENES, sec} from './script';
import {Captions} from './components/Captions';
import {Scene01} from './Scenes/Scene01';
import {Scene02} from './Scenes/Scene02';
import {Scene03} from './Scenes/Scene03';
import {Scene04} from './Scenes/Scene04';
import {Scene05} from './Scenes/Scene05';
import {Scene06} from './Scenes/Scene06';
import {Scene07} from './Scenes/Scene07';
import {Scene08} from './Scenes/Scene08';
import {Scene09} from './Scenes/Scene09';

const SCENE_LIST = [
  Scene01,
  Scene02,
  Scene03,
  Scene04,
  Scene05,
  Scene06,
  Scene07,
  Scene08,
  Scene09,
];

export const SupermarketStrategiesDoc: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDeep}}>
      {/* Tres archivos de narración en orden continuo exacto, sin acelerar ni recortar */}
      <Sequence from={0} durationInFrames={sec(NARRATION_1_SEC) + 2}>
        <Audio src={staticFile('audio/narration1.mp3')} volume={1} />
      </Sequence>
      <Sequence from={sec(NARRATION_2_START)} durationInFrames={sec(91.3763) + 2}>
        <Audio src={staticFile('audio/narration2.mp3')} volume={1} />
      </Sequence>
      <Sequence from={sec(NARRATION_3_START)} durationInFrames={sec(95.2163) + 2}>
        <Audio src={staticFile('audio/narration3.mp3')} volume={1} />
      </Sequence>

      {/* Música instrumental de fondo a bajo volumen */}
      <Audio src={staticFile('audio/music.wav')} volume={0.32} loop />

      {/* Nueve escenas sincronizadas con la narración */}
      {SCENES.map((scene, idx) => {
        const SceneComp = SCENE_LIST[idx];
        const fromFrame = Math.max(0, sec(scene.startSec) - (idx > 0 ? OVERLAP : 0));
        const endFrame = sec(scene.endSec);
        const durationInFrames = Math.max(1, endFrame - fromFrame);

        return (
          <Sequence
            key={scene.id}
            from={fromFrame}
            durationInFrames={durationInFrames}
            name={scene.id}
          >
            <SceneComp scene={scene} />
          </Sequence>
        );
      })}

      {/* Subtítulos en español continuos entre los tres audios */}
      <Captions />
    </AbsoluteFill>
  );
};
