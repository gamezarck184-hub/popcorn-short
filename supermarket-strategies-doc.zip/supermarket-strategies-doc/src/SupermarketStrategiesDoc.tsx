import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {
  DURATION_SEC,
  NARRATION_1_SEC,
  NARRATION_2_SEC,
  NARRATION_2_START,
  NARRATION_3_SEC,
  NARRATION_3_START,
  PALETTE,
  sec,
} from './config';
import {TIMELINE} from './data/timeline';
import {SequenceStage} from './components/SequenceStage';
import {Captions} from './components/Captions';

export const SupermarketStrategiesDoc: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDeep}}>
      {/* 1. Tres pistas de narración en orden continuo exacto sin cortes ni silencios */}
      <Sequence from={0} durationInFrames={sec(NARRATION_1_SEC) + 1}>
        <Audio src={staticFile('audio/narration1.mp3')} volume={1} />
      </Sequence>
      <Sequence from={sec(NARRATION_2_START)} durationInFrames={sec(NARRATION_2_SEC) + 1}>
        <Audio src={staticFile('audio/narration2.mp3')} volume={1} />
      </Sequence>
      <Sequence from={sec(NARRATION_3_START)} durationInFrames={sec(NARRATION_3_SEC) + 1}>
        <Audio src={staticFile('audio/narration3.mp3')} volume={1} />
      </Sequence>

      {/* 2. Música instrumental continua a bajo volumen durante todo el documental */}
      <Sequence from={0} durationInFrames={sec(DURATION_SEC)}>
        <Audio src={staticFile('audio/music.wav')} volume={0.28} />
      </Sequence>

      {/* 3. Las 38 secuencias (seq-01 a seq-38) renderizadas directamente en el timeline */}
      {TIMELINE.map((seq, idx) => {
        const fromF = sec(seq.startSec);
        const toF = sec(seq.endSec);
        const durF = Math.max(1, toF - fromF);
        const midF = fromF + Math.max(4, Math.round(durF * 0.45));
        return (
          <React.Fragment key={seq.id}>
            <Sequence from={fromF} durationInFrames={durF} name={seq.id}>
              <SequenceStage seq={seq} />
            </Sequence>
            {idx > 0 && (
              <Sequence from={fromF} durationInFrames={10}>
                <Audio src={staticFile('audio/sfx/whoosh.wav')} volume={0.18} />
              </Sequence>
            )}
            {seq.sfx === 'chime' && (
              <Sequence from={fromF + 2} durationInFrames={15}>
                <Audio src={staticFile('audio/sfx/chime.wav')} volume={0.22} />
              </Sequence>
            )}
            {seq.sfx === 'pop' && (
              <Sequence from={midF} durationInFrames={8}>
                <Audio src={staticFile('audio/sfx/pop.wav')} volume={0.25} />
              </Sequence>
            )}
          </React.Fragment>
        );
      })}

      {/* 4. Subtítulos continuos en español */}
      <Captions />
    </AbsoluteFill>
  );
};
