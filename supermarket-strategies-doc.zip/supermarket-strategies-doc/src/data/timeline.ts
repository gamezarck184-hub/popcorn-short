export type SequenceMode =
  | 'enter_with_list'
  | 'list_milk_bread_vs_full_bag'
  | 'hidden_strategy_blueprint'
  | 'aisle_and_shelf_design'
  | 'puppet_stage_illusion'
  | 'top_down_store_map'
  | 'basics_far_from_entrance'
  | 'long_walk_more_exposure'
  | 'walking_past_offers_snacks'
  | 'two_items_extra_aisles'
  | 'separated_essentials_route'
  | 'transition_to_shelves'
  | 'eye_level_shelf_focus'
  | 'first_sight_zone_diagram'
  | 'brands_pay_for_eye_level'
  | 'cheap_items_bottom_shelf'
  | 'quick_grab_not_cheapest'
  | 'middle_aisle_promo_island'
  | 'product_mountains_discount_signs'
  | 'strategic_impulse_trap'
  | 'checkout_zone_intro'
  | 'checkout_candies_gum_drinks'
  | 'arm_reach_convenience'
  | 'bored_waiting_impulse_grab'
  | 'checkout_logic_summary'
  | 'charm_pricing_9999_vs_10000'
  | 'brain_perception_trick'
  | 'three_sizes_decoy'
  | 'choosing_larger_size'
  | 'store_ambience_lights_music'
  | 'warm_temp_and_aromas'
  | 'comfortable_slow_browsing'
  | 'more_time_more_purchases'
  | 'how_to_avoid_intro'
  | 'shopping_list_discipline'
  | 'no_hungry_shopping_unit_price'
  | 'offer_is_not_always_saving'
  | 'buying_unneeded_costs_more'
  | 'closing_observe_aisles'
  | 'closing_designed_path_exit';

export interface TimelineSequence {
  id: string;
  block: number;
  blockTitle: string;
  startSec: number;
  endSec: number;
  mode: SequenceMode;
  narrationText: string;
  captionLines: string[];
  highlights: string[];
  sceneLabel: string;
}

export const TIMELINE: TimelineSequence[] = [
  // ================= BLOQUE 1: EL IMPULSO DE COMPRAR (0.000 - 31.800s) =================
  {
    id: 'seq-01',
    block: 1,
    blockTitle: 'EL IMPULSO DE COMPRAR',
    startSec: 0.0,
    endSec: 4.6,
    mode: 'enter_with_list',
    narrationText: '¿Alguna vez entraste a un supermercado para comprar solamente leche y pan',
    captionLines: ['¿Alguna vez entraste a un supermercado', 'para comprar solamente leche y pan'],
    highlights: ['leche', 'pan'],
    sceneLabel: 'ENTRADA',
  },
  {
    id: 'seq-02',
    block: 1,
    blockTitle: 'EL IMPULSO DE COMPRAR',
    startSec: 4.6,
    endSec: 9.8,
    mode: 'list_milk_bread_vs_full_bag',
    narrationText: 'y terminaste saliendo con una bolsa llena de cosas que ni siquiera necesitabas?',
    captionLines: ['y terminaste saliendo con una bolsa llena', 'de cosas que ni siquiera necesitabas?'],
    highlights: ['bolsa', 'llena', 'necesitabas?'],
    sceneLabel: 'SALIDA',
  },
  {
    id: 'seq-03',
    block: 1,
    blockTitle: 'EL IMPULSO DE COMPRAR',
    startSec: 9.8,
    endSec: 17.5,
    mode: 'hidden_strategy_blueprint',
    narrationText: 'No es casualidad. Los supermercados llevan años estudiando cómo hacer que gastes más dinero, y muchas de sus estrategias funcionan sin que siquiera te des cuenta.',
    captionLines: ['Los supermercados estudian cómo hacer que gastes más', 'sin que siquiera te des cuenta.'],
    highlights: ['gastes', 'estrategias'],
    sceneLabel: 'DISEÑO DE TIENDA',
  },
  {
    id: 'seq-04',
    block: 1,
    blockTitle: 'EL IMPULSO DE COMPRAR',
    startSec: 17.5,
    endSec: 23.8,
    mode: 'aisle_and_shelf_design',
    narrationText: 'Desde la distribución de los pasillos hasta la ubicación de los productos, prácticamente todo está pensado para influir en tus decisiones.',
    captionLines: ['Desde los pasillos hasta cada estantería,', 'todo está pensado para influir en tus decisiones.'],
    highlights: ['pasillos', 'decisiones.'],
    sceneLabel: 'PASILLOS',
  },
  {
    id: 'seq-05',
    block: 1,
    blockTitle: 'EL IMPULSO DE COMPRAR',
    startSec: 23.8,
    endSec: 31.8,
    mode: 'puppet_stage_illusion',
    narrationText: 'Y lo más curioso es que muchas veces creemos que estamos comprando libremente, cuando en realidad el supermercado ya ha preparado el escenario para que terminemos comprando más.',
    captionLines: ['Creemos que elegimos libremente, pero el escenario', 'ya está preparado para que compremos más.'],
    highlights: ['libremente,', 'escenario'],
    sceneLabel: 'DECISIÓN',
  },

  // ================= BLOQUE 2: LA DISTRIBUCIÓN DEL SUPERMERCADO (31.800 - 85.290s) =================
  {
    id: 'seq-06',
    block: 2,
    blockTitle: 'LA DISTRIBUCIÓN DEL SUPERMERCADO',
    startSec: 31.8,
    endSec: 36.2,
    mode: 'top_down_store_map',
    narrationText: 'Una de las primeras estrategias está en la distribución del establecimiento.',
    captionLines: ['Una de las primeras estrategias está', 'en la distribución del establecimiento.'],
    highlights: ['distribución'],
    sceneLabel: 'PLANO DEL LOCAL',
  },
  {
    id: 'seq-07',
    block: 2,
    blockTitle: 'LA DISTRIBUCIÓN DEL SUPERMERCADO',
    startSec: 36.2,
    endSec: 44.5,
    mode: 'basics_far_from_entrance',
    narrationText: '¿Te has preguntado por qué productos básicos como la leche, los huevos o el pan suelen estar bastante alejados de la entrada?',
    captionLines: ['¿Por qué leche, huevos y pan', 'están tan alejados de la entrada?'],
    highlights: ['leche,', 'huevos', 'pan', 'alejados'],
    sceneLabel: 'LECHE • HUEVOS • PAN',
  },
  {
    id: 'seq-08',
    block: 2,
    blockTitle: 'LA DISTRIBUCIÓN DEL SUPERMERCADO',
    startSec: 44.5,
    endSec: 53.8,
    mode: 'long_walk_more_exposure',
    narrationText: 'La razón es sencilla. Si necesitas recorrer más partes del supermercado para encontrar lo que buscas, aumentan las posibilidades de que veas otros productos y termines añadiéndolos al carrito.',
    captionLines: ['Al recorrer más partes del supermercado,', 'ves más productos y los sumás al carrito.'],
    highlights: ['recorrer', 'carrito.'],
    sceneLabel: 'RECORRIDO',
  },
  {
    id: 'seq-09',
    block: 2,
    blockTitle: 'LA DISTRIBUCIÓN DEL SUPERMERCADO',
    startSec: 53.8,
    endSec: 64.0,
    mode: 'walking_past_offers_snacks',
    narrationText: 'Mientras caminas, encuentras ofertas, productos nuevos, snacks, bebidas y cosas que ni siquiera estaban en tu lista.',
    captionLines: ['Mientras caminás, encontrás ofertas, snacks,', 'bebidas y cosas que no estaban en tu lista.'],
    highlights: ['ofertas,', 'snacks,', 'bebidas'],
    sceneLabel: 'OFERTAS Y SNACKS',
  },
  {
    id: 'seq-10',
    block: 2,
    blockTitle: 'LA DISTRIBUCIÓN DEL SUPERMERCADO',
    startSec: 64.0,
    endSec: 73.2,
    mode: 'two_items_extra_aisles',
    narrationText: 'Y aunque solo hayas entrado por dos productos, cada pasillo adicional representa una nueva oportunidad para que gastes.',
    captionLines: ['Aunque entres por solo dos productos,', 'cada pasillo adicional es una oportunidad para gastar.'],
    highlights: ['dos', 'pasillo'],
    sceneLabel: 'PASILLO ADICIONAL',
  },
  {
    id: 'seq-11',
    block: 2,
    blockTitle: 'LA DISTRIBUCIÓN DEL SUPERMERCADO',
    startSec: 73.2,
    endSec: 85.29,
    mode: 'separated_essentials_route',
    narrationText: 'Por eso, en muchos supermercados, los productos que más necesitas no están colocados juntos ni cerca de la entrada. El recorrido está diseñado para que pases por distintas zonas antes de llegar a ellos.',
    captionLines: ['Los productos esenciales están separados:', 'cruzás distintas zonas antes de llegar a ellos.'],
    highlights: ['esenciales', 'zonas'],
    sceneLabel: 'ZONAS DEL LOCAL',
  },

  // ================= BLOQUE 3: LOS PRODUCTOS A LA ALTURA DE LOS OJOS (85.290 - 122.500s) =================
  {
    id: 'seq-12',
    block: 3,
    blockTitle: 'LOS PRODUCTOS A LA ALTURA DE LOS OJOS',
    startSec: 85.29,
    endSec: 92.2,
    mode: 'transition_to_shelves',
    narrationText: 'Pero la distribución de los pasillos es solamente una parte del plan. Otra estrategia muy utilizada es la ubicación de los productos en las estanterías.',
    captionLines: ['Otra estrategia clave es la ubicación', 'de los productos en las estanterías.'],
    highlights: ['ubicación', 'estanterías.'],
    sceneLabel: 'ESTANTERÍA',
  },
  {
    id: 'seq-13',
    block: 3,
    blockTitle: 'LOS PRODUCTOS A LA ALTURA DE LOS OJOS',
    startSec: 92.2,
    endSec: 98.0,
    mode: 'eye_level_shelf_focus',
    narrationText: 'Los productos que están a la altura de tus ojos suelen ser los que más interesa vender.',
    captionLines: ['Los productos a la altura de tus ojos', 'son los que más interesa vender.'],
    highlights: ['altura', 'ojos'],
    sceneLabel: 'ALTURA DE LOS OJOS',
  },
  {
    id: 'seq-14',
    block: 3,
    blockTitle: 'LOS PRODUCTOS A LA ALTURA DE LOS OJOS',
    startSec: 98.0,
    endSec: 105.0,
    mode: 'first_sight_zone_diagram',
    narrationText: 'Esa posición es especialmente valiosa porque es la primera zona que muchas personas observan al recorrer una estantería.',
    captionLines: ['Es la primera zona que miramos', 'al recorrer una estantería.'],
    highlights: ['primera', 'zona'],
    sceneLabel: 'ZONA VISUAL',
  },
  {
    id: 'seq-15',
    block: 3,
    blockTitle: 'LOS PRODUCTOS A LA ALTURA DE LOS OJOS',
    startSec: 105.0,
    endSec: 114.5,
    mode: 'brands_pay_for_eye_level',
    narrationText: 'Por eso, algunas marcas pagan para conseguir mejores exposiciones, mientras que los productos más económicos pueden estar en estantes inferiores o en lugares menos visibles.',
    captionLines: ['Las marcas pagan por el nivel de los ojos;', 'los más económicos quedan abajo.'],
    highlights: ['marcas', 'económicos', 'abajo.'],
    sceneLabel: 'PRECIO VS. ALTURA',
  },
  {
    id: 'seq-16',
    block: 3,
    blockTitle: 'LOS PRODUCTOS A LA ALTURA DE LOS OJOS',
    startSec: 114.5,
    endSec: 122.5,
    mode: 'quick_grab_not_cheapest',
    narrationText: 'Así, cuando buscas algo rápidamente, es posible que termines eligiendo el producto que más fácilmente encuentras, aunque no sea el más barato.',
    captionLines: ['Si buscás rápido, elegís el más visible,', 'aunque no sea el más barato.'],
    highlights: ['visible,', 'barato.'],
    sceneLabel: 'ELECCIÓN RÁPIDA',
  },

  // ================= BLOQUE 4: LAS OFERTAS (122.500 - 144.800s) =================
  {
    id: 'seq-17',
    block: 4,
    blockTitle: 'LAS OFERTAS',
    startSec: 122.5,
    endSec: 128.0,
    mode: 'middle_aisle_promo_island',
    narrationText: 'Y luego están las famosas ofertas que aparecen en medio de los pasillos.',
    captionLines: ['Luego aparecen las famosas ofertas', 'en medio de los pasillos.'],
    highlights: ['ofertas', 'pasillos.'],
    sceneLabel: 'OFERTAS',
  },
  {
    id: 'seq-18',
    block: 4,
    blockTitle: 'LAS OFERTAS',
    startSec: 128.0,
    endSec: 136.5,
    mode: 'product_mountains_discount_signs',
    narrationText: 'Montañas de productos, carteles enormes de descuento y exhibiciones especiales que parecen indicar que estás frente a una oportunidad única.',
    captionLines: ['Montañas de productos y carteles gigantes', 'simulan una oportunidad única.'],
    highlights: ['Montañas', 'descuento'],
    sceneLabel: 'DESCUENTO',
  },
  {
    id: 'seq-19',
    block: 4,
    blockTitle: 'LAS OFERTAS',
    startSec: 136.5,
    endSec: 144.8,
    mode: 'strategic_impulse_trap',
    narrationText: 'Sin embargo, muchas de estas exhibiciones están colocadas estratégicamente para llamar tu atención y provocar compras impulsivas.',
    captionLines: ['Están colocadas estratégicamente para llamar', 'tu atención y provocar compras impulsivas.'],
    highlights: ['impulsivas.'],
    sceneLabel: 'NECESIDAD VS. IMPULSO',
  },

  // ================= BLOQUE 5: LA ZONA DE CAJAS (144.800 - 176.666s) =================
  {
    id: 'seq-20',
    block: 5,
    blockTitle: 'LA ZONA DE CAJAS',
    startSec: 144.8,
    endSec: 150.2,
    mode: 'checkout_zone_intro',
    narrationText: 'Otro lugar especialmente diseñado para hacerte gastar más es la caja.',
    captionLines: ['Otro lugar diseñado para hacerte', 'gastar más es la zona de cajas.'],
    highlights: ['caja.'],
    sceneLabel: 'CAJA',
  },
  {
    id: 'seq-21',
    block: 5,
    blockTitle: 'LA ZONA DE CAJAS',
    startSec: 150.2,
    endSec: 157.8,
    mode: 'checkout_candies_gum_drinks',
    narrationText: 'Mientras esperas para pagar, encuentras chocolates, chicles, bebidas pequeñas y otros productos fáciles de agarrar.',
    captionLines: ['Mientras esperás, hay chocolates, chicles', 'y bebidas pequeñas fáciles de agarrar.'],
    highlights: ['chocolates,', 'chicles,'],
    sceneLabel: 'TENTACIÓN EN CAJA',
  },
  {
    id: 'seq-22',
    block: 5,
    blockTitle: 'LA ZONA DE CAJAS',
    startSec: 157.8,
    endSec: 164.0,
    mode: 'arm_reach_convenience',
    narrationText: 'No necesitas buscarlos: están justo delante de ti, a una distancia que hace muy fácil añadirlos a la compra.',
    captionLines: ['No necesitás buscarlos: están al alcance', 'de tu mano justo delante de vos.'],
    highlights: ['delante', 'fácil'],
    sceneLabel: 'AL ALCANCE',
  },
  {
    id: 'seq-23',
    block: 5,
    blockTitle: 'LA ZONA DE CAJAS',
    startSec: 164.0,
    endSec: 171.2,
    mode: 'bored_waiting_impulse_grab',
    narrationText: 'Y como estás esperando, aburrido o distraído, puedes terminar comprando algo que ni siquiera habías pensado llevar.',
    captionLines: ['Aburrido o distraído en la fila, sumás', 'algo que nunca habías pensado llevar.'],
    highlights: ['esperando,', 'distraído,'],
    sceneLabel: 'CINTA DE CAJA',
  },
  {
    id: 'seq-24',
    block: 5,
    blockTitle: 'LA ZONA DE CAJAS',
    startSec: 171.2,
    endSec: 176.666,
    mode: 'checkout_logic_summary',
    narrationText: 'Es una de las zonas donde más sentido tiene colocar productos baratos, pequeños y de consumo impulsivo.',
    captionLines: ['Es el punto ideal para productos baratos,', 'pequeños y de consumo impulsivo.'],
    highlights: ['baratos,', 'impulsivo.'],
    sceneLabel: 'PAGO',
  },

  // ================= BLOQUE 6: LA PSICOLOGÍA DE LOS PRECIOS (176.666 - 203.200s) =================
  {
    id: 'seq-25',
    block: 6,
    blockTitle: 'LA PSICOLOGÍA DE LOS PRECIOS',
    startSec: 176.666,
    endSec: 184.5,
    mode: 'charm_pricing_9999_vs_10000',
    narrationText: 'También existe una estrategia con los precios. Por ejemplo, cuando ves un producto a 9.999 en lugar de 10.000,',
    captionLines: ['Cuando ves un precio a 9.999', 'en lugar de 10.000,'],
    highlights: ['9.999', '10.000,'],
    sceneLabel: 'PRECIO',
  },
  {
    id: 'seq-26',
    block: 6,
    blockTitle: 'LA PSICOLOGÍA DE LOS PRECIOS',
    startSec: 184.5,
    endSec: 190.2,
    mode: 'brain_perception_trick',
    narrationText: 'tu cerebro puede percibirlo como un precio más bajo, aunque la diferencia sea prácticamente insignificante.',
    captionLines: ['tu cerebro lo percibe más barato,', 'aunque la diferencia sea insignificante.'],
    highlights: ['cerebro', 'bajo,'],
    sceneLabel: 'PERCEPCIÓN',
  },
  {
    id: 'seq-27',
    block: 6,
    blockTitle: 'LA PSICOLOGÍA DE LOS PRECIOS',
    startSec: 190.2,
    endSec: 196.8,
    mode: 'three_sizes_decoy',
    narrationText: 'Y cuando aparecen tres tamaños de un mismo producto, muchas veces el tamaño intermedio o grande está diseñado para parecer una opción mucho más conveniente.',
    captionLines: ['Con tres tamaños del mismo producto,', 'el grande parece mucho más conveniente.'],
    highlights: ['tres', 'tamaños', 'grande'],
    sceneLabel: 'TAMAÑOS',
  },
  {
    id: 'seq-28',
    block: 6,
    blockTitle: 'LA PSICOLOGÍA DE LOS PRECIOS',
    startSec: 196.8,
    endSec: 203.2,
    mode: 'choosing_larger_size',
    narrationText: 'Así, aunque originalmente pensabas comprar el más pequeño, terminas pagando más porque crees que estás aprovechando una mejor oferta.',
    captionLines: ['Ibas por el pequeño, pero pagás más', 'creyendo que aprovechás una mejor oferta.'],
    highlights: ['pagando', 'más'],
    sceneLabel: 'VALOR PERCIBIDO',
  },

  // ================= BLOQUE 7: EL AMBIENTE DEL SUPERMERCADO (203.200 - 227.500s) =================
  {
    id: 'seq-29',
    block: 7,
    blockTitle: 'EL AMBIENTE DEL SUPERMERCADO',
    startSec: 203.2,
    endSec: 209.5,
    mode: 'store_ambience_lights_music',
    narrationText: 'El ambiente también influye. La iluminación, la música, la temperatura',
    captionLines: ['El ambiente también influye:', 'iluminación, música y temperatura'],
    highlights: ['iluminación,', 'música,'],
    sceneLabel: 'AMBIENTE',
  },
  {
    id: 'seq-30',
    block: 7,
    blockTitle: 'EL AMBIENTE DEL SUPERMERCADO',
    startSec: 209.5,
    endSec: 214.2,
    mode: 'warm_temp_and_aromas',
    narrationText: 'y hasta ciertos aromas pueden hacer que el supermercado resulte más agradable.',
    captionLines: ['y ciertos aromas hacen que el local', 'resulte mucho más agradable.'],
    highlights: ['aromas', 'agradable.'],
    sceneLabel: 'AROMAS',
  },
  {
    id: 'seq-31',
    block: 7,
    blockTitle: 'EL AMBIENTE DEL SUPERMERCADO',
    startSec: 214.2,
    endSec: 221.2,
    mode: 'comfortable_slow_browsing',
    narrationText: 'Cuando te sientes cómodo, es más probable que recorras el establecimiento con calma, observes más productos y permanezcas más tiempo.',
    captionLines: ['Al sentirte cómodo, caminás con calma,', 'mirás más productos y te quedás más tiempo.'],
    highlights: ['calma,', 'tiempo.'],
    sceneLabel: 'RECORRIDO CALMO',
  },
  {
    id: 'seq-32',
    block: 7,
    blockTitle: 'EL AMBIENTE DEL SUPERMERCADO',
    startSec: 221.2,
    endSec: 227.5,
    mode: 'more_time_more_purchases',
    narrationText: 'Y cuanto más tiempo pasas dentro, mayores son las oportunidades de que termines comprando cosas adicionales.',
    captionLines: ['Cuanto más tiempo pasás dentro,', 'más cosas adicionales terminás comprando.'],
    highlights: ['más', 'tiempo', 'adicionales.'],
    sceneLabel: 'PERMANENCIA',
  },

  // ================= BLOQUE 8 Y 9: COMPRAS IMPULSIVAS Y CÓMO EVITAR GASTAR DE MÁS (227.500 - 271.882s) =================
  {
    id: 'seq-33',
    block: 8,
    blockTitle: 'LAS COMPRAS IMPULSIVAS',
    startSec: 227.5,
    endSec: 233.6,
    mode: 'how_to_avoid_intro',
    narrationText: 'Entonces, ¿cómo puedes evitar caer en estas estrategias? Lo más sencillo es ir con una lista de compras y tratar de respetarla.',
    captionLines: ['¿Cómo evitar caer en estas estrategias?', 'Llevá una lista de compras y respetala.'],
    highlights: ['lista', 'respetala.'],
    sceneLabel: 'LISTA DE COMPRAS',
  },
  {
    id: 'seq-34',
    block: 9,
    blockTitle: 'CÓMO EVITAR GASTAR DE MÁS',
    startSec: 233.6,
    endSec: 242.2,
    mode: 'no_hungry_shopping_unit_price',
    narrationText: 'También conviene evitar comprar con hambre, comparar precios por cantidad y no dejarse llevar únicamente por los carteles de ofertas.',
    captionLines: ['Evitá comprar con hambre, compará precios', 'por cantidad y no te guíes solo por carteles.'],
    highlights: ['hambre,', 'cantidad'],
    sceneLabel: 'COMPARAR PRECIO',
  },
  {
    id: 'seq-35',
    block: 9,
    blockTitle: 'CÓMO EVITAR GASTAR DE MÁS',
    startSec: 242.2,
    endSec: 248.0,
    mode: 'offer_is_not_always_saving',
    narrationText: 'Porque una oferta no siempre significa que estás ahorrando.',
    captionLines: ['Porque una oferta no siempre', 'significa que estás ahorrando.'],
    highlights: ['oferta', 'ahorrando.'],
    sceneLabel: 'AHORRO REAL',
  },
  {
    id: 'seq-36',
    block: 9,
    blockTitle: 'CÓMO EVITAR GASTAR DE MÁS',
    startSec: 248.0,
    endSec: 254.0,
    mode: 'buying_unneeded_costs_more',
    narrationText: 'Si compras algo que no necesitabas, en realidad estás gastando más.',
    captionLines: ['Si comprás algo que no necesitabas,', 'en realidad estás gastando más.'],
    highlights: ['gastando', 'más.'],
    sceneLabel: 'LISTA VS. CARRITO',
  },
  {
    id: 'seq-37',
    block: 9,
    blockTitle: 'CÓMO EVITAR GASTAR DE MÁS',
    startSec: 254.0,
    endSec: 262.0,
    mode: 'closing_observe_aisles',
    narrationText: 'La próxima vez que entres a un supermercado, observa los pasillos, las estanterías y los productos que aparecen frente a ti.',
    captionLines: ['La próxima vez que entres, observá los pasillos,', 'las estanterías y lo que aparece frente a vos.'],
    highlights: ['observá', 'pasillos,'],
    sceneLabel: 'CONCIENCIA',
  },
  {
    id: 'seq-38',
    block: 9,
    blockTitle: 'CÓMO EVITAR GASTAR DE MÁS',
    startSec: 262.0,
    endSec: 271.882,
    mode: 'closing_designed_path_exit',
    narrationText: 'Quizás pensabas que solamente estabas eligiendo qué comprar, pero alguien también había pensado en cómo ibas a recorrer cada pasillo.',
    captionLines: ['Alguien ya había pensado en cómo', 'ibas a recorrer cada pasillo.'],
    highlights: ['pensado', 'recorrer'],
    sceneLabel: 'SALIDA',
  },
];
