import React from 'react';
import {FONT_FAMILY, PALETTE} from '../config';

export interface PriceTagProps {
  x: number;
  y: number;
  title: string;
  price: string;
  subtitle?: string;
  tone?: 'neutral' | 'green' | 'amber' | 'red';
  scale?: number;
}

export const PriceTag: React.FC<PriceTagProps> = ({
  x,
  y,
  title,
  price,
  subtitle,
  tone = 'neutral',
  scale = 1,
}) => {
  const stroke =
    tone === 'green'
      ? PALETTE.accentGreen
      : tone === 'amber'
      ? PALETTE.amber
      : tone === 'red'
      ? PALETTE.red
      : '#334155';

  return (
    <g transform={`translate(${x}, ${y}) scale(${scale})`}>
      <rect
        x={-125}
        y={-52}
        width={250}
        height={104}
        rx={14}
        fill="#F8FAFC"
        stroke={stroke}
        strokeWidth={5}
      />
      <text
        x={0}
        y={-22}
        textAnchor="middle"
        fill="#334155"
        fontFamily={FONT_FAMILY}
        fontWeight="800"
        fontSize="17"
      >
        {title}
      </text>
      <text
        x={0}
        y={14}
        textAnchor="middle"
        fill="#090D16"
        fontFamily={FONT_FAMILY}
        fontWeight="900"
        fontSize="32"
      >
        {price}
      </text>
      {subtitle && (
        <text
          x={0}
          y={38}
          textAnchor="middle"
          fill="#1E7A44"
          fontFamily={FONT_FAMILY}
          fontWeight="800"
          fontSize="15"
        >
          {subtitle}
        </text>
      )}
    </g>
  );
};
