import React from 'react';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';

export interface PriceTagProps {
  x: number;
  y: number;
  label: string;
  priceText: string;
  accent?: 'normal' | 'highlight' | 'alert';
}

export const PriceTag: React.FC<PriceTagProps> = ({
  x,
  y,
  label,
  priceText,
  accent = 'normal',
}) => {
  const borderColor =
    accent === 'highlight'
      ? PALETTE.accentGreen
      : accent === 'alert'
      ? PALETTE.promoRed
      : '#334155';

  return (
    <g transform={`translate(${x}, ${y})`}>
      <rect
        x={-110}
        y={-42}
        width={220}
        height={84}
        rx={12}
        fill="#F8FAFC"
        stroke={borderColor}
        strokeWidth={5}
      />
      <text
        x={0}
        y={-12}
        textAnchor="middle"
        fill="#334155"
        fontFamily={fontFamily}
        fontWeight="700"
        fontSize="18"
      >
        {label}
      </text>
      <text
        x={0}
        y={22}
        textAnchor="middle"
        fill="#090D16"
        fontFamily={fontFamily}
        fontWeight="900"
        fontSize="28"
      >
        {priceText}
      </text>
    </g>
  );
};
