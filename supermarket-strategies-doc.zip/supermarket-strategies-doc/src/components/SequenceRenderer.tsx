import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, FONT_FAMILY, PALETTE, sec} from '../config';
import {TimelineSequence} from '../data/timeline';
import {Character, StickmanAction} from './Character';
import {ShoppingCart} from './ShoppingCart';
import {Shelf} from './Shelf';
import {PriceTag} from './PriceTag';

export const SequenceRenderer: React.FC<{seq: TimelineSequence}> = ({seq}) => {
  const frame = useCurrentFrame();
  const totalF = Math.max(1, sec(seq.endSec) - sec(seq.startSec));
  const p = interpolate(frame, [0, totalF], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // Cámara suave vinculada a la acción de cada secuencia
  const camScale = interpolate(p, [0, 1], [1.0, 1.05]);
  const camX = interpolate(p, [0, 1], [0, -24]);

  // Progresión temporal de personaje y carrito según el contenido real de la narración
  let charX = 620;
  let charAction: StickmanAction = 'walk';
  let cartX = 760;
  let cartItems = 2;
  let lookDir = 0.7;

  if (seq.mode === 'enter_with_list') {
    charX = interpolate(p, [0, 0.7, 1], [220, 620, 660]);
    charAction = p < 0.7 ? 'walk' : 'hold_list';
    cartX = charX + 135;
    cartItems = 0;
  } else if (seq.mode === 'list_milk_bread_vs_full_bag') {
    charX = interpolate(p, [0, 1], [540, 760]);
    charAction = p > 0.5 ? 'surprised' : 'push_cart';
    cartX = charX + 140;
    cartItems = Math.round(interpolate(p, [0, 1], [2, 8]));
  } else if (seq.mode === 'walking_past_offers_snacks' || seq.mode === 'long_walk_more_exposure') {
    charX = interpolate(p, [0, 1], [340, 960]);
    charAction = p > 0.45 && p < 0.75 ? 'reach_mid' : 'push_cart';
    cartX = charX + 140;
    cartItems = Math.round(interpolate(p, [0, 1], [2, 6]));
  } else if (seq.mode === 'eye_level_shelf_focus' || seq.mode === 'brands_pay_for_eye_level') {
    charX = 560;
    charAction = p > 0.35 ? 'reach_mid' : 'look_shelf';
    cartX = 410;
    cartItems = 4;
  } else if (seq.mode === 'cheap_items_bottom_shelf') {
    charX = 560;
    charAction = 'reach_down';
    cartX = 410;
    cartItems = 4;
  } else if (seq.mode === 'checkout_zone_intro' || seq.mode === 'checkout_candies_gum_drinks' || seq.mode === 'arm_reach_convenience' || seq.mode === 'bored_waiting_impulse_grab' || seq.mode === 'checkout_logic_summary') {
    charX = interpolate(p, [0, 1], [660, 820]);
    charAction = p > 0.45 ? 'reach_mid' : 'think';
    cartX = charX - 145;
    cartItems = Math.round(interpolate(p, [0, 1], [5, 8]));
  } else if (seq.mode === 'choosing_larger_size' || seq.mode === 'three_sizes_decoy') {
    charX = 520;
    charAction = p > 0.4 ? 'reach_up' : 'think';
    cartX = 370;
    cartItems = 6;
  } else if (seq.mode === 'comfortable_slow_browsing' || seq.mode === 'more_time_more_purchases') {
    charX = interpolate(p, [0, 1], [380, 920]);
    charAction = 'push_cart';
    cartX = charX + 140;
    cartItems = Math.round(interpolate(p, [0, 1], [4, 8]));
  } else if (seq.mode === 'shopping_list_discipline' || seq.mode === 'no_hungry_shopping_unit_price' || seq.mode === 'closing_designed_path_exit') {
    charX = interpolate(p, [0, 1], [420, 1080]);
    charAction = p < 0.35 ? 'hold_list' : 'push_cart';
    cartX = charX + 140;
    cartItems = 2; // Solo leche y pan comprados con intención
  } else {
    charX = interpolate(p, [0, 1], [420, 840]);
    charAction = 'push_cart';
    cartX = charX + 140;
    cartItems = 5;
  }

  const isTopDownMap =
    seq.mode === 'top_down_store_map' ||
    seq.mode === 'basics_far_from_entrance' ||
    seq.mode === 'separated_essentials_route';

  const isPricingComparison =
    seq.mode === 'charm_pricing_9999_vs_10000' ||
    seq.mode === 'brain_perception_trick' ||
    seq.mode === 'three_sizes_decoy' ||
    seq.mode === 'choosing_larger_size';

  const isListVsCartComparison =
    seq.mode === 'list_milk_bread_vs_full_bag' ||
    seq.mode === 'buying_unneeded_costs_more' ||
    seq.mode === 'offer_is_not_always_saving';

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDeep, overflow: 'hidden'}}>
      <svg
        width="1920"
        height="1080"
        viewBox="0 0 1920 1080"
        style={{
          transform: `translate(${camX}px, 0px) scale(${camScale})`,
          transformOrigin: '960px 540px',
        }}
      >
        {/* Fondo arquitectónico de supermercado en español */}
        <rect width="1920" height="1080" fill="#10192B" />
        <rect x={0} y={FLOOR_Y} width={1920} height={1080 - FLOOR_Y} fill="#1E293B" />
        <line x1={0} y1={FLOOR_Y} x2={1920} y2={FLOOR_Y} stroke="#475569" strokeWidth={4} />

        {/* Luces superiores del supermercado */}
        {[280, 740, 1200, 1660].map((lx, idx) => (
          <g key={idx}>
            <polygon
              points={`${lx - 70},90 ${lx + 70},90 ${lx + 210},${FLOOR_Y} ${lx - 210},${FLOOR_Y}`}
              fill={
                seq.block === 7
                  ? 'rgba(253, 224, 71, 0.08)'
                  : 'rgba(148, 163, 184, 0.04)'
              }
            />
            <rect x={lx - 75} y={76} width={150} height={14} rx={6} fill="#E2E8F0" />
          </g>
        ))}

        {/* Letrero superior de zona en español */}
        <g transform="translate(1690, 155)">
          <rect
            x={-170}
            y={-28}
            width={340}
            height={54}
            rx={10}
            fill="#0F172A"
            stroke={PALETTE.accentGreen}
            strokeWidth={3}
          />
          <text
            x={0}
            y={8}
            textAnchor="middle"
            fill={PALETTE.accentGreen}
            fontFamily={FONT_FAMILY}
            fontWeight="900"
            fontSize="22"
          >
            {seq.sceneLabel}
          </text>
        </g>

        {/* VISTA A: Plano cenital del recorrido del supermercado (Bloque 2) */}
        {isTopDownMap ? (
          <g transform="translate(960, 485)">
            <rect
              x={-540}
              y={-250}
              width={1080}
              height={490}
              rx={18}
              fill="#1E293B"
              stroke="#64748B"
              strokeWidth={4}
            />
            {/* Entrada abajo a la izquierda */}
            <rect x={-500} y={195} width={160} height={42} rx={8} fill={PALETTE.accentGreen} />
            <text
              x={-420}
              y={222}
              textAnchor="middle"
              fill="#090D16"
              fontFamily={FONT_FAMILY}
              fontWeight="900"
              fontSize="20"
            >
              ENTRADA
            </text>

            {/* Góndolas interiores */}
            {[-280, -60, 160].map((gx, idx) => (
              <rect
                key={idx}
                x={gx}
                y={-120}
                width={120}
                height={260}
                rx={10}
                fill="#334155"
                stroke="#94A3B8"
                strokeWidth={2.5}
              />
            ))}

            {/* Productos básicos al fondo (lejos de la entrada) */}
            <rect x={280} y={-225} width={220} height={64} rx={10} fill="#0284C7" />
            <text
              x={390}
              y={-186}
              textAnchor="middle"
              fill="#FFFFFF"
              fontFamily={FONT_FAMILY}
              fontWeight="900"
              fontSize="20"
            >
              LECHE • HUEVOS • PAN
            </text>

            {/* Ruta punteada larga */}
            <path
              d="M -420 190 L -420 -180 L -140 -180 L -140 160 L 80 160 L 80 -180 L 390 -180"
              fill="none"
              stroke={PALETTE.amber}
              strokeWidth={6}
              strokeDasharray="14 10"
            />

            {/* Marcador del cliente recorriendo todo el plano */}
            <circle
              cx={interpolate(p, [0, 0.35, 0.7, 1], [-420, -420, 80, 390])}
              cy={interpolate(p, [0, 0.35, 0.7, 1], [180, -180, 140, -180])}
              r={18}
              fill={PALETTE.accentGreen}
              stroke="#FFFFFF"
              strokeWidth={4}
            />
          </g>
        ) : (
          <>
            {/* Góndolas laterales de supermercado */}
            <Shelf
              x={1160}
              y={FLOOR_Y - 12}
              width={740}
              height={410}
              highlightTier={
                seq.block === 3
                  ? seq.mode === 'cheap_items_bottom_shelf'
                    ? 'bottom'
                    : 'eye'
                  : null
              }
              bannerText={
                seq.block === 4
                  ? 'OFERTA ESPECIAL'
                  : seq.block === 5
                  ? 'CAJA • DULCES Y CHICLES'
                  : undefined
              }
            />

            {/* Comparación de precios 9.999 vs 10.000 y 3 tamaños (Bloque 6) */}
            {isPricingComparison && (
              <g>
                <PriceTag
                  x={1120}
                  y={250}
                  title="PRECIO GANCHO"
                  price="9.999"
                  subtitle="PARECE MUCHO MENOR"
                  tone="green"
                  scale={1 + Math.sin(p * Math.PI) * 0.08}
                />
                <PriceTag
                  x={1430}
                  y={250}
                  title="PRECIO REDONDO"
                  price="10.000"
                  subtitle="DIFERENCIA DE 1"
                  tone="red"
                />
              </g>
            )}

            {/* Tarjeta comparativa: Lista inicial vs. Carrito final */}
            {isListVsCartComparison && (
              <g transform="translate(1320, 265)">
                <rect
                  x={-220}
                  y={-95}
                  width={440}
                  height={190}
                  rx={16}
                  fill="rgba(15, 23, 42, 0.92)"
                  stroke={PALETTE.amber}
                  strokeWidth={3.5}
                />
                <text
                  x={-190}
                  y={-52}
                  fill={PALETTE.accentGreen}
                  fontFamily={FONT_FAMILY}
                  fontWeight="900"
                  fontSize="21"
                >
                  LISTA: 1. Leche  2. Pan
                </text>
                <text
                  x={-190}
                  y={-8}
                  fill={PALETTE.white}
                  fontFamily={FONT_FAMILY}
                  fontWeight="700"
                  fontSize="19"
                >
                  + Snacks, bebidas, oferta, dulces...
                </text>
                <text
                  x={-190}
                  y={48}
                  fill={PALETTE.amber}
                  fontFamily={FONT_FAMILY}
                  fontWeight="900"
                  fontSize="22"
                >
                  OFERTA ≠ AHORRO SI NO LO NECESITÁS
                </text>
              </g>
            )}

            {/* Ondas visuales de música y aromas en Bloque 7 */}
            {seq.block === 7 && (
              <g transform="translate(1320, 260)">
                {[0, 1, 2].map((waveIdx) => {
                  const offset = ((frame * 2 + waveIdx * 35) % 105) / 105;
                  return (
                    <path
                      key={waveIdx}
                      d={`M ${-160 + waveIdx * 90} ${40 - offset * 80} Q ${
                        -130 + waveIdx * 90
                      } ${10 - offset * 80} ${-100 + waveIdx * 90} ${40 - offset * 80}`}
                      fill="none"
                      stroke="rgba(34, 197, 94, 0.55)"
                      strokeWidth={4}
                      strokeLinecap="round"
                      opacity={1 - offset}
                    />
                  );
                })}
                <text
                  x={0}
                  y={85}
                  textAnchor="middle"
                  fill="#FDE047"
                  fontFamily={FONT_FAMILY}
                  fontWeight="800"
                  fontSize="22"
                >
                  MÚSICA SUAVE • ILUMINACIÓN CÁLIDA • AROMAS
                </text>
              </g>
            )}

            {/* Personaje principal y carrito sincronizados */}
            <Character
              x={charX}
              y={FLOOR_Y}
              scale={1.08}
              action={charAction}
              lookDir={lookDir}
            />
            <ShoppingCart
              x={cartX}
              y={FLOOR_Y}
              scale={1.08}
              itemCount={cartItems}
              wheelAngle={frame * 6}
            />
          </>
        )}

        {/* Indicador discreto de bloque narrativo arriba a la izquierda */}
        <g transform="translate(56, 46)">
          <rect
            x={0}
            y={0}
            width={520}
            height={44}
            rx={10}
            fill="rgba(9, 13, 22, 0.78)"
            stroke="rgba(255,255,255,0.16)"
            strokeWidth={1.5}
          />
          <text
            x={20}
            y={28}
            fill={PALETTE.white}
            fontFamily={FONT_FAMILY}
            fontWeight="800"
            fontSize="17"
          >
            {`BLOQUE ${seq.block} · ${seq.blockTitle}`}
          </text>
        </g>
      </svg>
    </AbsoluteFill>
  );
};
