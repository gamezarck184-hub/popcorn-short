import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';
import {SCENES, sec} from '../script';

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const allCaptions = SCENES.flatMap((s) => s.captions);
  const current = allCaptions.find((c) => frame >= sec(c.from) && frame < sec(c.to));

  if (!current) return null;

  const startF = sec(current.from);
  const endF = sec(current.to);
  const fadeIn = interpolate(frame, [startF, startF + 5], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const fadeOut = interpolate(frame, [endF - 4, endF], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const highlights = new Set((current.highlights || []).map((w) => w.toLowerCase()));
  const lines = current.text.split('\n');

  return (
    <div
      style={{
        position: 'absolute',
        left: 160,
        right: 160,
        bottom: 44,
        display: 'flex',
        justifyContent: 'center',
        pointerEvents: 'none',
        opacity: fadeIn * fadeOut,
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(9, 13, 22, 0.86)',
          border: '1px solid rgba(255, 255, 255, 0.16)',
          borderRadius: 16,
          padding: '12px 28px',
          fontFamily,
          fontWeight: 800,
          fontSize: 32,
          lineHeight: 1.25,
          color: PALETTE.white,
          textAlign: 'center',
          textShadow: '0 2px 8px rgba(0, 0, 0, 0.9)',
        }}
      >
        {lines.map((line, lIdx) => (
          <div key={lIdx}>
            {line.split(' ').map((word, wIdx) => {
              const active = highlights.has(word.toLowerCase());
              return (
                <span
                  key={wIdx}
                  style={{color: active ? PALETTE.accentGreen : PALETTE.white}}
                >
                  {word}
                  {wIdx < line.split(' ').length - 1 ? ' ' : ''}
                </span>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};
