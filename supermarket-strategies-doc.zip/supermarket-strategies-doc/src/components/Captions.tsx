import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {FONT_FAMILY, PALETTE, sec} from '../config';
import {TIMELINE} from '../data/timeline';

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const current =
    TIMELINE.find((item) => frame >= sec(item.startSec) && frame < sec(item.endSec)) ||
    TIMELINE[TIMELINE.length - 1];

  const startF = sec(current.startSec);
  const endF = sec(current.endSec);
  const fadeIn = interpolate(frame, [startF, startF + 5], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const fadeOut = interpolate(frame, [endF - 4, endF], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const highlightSet = new Set(current.highlights.map((h) => h.toLowerCase()));

  return (
    <div
      style={{
        position: 'absolute',
        left: 170,
        right: 170,
        bottom: 34,
        display: 'flex',
        justifyContent: 'center',
        pointerEvents: 'none',
        opacity: Math.max(0.2, fadeIn * fadeOut),
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(9, 13, 22, 0.9)',
          border: '1.5px solid rgba(255, 255, 255, 0.16)',
          borderRadius: 16,
          padding: '12px 30px',
          fontFamily: FONT_FAMILY,
          fontWeight: 800,
          fontSize: 30,
          lineHeight: 1.24,
          color: PALETTE.white,
          textAlign: 'center',
          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.55)',
        }}
      >
        {current.captionLines.map((line, lIdx) => {
          const words = line.split(' ');
          return (
            <div key={lIdx}>
              {words.map((word, wIdx) => {
                const isHl = highlightSet.has(word.toLowerCase());
                return (
                  <span key={wIdx} style={{color: isHl ? PALETTE.accentGreen : PALETTE.white}}>
                    {word}
                    {wIdx < words.length - 1 ? ' ' : ''}
                  </span>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
};
