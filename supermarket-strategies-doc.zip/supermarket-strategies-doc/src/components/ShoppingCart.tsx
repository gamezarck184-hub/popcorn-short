import React from 'react';
import {PALETTE} from '../config';

export interface ShoppingCartProps {
  x: number;
  y: number;
  scale?: number;
  fillLevel?: number;
  wheelRoll?: number;
}

export const ShoppingCart: React.FC<ShoppingCartProps> = ({
  x,
  y,
  scale = 1,
  fillLevel = 0.2,
  wheelRoll = 0,
}) => {
  const clampedFill = Math.max(0, Math.min(1, fillLevel));

  return (
    <g transform={`translate(${x}, ${y}) scale(${scale})`}>
      <ellipse cx={0} cy={4} rx={66} ry={9} fill="rgba(0,0,0,0.32)" />

      {clampedFill > 0.05 && (
        <g>
          <rect
            x={-42}
            y={-56 - clampedFill * 28}
            width={26}
            height={28}
            rx={4}
            fill="#38BDF8"
            stroke={PALETTE.ink}
            strokeWidth={2.5}
          />
          <rect
            x={-10}
            y={-62 - clampedFill * 34}
            width={30}
            height={34}
            rx={4}
            fill={PALETTE.promoAmber}
            stroke={PALETTE.ink}
            strokeWidth={2.5}
          />
        </g>
      )}
      {clampedFill > 0.55 && (
        <g>
          <rect
            x={22}
            y={-68 - clampedFill * 20}
            width={24}
            height={30}
            rx={4}
            fill={PALETTE.promoRed}
            stroke={PALETTE.ink}
            strokeWidth={2.5}
          />
          <rect
            x={-28}
            y={-88}
            width={32}
            height={24}
            rx={4}
            fill={PALETTE.accentGreen}
            stroke={PALETTE.ink}
            strokeWidth={2.5}
          />
        </g>
      )}

      <polygon
        points="-54,-82 48,-82 34,-34 -38,-34"
        fill="rgba(226, 232, 240, 0.35)"
        stroke="#475569"
        strokeWidth={4.5}
        strokeLinejoin="round"
      />
      <line x1="-46" y1="-64" x2="42" y2="-64" stroke="#64748B" strokeWidth={2.5} />
      <line x1="-20" y1="-82" x2="-15" y2="-34" stroke="#64748B" strokeWidth={2.5} />
      <line x1="12" y1="-82" x2="9" y2="-34" stroke="#64748B" strokeWidth={2.5} />

      <polyline
        points="-54,-82 -68,-94 -78,-94"
        fill="none"
        stroke="#334155"
        strokeWidth={5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      <line x1="-38" y1="-22" x2="36" y2="-22" stroke="#334155" strokeWidth={4.5} />
      {[-30, 28].map((wx, idx) => (
        <g key={idx} transform={`translate(${wx}, -10) rotate(${wheelRoll})`}>
          <circle cx={0} cy={0} r={10} fill="#1E293B" stroke="#0F172A" strokeWidth={3} />
          <line x1={-7} y1={0} x2={7} y2={0} stroke="#94A3B8" strokeWidth={2} />
        </g>
      ))}
    </g>
  );
};
