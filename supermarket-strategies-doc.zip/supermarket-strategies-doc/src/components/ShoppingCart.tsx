import React from 'react';
import {PALETTE} from '../config';

export interface ShoppingCartProps {
  x: number;
  y: number;
  scale?: number;
  itemCount?: number;
  wheelDeg?: number;
}

export const ShoppingCart: React.FC<ShoppingCartProps> = ({
  x,
  y,
  scale = 1,
  itemCount = 2,
  wheelDeg = 0,
}) => {
  const count = Math.max(0, Math.min(8, Math.round(itemCount)));
  const items = [
    {x: -42, y: -74, w: 22, h: 36, color: PALETTE.sky},
    {x: -16, y: -68, w: 28, h: 30, color: PALETTE.amber},
    {x: 16, y: -72, w: 24, h: 34, color: PALETTE.red},
    {x: -36, y: -96, w: 26, h: 24, color: PALETTE.accentGreen},
    {x: -6, y: -98, w: 28, h: 28, color: '#A855F7'},
    {x: 24, y: -94, w: 22, h: 24, color: '#FB923C'},
    {x: -22, y: -116, w: 30, h: 22, color: '#06B6D4'},
    {x: 12, y: -114, w: 26, h: 22, color: '#FACC15'},
  ];

  return (
    <g transform={`translate(${x}, ${y}) scale(${scale})`}>
      <ellipse cx={0} cy={4} rx={68} ry={9} fill="rgba(0,0,0,0.32)" />
      {items.slice(0, count).map((it, idx) => (
        <rect
          key={idx}
          x={it.x}
          y={it.y}
          width={it.w}
          height={it.h}
          rx={4}
          fill={it.color}
          stroke={PALETTE.ink}
          strokeWidth={2.5}
        />
      ))}
      <polygon
        points="-54,-82 48,-82 34,-34 -38,-34"
        fill="rgba(226, 232, 240, 0.36)"
        stroke="#475569"
        strokeWidth={4.5}
        strokeLinejoin="round"
      />
      <line x1="-46" y1="-64" x2="42" y2="-64" stroke="#64748B" strokeWidth={2.5} />
      <line x1="-20" y1="-82" x2="-15" y2="-34" stroke="#64748B" strokeWidth={2.5} />
      <line x1="12" y1="-82" x2="9" y2="-34" stroke="#64748B" strokeWidth={2.5} />
      <polyline
        points="-54,-82 -68,-94 -78,-94"
        fill="none"
        stroke="#334155"
        strokeWidth={5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line x1="-38" y1="-22" x2="36" y2="-22" stroke="#334155" strokeWidth={4.5} />
      {[-30, 28].map((wx, idx) => (
        <g key={idx} transform={`translate(${wx}, -10) rotate(${wheelDeg})`}>
          <circle cx={0} cy={0} r={10} fill="#1E293B" stroke="#0F172A" strokeWidth={3} />
          <line x1={-7} y1={0} x2={7} y2={0} stroke="#94A3B8" strokeWidth={2} />
        </g>
      ))}
    </g>
  );
};
