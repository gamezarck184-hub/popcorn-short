import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {FLOOR_Y, FONT_FAMILY, PALETTE, sec} from '../config';
import {SequenceItem} from '../data/timeline';
import {Character, CharacterPose} from './Character';
import {ShoppingCart} from './ShoppingCart';
import {Shelf} from './Shelf';
import {PriceTag} from './PriceTag';

export const SequenceStage: React.FC<{seq: SequenceItem}> = ({seq}) => {
  const frame = useCurrentFrame();
  const durF = Math.max(1, sec(seq.endSec) - sec(seq.startSec));
  const p = interpolate(frame, [0, durF], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const camX = interpolate(p, [0, 1], [seq.cameraFrom.x, seq.cameraTo.x]);
  const camY = interpolate(p, [0, 1], [seq.cameraFrom.y, seq.cameraTo.y]);
  const camZoom = interpolate(p, [0, 1], [seq.cameraFrom.zoom, seq.cameraTo.zoom]);

  let charX = 560;
  let charPose: CharacterPose = 'walk';
  let cartX = 700;
  let cartItems = 3;
  let lookX = 0.7;

  switch (seq.id) {
    case 'seq-01':
      charX = interpolate(p, [0, 0.75, 1], [210, 580, 620]);
      charPose = p < 0.75 ? 'walk' : 'hold_list';
      cartX = charX + 135;
      cartItems = 0;
      break;
    case 'seq-02':
      charX = interpolate(p, [0, 1], [500, 760]);
      charPose = p > 0.55 ? 'surprised' : 'walk';
      cartX = charX + 140;
      cartItems = Math.round(interpolate(p, [0, 1], [2, 8]));
      break;
    case 'seq-03':
    case 'seq-04':
    case 'seq-05':
      charX = interpolate(p, [0, 1], [420, 820]);
      charPose = seq.id === 'seq-05' && p > 0.5 ? 'think' : 'walk';
      cartX = charX + 140;
      cartItems = Math.round(interpolate(p, [0, 1], [3, 6]));
      break;
    case 'seq-08':
    case 'seq-09':
    case 'seq-10':
      charX = interpolate(p, [0, 1], [330, 940]);
      charPose = p > 0.45 && p < 0.78 ? 'reach_mid' : 'walk';
      cartX = charX + 140;
      cartItems = Math.round(interpolate(p, [0, 1], [2, 7]));
      break;
    case 'seq-12':
    case 'seq-13':
    case 'seq-14':
      charX = 540;
      charPose = p > 0.35 ? 'reach_mid' : 'idle';
      cartX = 395;
      cartItems = 4;
      break;
    case 'seq-15':
      charX = 540;
      charPose = p > 0.5 ? 'reach_down' : 'reach_mid';
      cartX = 395;
      cartItems = 4;
      break;
    case 'seq-16':
      charX = interpolate(p, [0, 1], [540, 650]);
      charPose = 'reach_mid';
      cartX = 395;
      cartItems = 5;
      break;
    case 'seq-17':
    case 'seq-18':
    case 'seq-19':
      charX = interpolate(p, [0, 1], [440, 780]);
      charPose = p > 0.45 && p < 0.8 ? 'reach_mid' : 'walk';
      cartX = charX + 140;
      cartItems = Math.round(interpolate(p, [0, 1], [4, 7]));
      break;
    case 'seq-20':
    case 'seq-21':
    case 'seq-22':
    case 'seq-23':
    case 'seq-24':
      charX = interpolate(p, [0, 1], [620, 820]);
      charPose = p > 0.4 ? 'reach_mid' : 'think';
      cartX = charX - 145;
      cartItems = Math.round(interpolate(p, [0, 1], [5, 8]));
      lookX = 0.85;
      break;
    case 'seq-25':
    case 'seq-26':
      charX = 520;
      charPose = p > 0.5 ? 'think' : 'idle';
      cartX = 375;
      cartItems = 5;
      break;
    case 'seq-27':
    case 'seq-28':
      charX = 520;
      charPose = p > 0.4 ? 'reach_up' : 'think';
      cartX = 375;
      cartItems = Math.round(interpolate(p, [0, 1], [5, 7]));
      break;
    case 'seq-29':
    case 'seq-30':
    case 'seq-31':
    case 'seq-32':
      charX = interpolate(p, [0, 1], [370, 920]);
      charPose = 'walk';
      cartX = charX + 140;
      cartItems = Math.round(interpolate(p, [0, 1], [4, 8]));
      break;
    case 'seq-33':
    case 'seq-34':
    case 'seq-35':
    case 'seq-36':
    case 'seq-37':
    case 'seq-38':
      charX = interpolate(p, [0, 1], [420, 1080]);
      charPose = p < 0.35 ? 'hold_list' : 'walk';
      cartX = charX + 140;
      cartItems = 2;
      break;
    default:
      charX = interpolate(p, [0, 1], [380, 820]);
      charPose = 'walk';
      cartX = charX + 140;
      cartItems = 4;
      break;
  }

  const isTopDownPlan =
    seq.id === 'seq-06' || seq.id === 'seq-07' || seq.id === 'seq-11';

  const isPricePsych =
    seq.id === 'seq-25' ||
    seq.id === 'seq-26' ||
    seq.id === 'seq-27' ||
    seq.id === 'seq-28';

  const isListVsCart =
    seq.id === 'seq-02' ||
    seq.id === 'seq-35' ||
    seq.id === 'seq-36';

  const highlightTier =
    seq.block === 3
      ? seq.id === 'seq-15'
        ? 'bottom'
        : 'eye'
      : null;

  return (
    <AbsoluteFill style={{backgroundColor: PALETTE.bgDeep, overflow: 'hidden'}}>
      <svg
        width="1920"
        height="1080"
        viewBox="0 0 1920 1080"
        style={{
          transform: `translate(${camX}px, ${camY}px) scale(${camZoom})`,
          transformOrigin: '960px 540px',
        }}
      >
        <rect width="1920" height="1080" fill={PALETTE.wallSlate} />
        <rect x={0} y={FLOOR_Y} width={1920} height={1080 - FLOOR_Y} fill={PALETTE.floorMain} />
        <line x1={0} y1={FLOOR_Y} x2={1920} y2={FLOOR_Y} stroke={PALETTE.floorLine} strokeWidth={4} />

        {/* Luces del supermercado */}
        {[280, 740, 1200, 1660].map((lx, idx) => (
          <g key={idx}>
            <polygon
              points={`${lx - 70},90 ${lx + 70},90 ${lx + 210},${FLOOR_Y} ${lx - 210},${FLOOR_Y}`}
              fill={
                seq.block === 7
                  ? 'rgba(253, 224, 71, 0.08)'
                  : 'rgba(148, 163, 184, 0.04)'
              }
            />
            <rect x={lx - 75} y={76} width={150} height={14} rx={6} fill="#E2E8F0" />
          </g>
        ))}

        {/* Etiqueta superior derecha en español */}
        <g transform="translate(1690, 155)">
          <rect
            x={-175}
            y={-28}
            width={350}
            height={54}
            rx={10}
            fill="#0F172A"
            stroke={PALETTE.accentGreen}
            strokeWidth={3}
          />
          <text x={0} y={8} textAnchor="middle" fill={PALETTE.accentGreen} fontFamily={FONT_FAMILY} fontWeight="900" fontSize="21">
            {seq.zoneLabel}
          </text>
        </g>

        {isTopDownPlan ? (
          <g transform="translate(960, 485)">
            <rect x={-540} y={-250} width={1080} height={490} rx={18} fill="#1E293B" stroke="#64748B" strokeWidth={4} />
            <rect x={-500} y={195} width={160} height={42} rx={8} fill={PALETTE.accentGreen} />
            <text x={-420} y={222} textAnchor="middle" fill={PALETTE.ink} fontFamily={FONT_FAMILY} fontWeight="900" fontSize="20">
              ENTRADA
            </text>
            {[-280, -60, 160].map((gx, idx) => (
              <rect key={idx} x={gx} y={-120} width={120} height={260} rx={10} fill="#334155" stroke="#94A3B8" strokeWidth={2.5} />
            ))}
            <rect x={280} y={-225} width={220} height={64} rx={10} fill="#0284C7" />
            <text x={390} y={-186} textAnchor="middle" fill={PALETTE.white} fontFamily={FONT_FAMILY} fontWeight="900" fontSize="20">
              LECHE • HUEVOS • PAN
            </text>
            <path
              d="M -420 190 L -420 -180 L -140 -180 L -140 160 L 80 160 L 80 -180 L 390 -180"
              fill="none"
              stroke={PALETTE.amber}
              strokeWidth={6}
              strokeDasharray="14 10"
            />
            <circle
              cx={interpolate(p, [0, 0.35, 0.7, 1], [-420, -420, 80, 390])}
              cy={interpolate(p, [0, 0.35, 0.7, 1], [180, -180, 140, -180])}
              r={18}
              fill={PALETTE.accentGreen}
              stroke={PALETTE.white}
              strokeWidth={4}
            />
          </g>
        ) : (
          <>
            <Shelf
              x={1160}
              y={FLOOR_Y - 12}
              width={740}
              height={410}
              highlightTier={highlightTier}
              bannerText={
                seq.block === 4
                  ? 'OFERTA ESPECIAL'
                  : seq.block === 5
                  ? 'CAJA • DULCES Y CHICLES'
                  : undefined
              }
            />

            {isPricePsych && (
              <g>
                <PriceTag
                  x={1120}
                  y={250}
                  title="PRECIO GANCHO"
                  price="9.999"
                  subtitle="PARECE MUCHO MENOR"
                  tone="green"
                  scale={1 + Math.sin(p * Math.PI) * 0.08}
                />
                <PriceTag
                  x={1430}
                  y={250}
                  title="PRECIO REDONDO"
                  price="10.000"
                  subtitle="DIFERENCIA DE 1"
                  tone="red"
                />
              </g>
            )}

            {isListVsCart && (
              <g transform="translate(1320, 265)">
                <rect x={-220} y={-95} width={440} height={190} rx={16} fill="rgba(15, 23, 42, 0.92)" stroke={PALETTE.amber} strokeWidth={3.5} />
                <text x={-190} y={-52} fill={PALETTE.accentGreen} fontFamily={FONT_FAMILY} fontWeight="900" fontSize="21">
                  LISTA: 1. Leche  2. Pan
                </text>
                <text x={-190} y={-8} fill={PALETTE.white} fontFamily={FONT_FAMILY} fontWeight="700" fontSize="19">
                  + Snacks, bebidas, oferta, dulces...
                </text>
                <text x={-190} y={48} fill={PALETTE.amber} fontFamily={FONT_FAMILY} fontWeight="900" fontSize="21">
                  OFERTA ≠ AHORRO SI NO LO NECESITÁS
                </text>
              </g>
            )}

            {seq.block === 7 && (
              <g transform="translate(1320, 260)">
                {[0, 1, 2].map((waveIdx) => {
                  const offset = ((frame * 2 + waveIdx * 35) % 105) / 105;
                  return (
                    <path
                      key={waveIdx}
                      d={`M ${-160 + waveIdx * 90} ${40 - offset * 80} Q ${-130 + waveIdx * 90} ${10 - offset * 80} ${-100 + waveIdx * 90} ${40 - offset * 80}`}
                      fill="none"
                      stroke="rgba(34, 197, 94, 0.55)"
                      strokeWidth={4}
                      strokeLinecap="round"
                      opacity={1 - offset}
                    />
                  );
                })}
                <text x={0} y={85} textAnchor="middle" fill="#FDE047" fontFamily={FONT_FAMILY} fontWeight="800" fontSize="22">
                  MÚSICA SUAVE • ILUMINACIÓN CÁLIDA • AROMAS
                </text>
              </g>
            )}

            <Character x={charX} y={FLOOR_Y} scale={1.08} pose={charPose} lookX={lookX} />
            <ShoppingCart x={cartX} y={FLOOR_Y} scale={1.08} itemCount={cartItems} wheelDeg={frame * 6} />
          </>
        )}

        {/* Indicador de secuencia y bloque */}
        <g transform="translate(56, 46)">
          <rect x={0} y={0} width={560} height={44} rx={10} fill="rgba(9, 13, 22, 0.8)" stroke="rgba(255,255,255,0.16)" strokeWidth={1.5} />
          <text x={20} y={28} fill={PALETTE.white} fontFamily={FONT_FAMILY} fontWeight="800" fontSize="17">
            {`${seq.id.toUpperCase()} · BLOQUE ${seq.block}: ${seq.blockName}`}
          </text>
        </g>
      </svg>
    </AbsoluteFill>
  );
};
