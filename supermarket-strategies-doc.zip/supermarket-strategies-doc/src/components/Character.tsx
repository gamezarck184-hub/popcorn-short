import React from 'react';
import {useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';

export type CharacterPose =
  | 'idle'
  | 'walking'
  | 'pointing'
  | 'holding_list'
  | 'surprised'
  | 'thinking';

export interface CharacterProps {
  x: number;
  y: number;
  scale?: number;
  flipX?: boolean;
  pose?: CharacterPose;
  walkSpeed?: number;
  lookX?: number;
  armAngleDeg?: number;
}

export const Character: React.FC<CharacterProps> = ({
  x,
  y,
  scale = 1,
  flipX = false,
  pose = 'idle',
  walkSpeed = 0,
  lookX = 0.5,
  armAngleDeg = -32,
}) => {
  const frame = useCurrentFrame();

  const breath = Math.sin(frame * 0.1) * 2.2;
  const phase = walkSpeed > 0 ? Math.sin(frame * walkSpeed) : 0;
  const lift = walkSpeed > 0 ? Math.abs(Math.cos(frame * walkSpeed)) * 5 : 0;
  const blink = frame % 124 > 119 ? 0.12 : 1;
  const pupilDx = lookX * 4.5;

  const leftFootX = -18 + phase * 22;
  const rightFootX = 18 - phase * 22;
  const leftKneeX = -20 + phase * 11;
  const rightKneeX = 20 - phase * 11;

  const rad = (armAngleDeg * Math.PI) / 180;
  const shoulderR = {x: 32, y: -154 + breath};
  const handR = {
    x: shoulderR.x + Math.cos(rad) * 96,
    y: shoulderR.y + Math.sin(rad) * 96,
  };
  const elbowR = {
    x: (shoulderR.x + handR.x) / 2 + 5,
    y: (shoulderR.y + handR.y) / 2 + 12,
  };

  const shoulderL = {x: -32, y: -154 + breath};
  const handL =
    pose === 'holding_list'
      ? {x: 18, y: -124 + breath}
      : {x: -50 - phase * 14, y: -74 + breath * 0.5};
  const elbowL =
    pose === 'holding_list'
      ? {x: -24, y: -116 + breath}
      : {x: -48 - phase * 8, y: -114 + breath};

  return (
    <g
      transform={`translate(${x}, ${y - lift}) scale(${flipX ? -scale : scale}, ${scale})`}
    >
      <ellipse cx={0} cy={lift} rx={52} ry={10} fill="rgba(0,0,0,0.35)" />

      <polyline
        points={`-16,-78 ${leftKneeX},-38 ${leftFootX},${lift}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={12}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polyline
        points={`16,-78 ${rightKneeX},-38 ${rightFootX},${lift}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={12}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      <polyline
        points={`${shoulderL.x},${shoulderL.y} ${elbowL.x},${elbowL.y} ${handL.x},${handL.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={10.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      <path
        d={`M -32 ${-164 + breath}
            Q 0 ${-172 + breath} 32 ${-164 + breath}
            L 38 ${-76 + breath * 0.4}
            Q 0 ${-70 + breath * 0.4} -38 ${-76 + breath * 0.4} Z`}
        fill={PALETTE.sweaterGreen}
        stroke={PALETTE.ink}
        strokeWidth={3.8}
      />
      <path
        d={`M -15 ${-165 + breath} Q 0 ${-150 + breath} 15 ${-165 + breath}`}
        fill="none"
        stroke={PALETTE.sweaterGreenDark}
        strokeWidth={4.5}
        strokeLinecap="round"
      />

      <polyline
        points={`${shoulderR.x},${shoulderR.y} ${elbowR.x},${elbowR.y} ${handR.x},${handR.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={10.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line
        x1={shoulderR.x}
        y1={shoulderR.y}
        x2={(shoulderR.x + elbowR.x) / 2}
        y2={(shoulderR.y + elbowR.y) / 2}
        stroke={PALETTE.sweaterGreen}
        strokeWidth={15}
        strokeLinecap="round"
      />

      {pose === 'holding_list' && (
        <g transform={`translate(${handL.x + 8}, ${handL.y - 24})`}>
          <rect
            x={-18}
            y={-24}
            width={36}
            height={48}
            rx={4}
            fill="#FFFFFF"
            stroke={PALETTE.ink}
            strokeWidth={3}
          />
          <line x1={-10} y1={-10} x2={10} y2={-10} stroke="#0F172A" strokeWidth={2.5} />
          <line x1={-10} y1={2} x2={8} y2={2} stroke="#0F172A" strokeWidth={2.5} />
        </g>
      )}

      <circle
        cx={0}
        cy={-218 + breath}
        r={42}
        fill={PALETTE.white}
        stroke={PALETTE.ink}
        strokeWidth={4.2}
      />

      <line
        x1={-20 + pupilDx * 0.5}
        y1={pose === 'surprised' ? -240 + breath : -235 + breath}
        x2={-7 + pupilDx * 0.5}
        y2={-236 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.2}
        strokeLinecap="round"
      />
      <line
        x1={7 + pupilDx * 0.5}
        y1={-236 + breath}
        x2={20 + pupilDx * 0.5}
        y2={pose === 'surprised' ? -240 + breath : -235 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.2}
        strokeLinecap="round"
      />

      <ellipse
        cx={-12 + pupilDx}
        cy={-224 + breath}
        rx={4.2}
        ry={6 * blink}
        fill={PALETTE.ink}
      />
      <ellipse
        cx={12 + pupilDx}
        cy={-224 + breath}
        rx={4.2}
        ry={6 * blink}
        fill={PALETTE.ink}
      />

      {pose === 'surprised' ? (
        <ellipse cx={0} cy={-206 + breath} rx={6.5} ry={9} fill={PALETTE.ink} />
      ) : pose === 'pointing' ? (
        <path
          d={`M -12 ${-210 + breath} Q 0 ${-195 + breath} 12 ${-210 + breath}`}
          stroke={PALETTE.ink}
          strokeWidth={3.5}
          fill="none"
          strokeLinecap="round"
        />
      ) : (
        <line
          x1={-10}
          y1={-206 + breath}
          x2={10}
          y2={-207 + breath}
          stroke={PALETTE.ink}
          strokeWidth={3.5}
          strokeLinecap="round"
        />
      )}
    </g>
  );
};
