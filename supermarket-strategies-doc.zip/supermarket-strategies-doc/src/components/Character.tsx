import React from 'react';
import {useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';

export type StickmanAction =
  | 'idle'
  | 'walk'
  | 'run'
  | 'look_shelf'
  | 'reach_up'
  | 'reach_down'
  | 'reach_mid'
  | 'hold_list'
  | 'surprised'
  | 'think'
  | 'push_cart';

export interface CharacterProps {
  x: number;
  y: number;
  scale?: number;
  flipX?: boolean;
  action?: StickmanAction;
  walkCycleSpeed?: number;
  lookDir?: number; // -1 izquierda, 0 frente, 1 derecha
  armDeg?: number;
}

export const Character: React.FC<CharacterProps> = ({
  x,
  y,
  scale = 1,
  flipX = false,
  action = 'idle',
  walkCycleSpeed = 0,
  lookDir = 0.6,
  armDeg = -30,
}) => {
  const frame = useCurrentFrame();

  const breath = Math.sin(frame * 0.11) * 2.2;
  const speed =
    walkCycleSpeed > 0
      ? walkCycleSpeed
      : action === 'run'
      ? 0.36
      : action === 'walk' || action === 'push_cart'
      ? 0.22
      : 0;

  const stride = speed > 0 ? Math.sin(frame * speed) : 0;
  const bounce = speed > 0 ? Math.abs(Math.cos(frame * speed)) * 5.5 : 0;
  const blink = frame % 118 > 113 ? 0.12 : 1;
  const pupilShift = lookDir * 4.8;

  const leftFootX = -18 + stride * 24;
  const rightFootX = 18 - stride * 24;
  const leftKneeX = -20 + stride * 12;
  const rightKneeX = 20 - stride * 12;

  const effectiveArmDeg =
    action === 'reach_up'
      ? -62
      : action === 'reach_down'
      ? 36
      : action === 'reach_mid' || action === 'push_cart'
      ? -12
      : armDeg;

  const rad = (effectiveArmDeg * Math.PI) / 180;
  const shoulderR = {x: 32, y: -156 + breath};
  const handR = {
    x: shoulderR.x + Math.cos(rad) * 96,
    y: shoulderR.y + Math.sin(rad) * 96,
  };
  const elbowR = {
    x: (shoulderR.x + handR.x) / 2 + 5,
    y: (shoulderR.y + handR.y) / 2 + 12,
  };

  const shoulderL = {x: -32, y: -156 + breath};
  const handL =
    action === 'hold_list'
      ? {x: 20, y: -124 + breath}
      : action === 'push_cart'
      ? {x: 78, y: -112 + breath}
      : action === 'think'
      ? {x: 16, y: -182 + breath}
      : {x: -48 - stride * 14, y: -74 + breath * 0.5};
  const elbowL =
    action === 'hold_list'
      ? {x: -22, y: -114 + breath}
      : action === 'push_cart'
      ? {x: 28, y: -122 + breath}
      : action === 'think'
      ? {x: -28, y: -145 + breath}
      : {x: -46 - stride * 8, y: -115 + breath};

  return (
    <g transform={`translate(${x}, ${y - bounce}) scale(${flipX ? -scale : scale}, ${scale})`}>
      {/* Sombra en el piso */}
      <ellipse cx={0} cy={bounce} rx={52} ry={10} fill="rgba(0,0,0,0.34)" />

      {/* Piernas negras consistentes */}
      <polyline
        points={`-16,-78 ${leftKneeX},-38 ${leftFootX},${bounce}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={12}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polyline
        points={`16,-78 ${rightKneeX},-38 ${rightFootX},${bounce}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={12}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Brazo izquierdo */}
      <polyline
        points={`${shoulderL.x},${shoulderL.y} ${elbowL.x},${elbowL.y} ${handL.x},${handL.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={10.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Sudadera verde característica */}
      <path
        d={`M -32 ${-166 + breath}
            Q 0 ${-174 + breath} 32 ${-166 + breath}
            L 38 ${-76 + breath * 0.4}
            Q 0 ${-70 + breath * 0.4} -38 ${-76 + breath * 0.4} Z`}
        fill={PALETTE.sweaterGreen}
        stroke={PALETTE.ink}
        strokeWidth={3.8}
      />
      <path
        d={`M -15 ${-166 + breath} Q 0 ${-150 + breath} 15 ${-166 + breath}`}
        fill="none"
        stroke={PALETTE.sweaterGreenDark}
        strokeWidth={4.5}
        strokeLinecap="round"
      />

      {/* Brazo derecho */}
      <polyline
        points={`${shoulderR.x},${shoulderR.y} ${elbowR.x},${elbowR.y} ${handR.x},${handR.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={10.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line
        x1={shoulderR.x}
        y1={shoulderR.y}
        x2={(shoulderR.x + elbowR.x) / 2}
        y2={(shoulderR.y + elbowR.y) / 2}
        stroke={PALETTE.sweaterGreen}
        strokeWidth={15}
        strokeLinecap="round"
      />

      {/* Libreta de lista en mano cuando corresponde */}
      {action === 'hold_list' && (
        <g transform={`translate(${handL.x + 8}, ${handL.y - 24})`}>
          <rect
            x={-18}
            y={-24}
            width={36}
            height={48}
            rx={4}
            fill="#FFFFFF"
            stroke={PALETTE.ink}
            strokeWidth={3}
          />
          <line x1={-10} y1={-10} x2={10} y2={-10} stroke="#0F172A" strokeWidth={2.5} />
          <line x1={-10} y1={2} x2={8} y2={2} stroke="#0F172A" strokeWidth={2.5} />
        </g>
      )}

      {/* Cabeza circular blanca sin cabello */}
      <circle
        cx={0}
        cy={-220 + breath}
        r={42}
        fill={PALETTE.white}
        stroke={PALETTE.ink}
        strokeWidth={4.2}
      />

      {/* Cejas */}
      <line
        x1={-20 + pupilShift * 0.5}
        y1={action === 'surprised' ? -242 + breath : -237 + breath}
        x2={-7 + pupilShift * 0.5}
        y2={-238 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.2}
        strokeLinecap="round"
      />
      <line
        x1={7 + pupilShift * 0.5}
        y1={-238 + breath}
        x2={20 + pupilShift * 0.5}
        y2={action === 'surprised' ? -242 + breath : -237 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.2}
        strokeLinecap="round"
      />

      {/* Ojos */}
      <ellipse
        cx={-12 + pupilShift}
        cy={-226 + breath}
        rx={4.2}
        ry={6 * blink}
        fill={PALETTE.ink}
      />
      <ellipse
        cx={12 + pupilShift}
        cy={-226 + breath}
        rx={4.2}
        ry={6 * blink}
        fill={PALETTE.ink}
      />

      {/* Expresión bucal */}
      {action === 'surprised' ? (
        <ellipse cx={0} cy={-206 + breath} rx={6.5} ry={9} fill={PALETTE.ink} />
      ) : action === 'reach_up' || action === 'reach_mid' ? (
        <path
          d={`M -12 ${-211 + breath} Q 0 ${-196 + breath} 12 ${-211 + breath}`}
          stroke={PALETTE.ink}
          strokeWidth={3.5}
          fill="none"
          strokeLinecap="round"
        />
      ) : (
        <line
          x1={-10}
          y1={-207 + breath}
          x2={10}
          y2={-208 + breath}
          stroke={PALETTE.ink}
          strokeWidth={3.5}
          strokeLinecap="round"
        />
      )}
    </g>
  );
};
