import React from 'react';
import {useCurrentFrame} from 'remotion';
import {PALETTE} from '../config';

export type CharacterPose =
  | 'idle'
  | 'walk'
  | 'hold_list'
  | 'surprised'
  | 'think'
  | 'reach_mid'
  | 'reach_up'
  | 'reach_down';

export interface CharacterProps {
  x: number;
  y: number;
  scale?: number;
  flipX?: boolean;
  pose?: CharacterPose;
  stepPhase?: number;
  lookX?: number;
}

export const Character: React.FC<CharacterProps> = ({
  x,
  y,
  scale = 1,
  flipX = false,
  pose = 'walk',
  stepPhase,
  lookX = 0.7,
}) => {
  const frame = useCurrentFrame();
  const phase = stepPhase !== undefined ? stepPhase : frame * 0.24;

  const isMoving = pose === 'walk';
  const stride = isMoving ? Math.sin(phase) : 0;
  const bounce = isMoving ? Math.abs(Math.cos(phase)) * 5 : Math.sin(frame * 0.1) * 1.5;
  const breath = Math.sin(frame * 0.12) * 2;
  const blink = frame % 110 > 105 ? 0.15 : 1;
  const pupilDx = lookX * 4.5;

  const leftFootX = -18 + stride * 24;
  const rightFootX = 18 - stride * 24;
  const leftKneeX = -20 + stride * 12;
  const rightKneeX = 20 - stride * 12;

  const armAngle =
    pose === 'reach_up'
      ? -64
      : pose === 'reach_down'
      ? 36
      : pose === 'reach_mid'
      ? -10
      : -24 + Math.sin(frame * 0.14) * 6;
  const rad = (armAngle * Math.PI) / 180;
  const shoulderR = {x: 32, y: -156 + breath};
  const handR = {
    x: shoulderR.x + Math.cos(rad) * 94,
    y: shoulderR.y + Math.sin(rad) * 94,
  };
  const elbowR = {
    x: (shoulderR.x + handR.x) / 2 + 5,
    y: (shoulderR.y + handR.y) / 2 + 12,
  };

  const shoulderL = {x: -32, y: -156 + breath};
  const handL =
    pose === 'hold_list'
      ? {x: 22, y: -126 + breath}
      : pose === 'think'
      ? {x: 18, y: -182 + breath}
      : {x: -46 - stride * 14, y: -76 + breath * 0.4};
  const elbowL =
    pose === 'hold_list'
      ? {x: -20, y: -116 + breath}
      : pose === 'think'
      ? {x: -26, y: -146 + breath}
      : {x: -44 - stride * 8, y: -116 + breath};

  return (
    <g transform={`translate(${x}, ${y - bounce}) scale(${flipX ? -scale : scale}, ${scale})`}>
      <ellipse cx={0} cy={bounce} rx={50} ry={9} fill="rgba(0,0,0,0.35)" />

      {/* Piernas negras */}
      <polyline
        points={`-16,-78 ${leftKneeX},-38 ${leftFootX},${bounce}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={12}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polyline
        points={`16,-78 ${rightKneeX},-38 ${rightFootX},${bounce}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={12}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Brazo izquierdo */}
      <polyline
        points={`${shoulderL.x},${shoulderL.y} ${elbowL.x},${elbowL.y} ${handL.x},${handL.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={10.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Sudadera verde */}
      <path
        d={`M -32 ${-166 + breath}
            Q 0 ${-174 + breath} 32 ${-166 + breath}
            L 38 ${-76 + breath * 0.4}
            Q 0 ${-70 + breath * 0.4} -38 ${-76 + breath * 0.4} Z`}
        fill={PALETTE.sweaterGreen}
        stroke={PALETTE.ink}
        strokeWidth={3.8}
      />
      <path
        d={`M -15 ${-166 + breath} Q 0 ${-150 + breath} 15 ${-166 + breath}`}
        fill="none"
        stroke={PALETTE.sweaterGreenDark}
        strokeWidth={4.5}
        strokeLinecap="round"
      />

      {/* Brazo derecho */}
      <polyline
        points={`${shoulderR.x},${shoulderR.y} ${elbowR.x},${elbowR.y} ${handR.x},${handR.y}`}
        fill="none"
        stroke={PALETTE.ink}
        strokeWidth={10.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line
        x1={shoulderR.x}
        y1={shoulderR.y}
        x2={(shoulderR.x + elbowR.x) / 2}
        y2={(shoulderR.y + elbowR.y) / 2}
        stroke={PALETTE.sweaterGreen}
        strokeWidth={15}
        strokeLinecap="round"
      />

      {/* Lista de leche y pan */}
      {pose === 'hold_list' && (
        <g transform={`translate(${handL.x + 10}, ${handL.y - 24})`}>
          <rect x={-20} y={-26} width={40} height={52} rx={4} fill="#FFFFFF" stroke={PALETTE.ink} strokeWidth={3} />
          <line x1={-12} y1={-11} x2={12} y2={-11} stroke="#0F172A" strokeWidth={2.5} />
          <line x1={-12} y1={2} x2={10} y2={2} stroke="#0F172A" strokeWidth={2.5} />
        </g>
      )}

      {/* Cabeza circular blanca sin cabello */}
      <circle
        cx={0}
        cy={-220 + breath}
        r={42}
        fill={PALETTE.white}
        stroke={PALETTE.ink}
        strokeWidth={4.2}
      />

      {/* Cejas y ojos */}
      <line
        x1={-20 + pupilDx * 0.5}
        y1={pose === 'surprised' ? -242 + breath : -237 + breath}
        x2={-7 + pupilDx * 0.5}
        y2={-238 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.2}
        strokeLinecap="round"
      />
      <line
        x1={7 + pupilDx * 0.5}
        y1={-238 + breath}
        x2={20 + pupilDx * 0.5}
        y2={pose === 'surprised' ? -242 + breath : -237 + breath}
        stroke={PALETTE.ink}
        strokeWidth={3.2}
        strokeLinecap="round"
      />
      <ellipse cx={-12 + pupilDx} cy={-226 + breath} rx={4.2} ry={6 * blink} fill={PALETTE.ink} />
      <ellipse cx={12 + pupilDx} cy={-226 + breath} rx={4.2} ry={6 * blink} fill={PALETTE.ink} />

      {/* Boca */}
      {pose === 'surprised' ? (
        <ellipse cx={0} cy={-206 + breath} rx={6.5} ry={9} fill={PALETTE.ink} />
      ) : (
        <line x1={-10} y1={-207 + breath} x2={10} y2={-208 + breath} stroke={PALETTE.ink} strokeWidth={3.5} strokeLinecap="round" />
      )}
    </g>
  );
};
