import React from 'react';
import {FONT_FAMILY, PALETTE} from '../config';

export interface ShelfProps {
  x: number;
  y: number;
  width?: number;
  height?: number;
  highlightTier?: 'top' | 'eye' | 'bottom' | null;
  bannerText?: string;
}

export const Shelf: React.FC<ShelfProps> = ({
  x,
  y,
  width = 740,
  height = 410,
  highlightTier = null,
  bannerText,
}) => {
  const tiers = [0.24, 0.56, 0.88];
  const tierLabels = ['MARCA SUPERIOR', 'ALTURA DE OJOS', 'MÁS ECONÓMICO'];
  const colors = ['#0284C7', '#16A34A', '#EA580C', '#7C3AED', '#0D9488', '#D97706'];

  return (
    <g transform={`translate(${x - width / 2}, ${y - height})`}>
      <rect
        x={0}
        y={0}
        width={width}
        height={height}
        rx={12}
        fill={PALETTE.shelfBody}
        stroke="#475569"
        strokeWidth={4}
      />

      {highlightTier && (
        <rect
          x={14}
          y={
            highlightTier === 'top'
              ? 18
              : highlightTier === 'eye'
              ? height * 0.34
              : height * 0.66
          }
          width={width - 28}
          height={height * 0.26}
          rx={10}
          fill={
            highlightTier === 'bottom'
              ? 'rgba(56, 189, 248, 0.16)'
              : 'rgba(34, 197, 94, 0.18)'
          }
          stroke={highlightTier === 'bottom' ? PALETTE.sky : PALETTE.accentGreen}
          strokeWidth={4}
        />
      )}

      {tiers.map((ratio, rIdx) => {
        const sy = height * ratio;
        return (
          <g key={rIdx}>
            <rect x={16} y={sy} width={width - 32} height={12} rx={4} fill={PALETTE.shelfEdge} />
            {[0, 1, 2, 3, 4].map((pIdx) => {
              const px = 44 + pIdx * ((width - 130) / 4.3);
              const color = colors[(rIdx * 2 + pIdx) % colors.length];
              return (
                <g key={pIdx} transform={`translate(${px}, ${sy - 58})`}>
                  <rect
                    x={0}
                    y={0}
                    width={58}
                    height={56}
                    rx={6}
                    fill={color}
                    stroke="#0F172A"
                    strokeWidth={2.5}
                  />
                  <rect x={9} y={14} width={40} height={10} rx={3} fill="rgba(255,255,255,0.72)" />
                </g>
              );
            })}
            <text
              x={width - 26}
              y={sy - 66}
              textAnchor="end"
              fill="rgba(248,250,252,0.62)"
              fontFamily={FONT_FAMILY}
              fontWeight="700"
              fontSize="13"
            >
              {tierLabels[rIdx]}
            </text>
          </g>
        );
      })}

      {bannerText && (
        <g transform={`translate(${width / 2}, -18)`}>
          <rect x={-150} y={-22} width={300} height={42} rx={10} fill={PALETTE.amber} stroke={PALETTE.ink} strokeWidth={3} />
          <text x={0} y={6} textAnchor="middle" fill={PALETTE.ink} fontFamily={FONT_FAMILY} fontWeight="900" fontSize="19">
            {bannerText}
          </text>
        </g>
      )}
    </g>
  );
};
