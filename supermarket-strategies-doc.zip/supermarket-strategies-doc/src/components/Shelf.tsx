import React from 'react';
import {PALETTE} from '../config';
import {fontFamily} from '../fonts';

export interface ShelfProps {
  x: number;
  y: number;
  width?: number;
  height?: number;
  highlightBand?: 'top' | 'eye' | 'bottom' | null;
  showPromoTag?: boolean;
}

export const Shelf: React.FC<ShelfProps> = ({
  x,
  y,
  width = 860,
  height = 460,
  highlightBand = null,
  showPromoTag = false,
}) => {
  const tiers = [0.22, 0.54, 0.86];
  const colors = ['#0284C7', '#16A34A', '#EA580C', '#6366F1', '#0D9488', '#D97706'];

  return (
    <g transform={`translate(${x - width / 2}, ${y - height})`}>
      <rect
        x={0}
        y={0}
        width={width}
        height={height}
        rx={12}
        fill="#1E293B"
        stroke="#475569"
        strokeWidth={4}
      />

      {highlightBand && (
        <rect
          x={14}
          y={
            highlightBand === 'top'
              ? 24
              : highlightBand === 'eye'
              ? height * 0.34
              : height * 0.66
          }
          width={width - 28}
          height={height * 0.24}
          rx={10}
          fill="rgba(34, 197, 94, 0.14)"
          stroke={PALETTE.accentGreen}
          strokeWidth={4}
        />
      )}

      {tiers.map((ratio, rIdx) => {
        const sy = height * ratio;
        return (
          <g key={rIdx}>
            <rect
              x={16}
              y={sy}
              width={width - 32}
              height={12}
              rx={4}
              fill="#64748B"
            />
            {[0, 1, 2, 3, 4, 5].map((pIdx) => {
              const px = 48 + pIdx * ((width - 130) / 5.2);
              const color = colors[(rIdx * 2 + pIdx) % colors.length];
              return (
                <g key={pIdx} transform={`translate(${px}, ${sy - 56})`}>
                  <rect
                    x={0}
                    y={0}
                    width={54}
                    height={54}
                    rx={6}
                    fill={color}
                    stroke="#0F172A"
                    strokeWidth={2.5}
                  />
                  <rect x={8} y={14} width={38} height={10} rx={3} fill="rgba(255,255,255,0.65)" />
                </g>
              );
            })}
          </g>
        );
      })}

      {showPromoTag && (
        <g transform={`translate(${width * 0.62}, ${height * 0.28})`}>
          <rect
            x={-88}
            y={-28}
            width={176}
            height={52}
            rx={10}
            fill={PALETTE.promoAmber}
            stroke="#0F172A"
            strokeWidth={3}
          />
          <text
            x={0}
            y={8}
            textAnchor="middle"
            fill="#090D16"
            fontFamily={fontFamily}
            fontWeight="900"
            fontSize="24"
          >
            OFERTA
          </text>
        </g>
      )}
    </g>
  );
};
