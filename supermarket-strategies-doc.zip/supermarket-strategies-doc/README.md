# Supermarket Strategies Doc — Documental Animado 2D en Remotion

Documental animado 2D en formato horizontal (`1920 × 1080`, `30 fps`, `271.882 segundos`, `8156 frames`) con **38 secuencias individuales** (`seq-01` a `seq-38`) sincronizadas con los tres audios originales en español (`narration1.mp3`, `narration2.mp3`, `narration3.mp3`), música continua (`music.wav`) y efectos de sonido (`sfx/`).

## 1. Instalar dependencias

```bash
npm install
```

## 2. Abrir Remotion Studio

```bash
npm run dev
```

Selecciona la composición **`SupermarketStrategiesDoc`** en el panel izquierdo.

## 3. Comprobar vista previa y tipos

```bash
npm run typecheck
```

## 4. Renderizar el MP4

```bash
npm run render
```

El archivo final se exportará en `out/supermarket-strategies-doc.mp4`.
