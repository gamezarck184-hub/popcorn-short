# Supermarket Strategies Doc — Documental Animado 2D en Remotion

Documental animado en formato horizontal (`1920 × 1080`, `30 fps`, `271.882 segundos`, `8156 frames`) sincronizado frase por frase con los tres archivos de narración en español.

## Requisitos previos

- Node.js 18 o superior
- npm 9 o superior

## Instalación

```bash
npm install
```

## Vista previa en Remotion Studio

```bash
npm run dev
```

Abre el navegador en la URL local que indica la terminal y selecciona la composición **`SupermarketStrategiesDoc`**.

## Verificación de TypeScript

```bash
npm run typecheck
```

## Renderizado del video MP4

```bash
npm run render
```

El archivo final se guardará en `out/supermarket-strategies-doc.mp4`.
