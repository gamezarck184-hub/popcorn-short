# SupermarketStrategiesDoc — Documental Animado 2D en Remotion

Video horizontal (`1920x1080`, `30 fps`, MP4 H.264) sobre estrategias de consumo en supermercados: *¿Cómo los supermercados hacen que compres más sin que te des cuenta?*

## Comandos

```bash
npm install
npm run typecheck
npm run render
```

El video final se genera en `out/supermarket-strategies-doc.mp4`.
